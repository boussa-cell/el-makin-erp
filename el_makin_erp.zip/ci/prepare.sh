#!/usr/bin/env bash
set -e
cp -r lib /tmp/lib_bak
cp pubspec.yaml /tmp/pubspec_bak.yaml
flutter create --org com.elmakin --project-name el_makin_erp --platforms=android,web .
rm -rf lib && cp -r /tmp/lib_bak lib
cp /tmp/pubspec_bak.yaml pubspec.yaml
rm -rf test

M=android/app/src/main/AndroidManifest.xml
sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.CAMERA"/>\n    <application#' "$M"

for f in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk(Version)? *=? *flutter\.minSdkVersion/minSdk = 23/' "$f"
    grep -n "minSdk" "$f" || true
  fi
done

flutter pub get
flutter pub deps --style=compact | grep -i "mobile_scanner" || true

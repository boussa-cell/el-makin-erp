#!/usr/bin/env bash
set -e
cp -r lib /tmp/lib_bak
cp pubspec.yaml /tmp/pubspec_bak.yaml
flutter create --org com.elmakin --project-name el_makin_erp --platforms=android,web .
rm -rf lib && cp -r /tmp/lib_bak lib
cp /tmp/pubspec_bak.yaml pubspec.yaml
rm -rf test

M=android/app/src/main/AndroidManifest.xml
sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.CAMERA"/>\n    <application#' "$M"

for f in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk(Version)? *=? *flutter\.minSdkVersion/minSdk = 23/' "$f"
    grep -n "minSdk" "$f" || true
  fi
done

# --- توقيع ثابت للتطبيق: يسمح بالتحديث فوق النسخة القديمة دائمًا ---
KS=ci/signing/el-makin.jks
if [ -f "$KS" ] && [ -f android/app/build.gradle.kts ]; then
  cp "$KS" android/app/el-makin.jks
  python3 - <<'PYEOF'
import re
pw = open('ci/signing/password.txt').read().strip()
p = 'android/app/build.gradle.kts'
s = open(p).read()
block = (
    '\n    signingConfigs {\n'
    '        create("release") {\n'
    '            storeFile = file("el-makin.jks")\n'
    '            storePassword = "%s"\n'
    '            keyAlias = "elmakin"\n'
    '            keyPassword = "%s"\n'
    '        }\n'
    '    }\n' % (pw, pw)
)
if 'create("release")' not in s and re.search(r'\n    buildTypes\s*\{', s):
    s = re.sub(r'(\n    buildTypes\s*\{)', lambda m: block + m.group(1), s, count=1)
    s = s.replace('signingConfig = signingConfigs.getByName("debug")',
                  'signingConfig = signingConfigs.getByName("release")')
    open(p, 'w').write(s)
    print('SIGNING PATCHED')
else:
    print('SIGNING NOT PATCHED (using default key)')
PYEOF
fi

flutter pub get
flutter pub deps --style=compact | grep -i "mobile_scanner" || true

# EL MAKIN ERP

التشغيل من الهاتف:
1) Supabase: شغّل ملف sql/phase1.sql في SQL Editor، ثم أنشئ مستخدمك من Authentication.
2) GitHub: ارفع كل الملفات إلى مستودع (فرع main).
3) Settings > Secrets and variables > Actions: أضف SUPABASE_URL و SUPABASE_ANON_KEY.
4) تبويب Actions > Build APK > Run workflow، ثم نزّل el-makin-apk من أسفل صفحة التشغيل.

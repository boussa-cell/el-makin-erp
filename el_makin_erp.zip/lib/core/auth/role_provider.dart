import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../local/local_db.dart';
import '../sync/net.dart';

/// دور المستخدم الحالي: admin | manager | vendeur
/// يُحفظ محليًا ليعمل التطبيق بنفس الأيقونات بدون إنترنت.
/// (الحماية الحقيقية تتم في قاعدة البيانات عبر RLS)
final roleProvider = FutureProvider.autoDispose<String>((ref) async {
  final db = Supabase.instance.client;
  final uid = db.auth.currentUser?.id;
  if (uid == null) return 'vendeur';
  return withNetwork<String>(
    () async {
      final row = await db.from('profiles').select('role').eq('id', uid).maybeSingle();
      final role = (row?['role'] as String?) ?? 'vendeur';
      await LocalKv.set('role:$uid', role);
      return role;
    },
    () async => (await LocalKv.get('role:$uid')) ?? 'vendeur',
  );
});

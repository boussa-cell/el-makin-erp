import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../local/local_db.dart';
import '../sync/net.dart';

/// دور المستخدم الحالي: admin | manager | vendeur
/// يُحفظ الدور والاسم محليًا ليعمل التطبيق بنفس الأيقونات بدون إنترنت.
/// (الحماية الحقيقية تتم في قاعدة البيانات عبر RLS)
final roleProvider = FutureProvider.autoDispose<String>((ref) async {
  final db = Supabase.instance.client;
  final uid = db.auth.currentUser?.id;
  if (uid == null) return 'vendeur';
  return withNetwork<String>(
    () async {
      final row =
          await db.from('profiles').select('role, full_name').eq('id', uid).maybeSingle();
      final role = (row?['role'] as String?) ?? 'vendeur';
      await LocalKv.set('role:$uid', role);
      await LocalKv.set('name:$uid', (row?['full_name'] as String?) ?? '');
      return role;
    },
    () async => (await LocalKv.get('role:$uid')) ?? 'vendeur',
  );
});

/// اسم المستخدم الحالي (من ملفه الشخصي) ليظهر بدل البريد.
final userNameProvider = FutureProvider.autoDispose<String>((ref) async {
  await ref.watch(roleProvider.future);
  final uid = Supabase.instance.client.auth.currentUser?.id;
  if (uid == null) return '';
  return (await LocalKv.get('name:$uid')) ?? '';
});

/// الاسم المخزّن محليًا (يُستعمل في الفواتير المحفوظة بدون إنترنت).
Future<String> cachedUserName() async {
  final u = Supabase.instance.client.auth.currentUser;
  if (u == null) return '-';
  final n = await LocalKv.get('name:${u.id}');
  return (n != null && n.isNotEmpty) ? n : (u.email ?? '-');
}

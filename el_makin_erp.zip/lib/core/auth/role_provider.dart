import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// دور المستخدم الحالي: admin | manager | vendeur
/// (الحماية الحقيقية تتم في قاعدة البيانات عبر RLS؛ هذا فقط لإخفاء ما لا يحق له رؤيته)
final roleProvider = FutureProvider.autoDispose<String>((ref) async {
  final db = Supabase.instance.client;
  final uid = db.auth.currentUser?.id;
  if (uid == null) return 'vendeur';
  final row = await db.from('profiles').select('role').eq('id', uid).maybeSingle();
  return (row?['role'] as String?) ?? 'vendeur';
});

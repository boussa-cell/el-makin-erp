import 'package:supabase_flutter/supabase_flutter.dart';

import '../local/local_db.dart';
import 'net.dart';

class SyncService {
  static bool _busy = false;
  static final _db = Supabase.instance.client;

  static bool get loggedIn => _db.auth.currentSession != null;

  /// يرسل العمليات المحفوظة محليًا بالترتيب. يعيد عدد ما أُرسل بنجاح.
  /// - انقطاع الإنترنت: يتوقف ويبقي الباقي.
  /// - رفض السيرفر (مثل: مخزون غير كافٍ): تُعلَّم العملية "فشلت" لتراجعها يدويًا.
  static Future<int> flush() async {
    if (_busy || !loggedIn) return 0;
    _busy = true;
    var done = 0;
    try {
      final items = (await Outbox.all()).where((i) => i.status == 'pending').toList();
      for (final it in items) {
        try {
          await _send(it);
          await Outbox.remove(it.id);
          done++;
        } on PostgrestException catch (e) {
          await Outbox.markFailed(it.id, e.message);
        } catch (e) {
          if (isNetworkError(e)) break;
          await Outbox.markFailed(it.id, '$e');
        }
      }
    } finally {
      _busy = false;
    }
    return done;
  }

  static Future<void> _send(OutboxItem it) async {
    final p = it.payload;
    switch (it.op) {
      case 'upsert_customer':
        await _db.from('customers').upsert(p).timeout(netTimeout);
        break;
      case 'create_sale':
        await _db.rpc('create_sale', params: {
          'p_id': p['id'],
          'p_customer_id': p['customer_id'],
          'p_tier': p['tier'],
          'p_discount': p['discount'],
          'p_paid': p['paid'],
          'p_note': p['note'],
          'p_items': p['items'],
        }).timeout(netTimeout);
        break;
      case 'record_payment':
        await _db.rpc('record_payment', params: {
          'p_id': p['id'],
          'p_kind': p['kind'],
          'p_party_id': p['party_id'],
          'p_amount': p['amount'],
          'p_note': p['note'],
        }).timeout(netTimeout);
        break;
      default:
        throw Exception('unknown op ${it.op}');
    }
  }

  static Future<List<Map<String, dynamic>>> _fetchAll(String table) async {
    final out = <Map<String, dynamic>>[];
    var from = 0;
    while (true) {
      final rows = await _db
          .from(table)
          .select()
          .isFilter('deleted_at', null)
          .order('created_at')
          .range(from, from + 999)
          .timeout(const Duration(seconds: 30));
      out.addAll(rows);
      if (rows.length < 1000) break;
      from += 1000;
    }
    return out;
  }

  /// يحدّث النسخة المحلية من المنتجات والعملاء (للبحث والبيع بدون إنترنت).
  static Future<bool> refreshMasterData() async {
    if (!loggedIn) return false;
    try {
      final products = await _fetchAll('products');
      final customers = await _fetchAll('customers');
      await ProductCache.replaceAll(products);
      await CustomerCache.replaceAll(customers);
      await _reapplyPending();
      return true;
    } catch (_) {
      return false;
    }
  }

  /// بعد التحديث نعيد تطبيق العمليات التي لم تُرسل بعد حتى لا تختفي آثارها محليًا.
  static Future<void> _reapplyPending() async {
    for (final it in await Outbox.all()) {
      final p = it.payload;
      switch (it.op) {
        case 'upsert_customer':
          await CustomerCache.upsert({'balance': 0, ...p});
          break;
        case 'create_sale':
          for (final i in (p['items'] as List)) {
            await ProductCache.adjustStock(
                i['product_id'] as String, -((i['qty'] as num).toDouble()));
          }
          break;
        case 'record_payment':
          if (p['kind'] == 'customer') {
            await CustomerCache.adjustBalance(
                p['party_id'] as String, -((p['amount'] as num).toDouble()));
          }
          break;
      }
    }
  }
}

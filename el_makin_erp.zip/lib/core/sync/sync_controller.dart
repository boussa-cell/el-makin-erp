import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/backup/data/backup_service.dart';
import '../../features/customers/data/customer_repository.dart';
import '../../features/products/data/product_repository.dart';
import '../../features/sales/data/sales_repository.dart';
import '../local/local_db.dart';
import 'net.dart';
import 'sync_service.dart';

final syncingProvider = StateProvider<bool>((_) => false);
final outboxProvider = FutureProvider.autoDispose<List<OutboxItem>>((_) => Outbox.all());
final pendingCountProvider = FutureProvider.autoDispose<int>((_) => Outbox.count());

/// يراقب الاتصال: عند عودة الإنترنت (أو كل دقيقتين) يرسل العمليات المعلّقة
/// ثم يحدّث النسخة المحلية.
class SyncController {
  final Ref ref;
  SyncController(this.ref);

  StreamSubscription<List<ConnectivityResult>>? _sub;
  Timer? _timer;
  DateTime? _lastRefresh;

  void start() {
    _sub = Connectivity().onConnectivityChanged.listen((r) {
      if (!r.contains(ConnectivityResult.none)) syncNow();
    });
    _timer = Timer.periodic(const Duration(minutes: 2), (_) => syncNow(force: false));
  }

  Future<void> syncNow({bool force = true}) async {
    if (!SyncService.loggedIn || !Net.connected || ref.read(syncingProvider)) return;
    ref.read(syncingProvider.notifier).state = true;
    try {
      final done = await SyncService.flush();
      final due = _lastRefresh == null ||
          DateTime.now().difference(_lastRefresh!) > const Duration(minutes: 10);
      if (force || done > 0 || due) {
        final ok = await SyncService.refreshMasterData();
        if (ok) _lastRefresh = DateTime.now();
      }
      if (force || done > 0) {
        ref.invalidate(productsProvider);
        ref.invalidate(customersProvider);
        ref.invalidate(salesProvider);
      }
      await BackupService.autoBackupIfDue();
    } finally {
      ref.read(syncingProvider.notifier).state = false;
      ref.invalidate(pendingCountProvider);
      ref.invalidate(outboxProvider);
    }
  }

  void dispose() {
    _sub?.cancel();
    _timer?.cancel();
  }
}

final syncControllerProvider = Provider<SyncController>((ref) {
  final c = SyncController(ref)..start();
  ref.onDispose(c.dispose);
  return c;
});


/// حالة الاتصال للواجهة (true = متصل).
final onlineProvider = StreamProvider<bool>((ref) async* {
  yield Net.connected;
  await for (final r in Connectivity().onConnectivityChanged) {
    yield r.any((x) => x != ConnectivityResult.none);
  }
});

import 'dart:async';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';

/// هل الخطأ ناتج عن انقطاع الإنترنت (وليس رفضًا من السيرفر)؟
bool isNetworkError(Object e) {
  if (e is SocketException || e is TimeoutException || e is HandshakeException) return true;
  final s = e.toString();
  return s.contains('SocketException') ||
      s.contains('ClientException') ||
      s.contains('Failed host lookup') ||
      s.contains('AuthRetryableFetchException') ||
      s.contains('Connection closed') ||
      s.contains('Connection refused') ||
      s.contains('Connection reset') ||
      s.contains('Network is unreachable') ||
      s.contains('Software caused connection abort');
}

/// مهلة قصيرة: بدون إنترنت نريد الانتقال للوضع المحلي بسرعة.
const netTimeout = Duration(seconds: 6);

/// حالة الاتصال. نتجنب محاولة الشبكة أصلًا عندما نعرف أنها مقطوعة.
class Net {
  static bool _connected = true;
  static DateTime? _failedUntil;
  static StreamSubscription<List<ConnectivityResult>>? _sub;

  /// الجهاز يقول إن لديه اتصالًا (واي فاي/بيانات).
  static bool get connected => _connected;

  /// متصل ولم تفشل آخر محاولة شبكة قبل لحظات.
  static bool get online =>
      _connected && (_failedUntil == null || DateTime.now().isAfter(_failedUntil!));

  static bool _any(List<ConnectivityResult> r) => r.any((x) => x != ConnectivityResult.none);

  static Future<void> init() async {
    try {
      _connected = _any(await Connectivity().checkConnectivity());
    } catch (_) {}
    _sub ??= Connectivity().onConnectivityChanged.listen((r) {
      _connected = _any(r);
      _failedUntil = null;
    });
  }

  /// بعد فشل شبكة نتخطى المحاولات 15 ثانية فتصبح العمليات التالية فورية.
  static void markFailure() => _failedUntil = DateTime.now().add(const Duration(seconds: 15));
}

/// ينفّذ [onlineCall] إن كان هناك اتصال، وإلا (أو عند فشل الشبكة) ينفّذ [offlineCall].
/// أخطاء السيرفر (مثل رفض الصلاحيات) لا تُحوَّل للوضع المحلي.
Future<T> withNetwork<T>(
  Future<T> Function() onlineCall,
  Future<T> Function() offlineCall,
) async {
  if (!Net.online) return offlineCall();
  try {
    return await onlineCall().timeout(netTimeout);
  } catch (e) {
    if (!isNetworkError(e)) rethrow;
    Net.markFailure();
    return offlineCall();
  }
}

import 'dart:async';
import 'dart:io';

/// هل الخطأ ناتج عن انقطاع الإنترنت (وليس رفضًا من السيرفر)؟
bool isNetworkError(Object e) {
  if (e is SocketException || e is TimeoutException || e is HandshakeException) return true;
  final s = e.toString();
  return s.contains('SocketException') ||
      s.contains('ClientException') ||
      s.contains('Failed host lookup') ||
      s.contains('AuthRetryableFetchException') ||
      s.contains('Connection closed') ||
      s.contains('Connection refused') ||
      s.contains('Connection reset') ||
      s.contains('Network is unreachable') ||
      s.contains('Software caused connection abort');
}

const netTimeout = Duration(seconds: 12);

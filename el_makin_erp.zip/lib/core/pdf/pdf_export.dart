import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

/// يلتقط ما رُسم داخل RepaintBoundary كصورة PNG.
/// (نستخدم الصورة حتى يظهر النص العربي بشكل صحيح تمامًا في الـ PDF)
Future<Uint8List> captureBoundary(GlobalKey key, {double pixelRatio = 3}) async {
  final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
  if (boundary == null) throw Exception('Nothing to capture');
  final image = await boundary.toImage(pixelRatio: pixelRatio);
  final data = await image.toByteData(format: ui.ImageByteFormat.png);
  if (data == null) throw Exception('Capture failed');
  return data.buffer.asUint8List();
}

/// يحوّل الصورة إلى PDF بصفحة واحدة بعرض widthPt (طول الصفحة بحسب الصورة).
Future<Uint8List> pngToPdf(Uint8List png, {required double widthPt, double? minHeightPt}) async {
  final codec = await ui.instantiateImageCodec(png);
  final frame = await codec.getNextFrame();
  final w = frame.image.width.toDouble();
  final h = frame.image.height.toDouble();

  final imgHeight = widthPt * h / w;
  final pageHeight = math.max(imgHeight, minHeightPt ?? 0);

  final doc = pw.Document();
  final img = pw.MemoryImage(png);
  doc.addPage(
    pw.Page(
      pageFormat: PdfPageFormat(widthPt, pageHeight),
      build: (_) => pw.Align(
        alignment: pw.Alignment.topCenter,
        child: pw.Image(img, width: widthPt, height: imgHeight),
      ),
    ),
  );
  return doc.save();
}

Future<Uint8List> boundaryToPdf(GlobalKey key, {required bool thermal}) async {
  final png = await captureBoundary(key);
  return pngToPdf(
    png,
    widthPt: thermal ? PdfPageFormat.roll80.width : PdfPageFormat.a4.width,
    minHeightPt: thermal ? null : PdfPageFormat.a4.height,
  );
}

Future<void> printPdf(Uint8List bytes, String name) =>
    Printing.layoutPdf(onLayout: (_) async => bytes, name: name);

Future<void> sharePdf(Uint8List bytes, String filename) =>
    Printing.sharePdf(bytes: bytes, filename: filename);

/// مشاركة ملف نصي (CSV) يفتحه Excel. BOM لكي تظهر العربية بشكل صحيح.
Future<void> shareCsv(String filename, String content) async {
  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/$filename');
  await file.writeAsString('\uFEFF$content');
  await Share.shareXFiles([XFile(file.path, mimeType: 'text/csv')]);
}

import 'dart:math';

/// يولّد باركود EAN-13 داخلي (يبدأ بـ 200) مع رقم التحقق.
String generateEan13() {
  final r = Random.secure();
  final digits = <int>[2, 0, 0, for (var i = 0; i < 9; i++) r.nextInt(10)];
  var sum = 0;
  for (var i = 0; i < 12; i++) {
    sum += digits[i] * (i.isEven ? 1 : 3);
  }
  final check = (10 - sum % 10) % 10;
  return '${digits.join()}$check';
}

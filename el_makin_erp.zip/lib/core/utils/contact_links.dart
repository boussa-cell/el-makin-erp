import 'package:url_launcher/url_launcher.dart';

/// رقم واتساب بالصيغة الدولية (الأرقام الجزائرية التي تبدأ بـ 0 تتحول إلى 213).
String waDigits(String phone) {
  var d = phone.replaceAll(RegExp(r'\D'), '');
  if (d.startsWith('00')) d = d.substring(2);
  if (d.startsWith('0')) d = '213${d.substring(1)}';
  return d;
}

Future<void> openWhatsApp(String phone, [String text = '']) async {
  final q = text.isEmpty ? '' : '?text=${Uri.encodeComponent(text)}';
  await launchUrl(Uri.parse('https://wa.me/${waDigits(phone)}$q'),
      mode: LaunchMode.externalApplication);
}

Future<void> callPhone(String phone) async {
  await launchUrl(Uri(scheme: 'tel', path: phone.replaceAll(' ', '')));
}

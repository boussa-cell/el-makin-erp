import 'package:intl/intl.dart';

String dzd(num v) => '${NumberFormat('#,##0.00').format(v)} DZD';

import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

/// قراءة وكتابة ملفات Excel (.xlsx) و CSV بدون حزم Excel ثقيلة.

String _colName(int i) {
  var n = i;
  var s = '';
  do {
    s = String.fromCharCode(65 + n % 26) + s;
    n = n ~/ 26 - 1;
  } while (n >= 0);
  return s;
}

int _colIndex(String ref) {
  var n = 0;
  for (final c in ref.codeUnits) {
    if (c >= 65 && c <= 90) {
      n = n * 26 + (c - 64);
    } else if (c >= 97 && c <= 122) {
      n = n * 26 + (c - 96);
    } else {
      break;
    }
  }
  return n - 1;
}

String _esc(String s) => s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]'), '');

/// يبني ملف xlsx بورقة واحدة. الأرقام (num) تُكتب أرقامًا والباقي نصوصًا.
Uint8List buildXlsx(List<List<Object?>> rows, {String sheetName = 'Sheet1'}) {
  final sb = StringBuffer(
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>');
  for (var r = 0; r < rows.length; r++) {
    sb.write('<row r="${r + 1}">');
    for (var c = 0; c < rows[r].length; c++) {
      final v = rows[r][c];
      final ref = '${_colName(c)}${r + 1}';
      if (v == null || (v is String && v.isEmpty)) continue;
      if (v is num) {
        sb.write('<c r="$ref"><v>$v</v></c>');
      } else {
        sb.write('<c r="$ref" t="inlineStr"><is><t xml:space="preserve">${_esc('$v')}</t></is></c>');
      }
    }
    sb.write('</row>');
  }
  sb.write('</sheetData></worksheet>');

  const header = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  final files = <String, String>{
    '[Content_Types].xml': '$header'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        '</Types>',
    '_rels/.rels': '$header'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>',
    'xl/workbook.xml': '$header'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<sheets><sheet name="${_esc(sheetName)}" sheetId="1" r:id="rId1"/></sheets></workbook>',
    'xl/_rels/workbook.xml.rels': '$header'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        '</Relationships>',
    'xl/worksheets/sheet1.xml': sb.toString(),
  };

  final archive = Archive();
  files.forEach((name, content) {
    final bytes = utf8.encode(content);
    archive.addFile(ArchiveFile(name, bytes.length, bytes));
  });
  final out = ZipEncoder().encode(archive);
  return Uint8List.fromList(out!);
}

List<int> _fileBytes(ArchiveFile f) => f.content as List<int>;

String _plainNumber(String v) {
  // 6.001E12 -> رقم كامل، 12.0 -> 12
  final d = double.tryParse(v);
  if (d == null) return v;
  if (d == d.truncateToDouble() && d.abs() < 1e15) return d.toInt().toString();
  return v;
}

/// يقرأ أول ورقة من ملف xlsx ويعيد الصفوف كنصوص.
List<List<String>> readXlsx(Uint8List bytes) {
  final archive = ZipDecoder().decodeBytes(bytes);
  ArchiveFile? find(bool Function(String) test) {
    for (final f in archive.files) {
      if (f.isFile && test(f.name)) return f;
    }
    return null;
  }

  final shared = <String>[];
  final ss = find((n) => n == 'xl/sharedStrings.xml');
  if (ss != null) {
    final doc = XmlDocument.parse(utf8.decode(_fileBytes(ss)));
    for (final si in doc.findAllElements('si')) {
      shared.add(si.findAllElements('t').map((e) => e.innerText).join());
    }
  }

  final sheet = find((n) => n == 'xl/worksheets/sheet1.xml') ??
      find((n) => n.startsWith('xl/worksheets/sheet') && n.endsWith('.xml'));
  if (sheet == null) throw Exception('sheet not found');
  final doc = XmlDocument.parse(utf8.decode(_fileBytes(sheet)));

  final rows = <List<String>>[];
  for (final row in doc.findAllElements('row')) {
    final cells = <int, String>{};
    var maxCol = -1;
    for (final c in row.findElements('c')) {
      final ref = c.getAttribute('r') ?? '';
      final idx = ref.isEmpty ? maxCol + 1 : _colIndex(ref);
      final type = c.getAttribute('t');
      String value = '';
      if (type == 'inlineStr') {
        value = c.findAllElements('t').map((e) => e.innerText).join();
      } else {
        final v = c.findElements('v').isEmpty ? '' : c.findElements('v').first.innerText;
        if (type == 's') {
          final i = int.tryParse(v) ?? -1;
          value = (i >= 0 && i < shared.length) ? shared[i] : '';
        } else if (type == 'str' || type == 'b') {
          value = v;
        } else {
          value = _plainNumber(v);
        }
      }
      cells[idx] = value;
      if (idx > maxCol) maxCol = idx;
    }
    rows.add([for (var i = 0; i <= maxCol; i++) cells[i] ?? '']);
  }
  return rows;
}

/// CSV: يكتشف الفاصل (, أو ; أو Tab) ويدعم النصوص بين علامات اقتباس.
List<List<String>> readCsv(String text) {
  var t = text;
  if (t.startsWith('\uFEFF')) t = t.substring(1);
  final firstLine = t.split('\n').first;
  var delim = ',';
  var best = -1;
  for (final d in [',', ';', '\t']) {
    final n = d.allMatches(firstLine).length;
    if (n > best) {
      best = n;
      delim = d;
    }
  }

  final rows = <List<String>>[];
  var row = <String>[];
  final cell = StringBuffer();
  var inQuotes = false;
  for (var i = 0; i < t.length; i++) {
    final ch = t[i];
    if (inQuotes) {
      if (ch == '"') {
        if (i + 1 < t.length && t[i + 1] == '"') {
          cell.write('"');
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        cell.write(ch);
      }
    } else if (ch == '"') {
      inQuotes = true;
    } else if (ch == delim) {
      row.add(cell.toString());
      cell.clear();
    } else if (ch == '\n' || ch == '\r') {
      if (ch == '\r' && i + 1 < t.length && t[i + 1] == '\n') i++;
      row.add(cell.toString());
      cell.clear();
      rows.add(row);
      row = <String>[];
    } else {
      cell.write(ch);
    }
  }
  if (cell.isNotEmpty || row.isNotEmpty) {
    row.add(cell.toString());
    rows.add(row);
  }
  return rows;
}

import 'dart:convert';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// قاعدة بيانات محلية (SQLite) للعمل بدون إنترنت:
/// نسخة من المنتجات والعملاء + قائمة انتظار العمليات التي لم تُرسل بعد.
class LocalDb {
  LocalDb._();
  static final instance = LocalDb._();

  Database? _db;

  Future<Database> get db async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'el_makin.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, _) async {
        await db.execute('CREATE TABLE products_cache ('
            'id TEXT PRIMARY KEY, name_ar TEXT, name_fr TEXT, sku TEXT, barcode TEXT, '
            'json TEXT NOT NULL)');
        await db.execute('CREATE TABLE customers_cache ('
            'id TEXT PRIMARY KEY, name TEXT, phone TEXT, json TEXT NOT NULL)');
        await db.execute('CREATE TABLE outbox ('
            'id INTEGER PRIMARY KEY AUTOINCREMENT, op TEXT NOT NULL, payload TEXT NOT NULL, '
            "status TEXT NOT NULL DEFAULT 'pending', error TEXT, "
            'attempts INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)');
        await db.execute('CREATE TABLE kv (key TEXT PRIMARY KEY, value TEXT)');
      },
    );
  }
}

Map<String, dynamic> _decode(Object? json) =>
    Map<String, dynamic>.from(jsonDecode(json as String) as Map);

class LocalKv {
  static Future<String?> get(String key) async {
    final db = await LocalDb.instance.db;
    final rows = await db.query('kv', where: 'key = ?', whereArgs: [key], limit: 1);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  static Future<void> set(String key, String value) async {
    final db = await LocalDb.instance.db;
    await db.insert('kv', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}

class ProductCache {
  static Future<void> replaceAll(List<Map<String, dynamic>> rows) async {
    final db = await LocalDb.instance.db;
    await db.transaction((txn) async {
      await txn.delete('products_cache');
      final batch = txn.batch();
      for (final r in rows) {
        batch.insert(
          'products_cache',
          {
            'id': r['id'],
            'name_ar': r['name_ar'],
            'name_fr': r['name_fr'],
            'sku': r['sku'],
            'barcode': r['barcode'],
            'json': jsonEncode(r),
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      await batch.commit(noResult: true);
    });
  }

  static Future<List<Map<String, dynamic>>> search(String q) async {
    final db = await LocalDb.instance.db;
    final s = q.trim();
    final rows = s.isEmpty
        ? await db.query('products_cache', orderBy: 'name_ar', limit: 200)
        : await db.query(
            'products_cache',
            where: 'name_ar LIKE ? OR name_fr LIKE ? OR sku LIKE ? OR barcode LIKE ?',
            whereArgs: List.filled(4, '%$s%'),
            orderBy: 'name_ar',
            limit: 200,
          );
    return rows.map((r) => _decode(r['json'])).toList();
  }

  static Future<Map<String, dynamic>?> byBarcode(String code) async {
    final db = await LocalDb.instance.db;
    final rows =
        await db.query('products_cache', where: 'barcode = ?', whereArgs: [code], limit: 1);
    return rows.isEmpty ? null : _decode(rows.first['json']);
  }

  static Future<void> adjustStock(String id, double delta) async {
    final db = await LocalDb.instance.db;
    final rows = await db.query('products_cache', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return;
    final m = _decode(rows.first['json']);
    m['stock_qty'] = ((m['stock_qty'] ?? 0) as num).toDouble() + delta;
    await db.update('products_cache', {'json': jsonEncode(m)}, where: 'id = ?', whereArgs: [id]);
  }
}

class CustomerCache {
  static Map<String, Object?> _row(Map<String, dynamic> r) => {
        'id': r['id'],
        'name': r['name'],
        'phone': r['phone'],
        'json': jsonEncode(r),
      };

  static Future<void> replaceAll(List<Map<String, dynamic>> rows) async {
    final db = await LocalDb.instance.db;
    await db.transaction((txn) async {
      await txn.delete('customers_cache');
      final batch = txn.batch();
      for (final r in rows) {
        batch.insert('customers_cache', _row(r), conflictAlgorithm: ConflictAlgorithm.replace);
      }
      await batch.commit(noResult: true);
    });
  }

  static Future<void> upsert(Map<String, dynamic> r) async {
    final db = await LocalDb.instance.db;
    await db.insert('customers_cache', _row(r), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<List<Map<String, dynamic>>> search(String q) async {
    final db = await LocalDb.instance.db;
    final s = q.trim();
    final rows = s.isEmpty
        ? await db.query('customers_cache', orderBy: 'name', limit: 200)
        : await db.query(
            'customers_cache',
            where: 'name LIKE ? OR phone LIKE ?',
            whereArgs: List.filled(2, '%$s%'),
            orderBy: 'name',
            limit: 200,
          );
    return rows.map((r) => _decode(r['json'])).toList();
  }

  static Future<void> adjustBalance(String id, double delta) async {
    final db = await LocalDb.instance.db;
    final rows = await db.query('customers_cache', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return;
    final m = _decode(rows.first['json']);
    m['balance'] = ((m['balance'] ?? 0) as num).toDouble() + delta;
    await db.update('customers_cache', {'json': jsonEncode(m)}, where: 'id = ?', whereArgs: [id]);
  }
}

class OutboxItem {
  final int id;
  final String op; // create_sale | upsert_customer | record_payment
  final Map<String, dynamic> payload;
  final String status; // pending | failed
  final String? error;
  final int attempts;
  final DateTime createdAt;

  const OutboxItem({
    required this.id,
    required this.op,
    required this.payload,
    required this.status,
    this.error,
    required this.attempts,
    required this.createdAt,
  });

  factory OutboxItem.fromRow(Map<String, Object?> r) => OutboxItem(
        id: r['id'] as int,
        op: r['op'] as String,
        payload: _decode(r['payload']),
        status: r['status'] as String,
        error: r['error'] as String?,
        attempts: r['attempts'] as int,
        createdAt: DateTime.parse(r['created_at'] as String),
      );
}

class Outbox {
  static Future<int> add(String op, Map<String, dynamic> payload) async {
    final db = await LocalDb.instance.db;
    return db.insert('outbox', {
      'op': op,
      'payload': jsonEncode(payload),
      'status': 'pending',
      'attempts': 0,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  static Future<List<OutboxItem>> all() async {
    final db = await LocalDb.instance.db;
    final rows = await db.query('outbox', orderBy: 'id');
    return rows.map(OutboxItem.fromRow).toList();
  }

  static Future<int> count() async {
    final db = await LocalDb.instance.db;
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM outbox')) ?? 0;
  }

  static Future<void> markFailed(int id, String error) async {
    final db = await LocalDb.instance.db;
    await db.rawUpdate(
        "UPDATE outbox SET status = 'failed', error = ?, attempts = attempts + 1 WHERE id = ?",
        [error, id]);
  }

  static Future<void> markPending(int id) async {
    final db = await LocalDb.instance.db;
    await db.update('outbox', {'status': 'pending', 'error': null}, where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> remove(int id) async {
    final db = await LocalDb.instance.db;
    await db.delete('outbox', where: 'id = ?', whereArgs: [id]);
  }
}

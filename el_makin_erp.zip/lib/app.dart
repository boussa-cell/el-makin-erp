import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/l10n/strings.dart';
import 'core/sync/sync_controller.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/presentation/login_screen.dart';
import 'features/dashboard/presentation/dashboard_screen.dart';

class ElMakinApp extends ConsumerWidget {
  const ElMakinApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    return MaterialApp(
      title: 'EL MAKIN ERP',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      locale: Locale(lang),
      supportedLocales: const [Locale('ar'), Locale('fr')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: StreamBuilder<AuthState>(
        stream: Supabase.instance.client.auth.onAuthStateChange,
        builder: (context, _) {
          final session = Supabase.instance.client.auth.currentSession;
          return session == null ? const LoginScreen() : const _AuthedRoot();
        },
      ),
    );
  }
}


/// الصفحة الرئيسية بعد الدخول: تشغّل المزامنة التلقائية.
class _AuthedRoot extends ConsumerStatefulWidget {
  const _AuthedRoot();

  @override
  ConsumerState<_AuthedRoot> createState() => _AuthedRootState();
}

class _AuthedRootState extends ConsumerState<_AuthedRoot> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() => ref.read(syncControllerProvider).syncNow());
  }

  @override
  Widget build(BuildContext context) => const DashboardScreen();
}

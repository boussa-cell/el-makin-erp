import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../data/audit_repository.dart';

/// سجل العمليات المهمة (للمدير فقط): من فعل ماذا ومتى.
class AuditScreen extends ConsumerWidget {
  const AuditScreen({super.key});

  Color _color(String a) =>
      a == 'DELETE' ? Colors.red : (a == 'INSERT' ? Colors.green.shade700 : Colors.orange.shade800);

  String _pretty(Map<String, dynamic>? m) =>
      m == null ? '-' : const JsonEncoder.withIndent('  ').convert(m);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final logs = ref.watch(auditProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('audit_log'))),
        body: logs.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) {
            if (list.isEmpty) return Center(child: Text(ref.tr('no_logs')));
            return RefreshIndicator(
              onRefresh: () async => ref.invalidate(auditProvider),
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final e = list[i];
                  return Card(
                    child: ListTile(
                      onTap: () => showDialog<void>(
                        context: context,
                        builder: (_) => Directionality(
                          textDirection: TextDirection.ltr,
                          child: AlertDialog(
                            title: Text('${e.table} • ${e.action}'),
                            content: SingleChildScrollView(
                              child: SelectableText(
                                  '${ref.tr('old_data')}:\n${_pretty(e.oldData)}\n\n'
                                  '${ref.tr('new_data')}:\n${_pretty(e.newData)}',
                                  style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.of(context).pop(),
                                child: Text(ref.tr('close')),
                              ),
                            ],
                          ),
                        ),
                      ),
                      leading: Icon(Icons.history, color: _color(e.action)),
                      title: Text('${ref.tr('act_${e.action}')} — ${e.table}',
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${ref.tr('by_user')}: ${e.userName}\n${df.format(e.createdAt)}'),
                      isThreeLine: true,
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuditEntry {
  final String table;
  final String action; // INSERT | UPDATE | DELETE
  final String? recordId;
  final String userName;
  final Map<String, dynamic>? oldData;
  final Map<String, dynamic>? newData;
  final DateTime createdAt;

  const AuditEntry({
    required this.table,
    required this.action,
    this.recordId,
    required this.userName,
    this.oldData,
    this.newData,
    required this.createdAt,
  });
}

class AuditRepository {
  final _db = Supabase.instance.client;

  Future<List<AuditEntry>> list() async {
    final rows = await _db
        .from('audit_logs')
        .select('user_id, table_name, record_id, action, old_data, new_data, created_at')
        .order('created_at', ascending: false)
        .limit(200);
    final profiles = await _db.from('profiles').select('id, full_name');
    final names = {for (final p in profiles) p['id'] as String: (p['full_name'] as String?) ?? '-'};

    return [
      for (final r in rows)
        AuditEntry(
          table: r['table_name'] as String,
          action: r['action'] as String,
          recordId: r['record_id'] as String?,
          userName: names[r['user_id']] ?? '-',
          oldData: r['old_data'] == null ? null : Map<String, dynamic>.from(r['old_data'] as Map),
          newData: r['new_data'] == null ? null : Map<String, dynamic>.from(r['new_data'] as Map),
          createdAt: DateTime.parse(r['created_at'] as String).toLocal(),
        ),
    ];
  }
}

final auditProvider = FutureProvider.autoDispose<List<AuditEntry>>(
  (ref) => AuditRepository().list(),
);

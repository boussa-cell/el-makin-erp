import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../domain/purchase.dart';

class PurchasesRepository {
  final _db = Supabase.instance.client;

  /// يستدعي دالة create_purchase (عملية ذرّية: فاتورة + زيادة المخزون + رصيد المورد).
  Future<Map<String, dynamic>> createPurchase({
    required String purchaseId,
    required String supplierId,
    double discount = 0,
    double? paid,
    String? note,
    required List<Map<String, dynamic>> items,
  }) async {
    final res = await _db.rpc('create_purchase', params: {
      'p_id': purchaseId,
      'p_supplier_id': supplierId,
      'p_discount': discount,
      'p_paid': paid,
      'p_note': (note == null || note.trim().isEmpty) ? null : note.trim(),
      'p_items': items,
    });
    return Map<String, dynamic>.from(res as Map);
  }

  Future<List<PurchaseSummary>> list() async {
    final rows = await _db
        .from('purchases')
        .select('id, invoice_no, total, paid, remaining, created_at, suppliers(name)')
        .order('created_at', ascending: false)
        .limit(100);
    return rows.map(PurchaseSummary.fromMap).toList();
  }

  Future<List<Map<String, dynamic>>> items(String purchaseId) async {
    final rows = await _db
        .from('purchase_items')
        .select()
        .eq('purchase_id', purchaseId)
        .order('product_name');
    return rows;
  }
}

final purchasesRepoProvider = Provider((_) => PurchasesRepository());

final purchasesProvider = FutureProvider.autoDispose<List<PurchaseSummary>>(
  (ref) => ref.read(purchasesRepoProvider).list(),
);

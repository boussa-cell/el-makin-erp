import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../../products/data/product_repository.dart';
import '../../suppliers/data/supplier_repository.dart';
import '../data/purchases_repository.dart';
import '../domain/purchase.dart';
import 'new_purchase_screen.dart';

class PurchasesScreen extends ConsumerWidget {
  const PurchasesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final purchases = ref.watch(purchasesProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('purchases'))),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            final done = await Navigator.of(context).push<bool>(
              MaterialPageRoute(builder: (_) => const NewPurchaseScreen()),
            );
            if (done == true) {
              ref.invalidate(purchasesProvider);
              ref.invalidate(productsProvider);
              ref.invalidate(suppliersProvider);
            }
          },
          icon: const Icon(Icons.add),
          label: Text(ref.tr('new_purchase')),
        ),
        body: purchases.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) {
            if (list.isEmpty) return Center(child: Text(ref.tr('no_purchases')));
            return RefreshIndicator(
              onRefresh: () async => ref.invalidate(purchasesProvider),
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                itemCount: list.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) {
                  final p = list[i];
                  return Card(
                    child: ListTile(
                      onTap: () => showModalBottomSheet<void>(
                        context: context,
                        isScrollControlled: true,
                        builder: (_) => _PurchaseDetail(purchase: p),
                      ),
                      title: Text(p.invoiceNo, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${p.supplierName ?? '-'}\n${df.format(p.createdAt)}'),
                      isThreeLine: true,
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(dzd(p.total), style: const TextStyle(fontWeight: FontWeight.w800)),
                          if (p.remaining > 0)
                            Text('${ref.tr('remaining')}: ${dzd(p.remaining)}',
                                style: const TextStyle(color: Colors.red, fontSize: 12)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

class _PurchaseDetail extends ConsumerWidget {
  final PurchaseSummary purchase;
  const _PurchaseDetail({required this.purchase});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(purchase.invoiceNo,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: ref.read(purchasesRepoProvider).items(purchase.id),
              builder: (context, snap) {
                if (snap.hasError) return Text('${snap.error}');
                if (!snap.hasData) return const LinearProgressIndicator();
                return Column(
                  children: [
                    for (final it in snap.data!)
                      ListTile(
                        dense: true,
                        title: Text(it['product_name'] as String),
                        subtitle: Text('${it['qty']} × ${dzd(it['unit_cost'] as num)}'),
                        trailing: Text(dzd(it['total'] as num),
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                      ),
                  ],
                );
              },
            ),
            const Divider(),
            _row(ref.tr('total'), dzd(purchase.total)),
            _row(ref.tr('paid'), dzd(purchase.paid)),
            _row(ref.tr('remaining'), dzd(purchase.remaining)),
          ],
        ),
      ),
    );
  }

  Widget _row(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.w700))],
        ),
      );
}

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../../products/data/product_repository.dart';
import '../../products/domain/product.dart';
import '../../suppliers/data/supplier_repository.dart';
import '../data/purchases_repository.dart';

class _Line {
  final Product product;
  double qty;
  double cost;
  _Line(this.product)
      : qty = 1,
        cost = product.purchasePrice;
}

class NewPurchaseScreen extends ConsumerStatefulWidget {
  const NewPurchaseScreen({super.key});

  @override
  ConsumerState<NewPurchaseScreen> createState() => _NewPurchaseScreenState();
}

class _NewPurchaseScreenState extends ConsumerState<NewPurchaseScreen> {
  final String _purchaseId = const Uuid().v4();
  final List<_Line> _lines = [];
  final _discount = TextEditingController();
  final _paid = TextEditingController(text: '0.00');
  final _note = TextEditingController();
  String? _supplierId;
  bool _paidEdited = false;
  bool _saving = false;

  double _num(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '.')) ?? 0;

  double get _subtotal => _lines.fold(0.0, (s, l) => s + l.qty * l.cost);
  double get _total => math.max(0.0, _subtotal - _num(_discount));
  double get _paidValue => _paidEdited ? _num(_paid) : _total;
  double get _remaining => _total - _paidValue;

  @override
  void dispose() {
    _discount.dispose();
    _paid.dispose();
    _note.dispose();
    super.dispose();
  }

  void _syncPaid() {
    if (!_paidEdited) _paid.text = _total.toStringAsFixed(2);
  }

  void _msg(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _addProduct() async {
    final p = await showModalBottomSheet<Product>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _ProductPicker(),
    );
    if (p == null) return;
    setState(() {
      final i = _lines.indexWhere((l) => l.product.id == p.id);
      if (i == -1) {
        _lines.add(_Line(p));
      } else {
        _lines[i].qty += 1;
      }
      _syncPaid();
    });
  }

  Future<void> _editLine(int i) async {
    final l = _lines[i];
    final qty = TextEditingController(text: l.qty.toString());
    final cost = TextEditingController(text: l.cost.toString());
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ref.read(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: AlertDialog(
          title: Text(l.product.displayName(ref.read(langProvider))),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: qty,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: ref.tr('qty')),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: cost,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: ref.tr('unit_cost')),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false), child: Text(ref.tr('cancel'))),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
              onPressed: () => Navigator.of(context).pop(true),
              child: Text(ref.tr('ok')),
            ),
          ],
        ),
      ),
    );
    final q = double.tryParse(qty.text.replaceAll(',', '.')) ?? 0;
    final c = double.tryParse(cost.text.replaceAll(',', '.')) ?? 0;
    qty.dispose();
    cost.dispose();
    if (ok == true && q > 0 && c >= 0) {
      setState(() {
        l.qty = q;
        l.cost = c;
        _syncPaid();
      });
    }
  }

  Future<void> _confirm() async {
    if (_supplierId == null) return _msg(ref.tr('select_supplier'));
    if (_lines.isEmpty) return _msg(ref.tr('empty_purchase'));
    final paid = _paidValue;
    if (paid < 0 || paid > _total + 0.001) return _msg(ref.tr('invalid_paid'));

    setState(() => _saving = true);
    try {
      await ref.read(purchasesRepoProvider).createPurchase(
            purchaseId: _purchaseId,
            supplierId: _supplierId!,
            discount: _num(_discount),
            paid: _paidEdited ? paid : null,
            note: _note.text,
            items: [
              for (final l in _lines)
                {'product_id': l.product.id, 'qty': l.qty, 'unit_cost': l.cost},
            ],
          );
      if (mounted) {
        _msg(ref.tr('purchase_done'));
        Navigator.of(context).pop(true);
      }
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        _msg(e.message);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        _msg('$e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final suppliers = ref.watch(suppliersProvider(''));

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('new_purchase'))),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            suppliers.when(
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('$e'),
              data: (list) => DropdownButtonFormField<String>(
                value: _supplierId,
                decoration: InputDecoration(labelText: ref.tr('supplier')),
                items: [
                  for (final s in list) DropdownMenuItem<String>(value: s.id, child: Text(s.name)),
                ],
                onChanged: (v) => setState(() => _supplierId = v),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              onPressed: _addProduct,
              icon: const Icon(Icons.add_shopping_cart),
              label: Text(ref.tr('add_item')),
            ),
            const SizedBox(height: 8),
            for (var i = 0; i < _lines.length; i++)
              Card(
                child: ListTile(
                  onTap: () => _editLine(i),
                  title: Text(_lines[i].product.displayName(lang)),
                  subtitle: Text(
                      '${_lines[i].qty} × ${dzd(_lines[i].cost)} = ${dzd(_lines[i].qty * _lines[i].cost)}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => setState(() {
                      _lines.removeAt(i);
                      _syncPaid();
                    }),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            TextField(
              controller: _discount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: ref.tr('discount')),
              onChanged: (_) => setState(_syncPaid),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => setState(() {
                      _paidEdited = false;
                      _syncPaid();
                    }),
                    child: Text(ref.tr('cash')),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => setState(() {
                      _paidEdited = true;
                      _paid.text = '0';
                    }),
                    child: Text(ref.tr('credit')),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _paid,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: ref.tr('paid')),
              onChanged: (_) => setState(() => _paidEdited = true),
            ),
            const SizedBox(height: 12),
            TextField(controller: _note, decoration: InputDecoration(labelText: ref.tr('note'))),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(ref.tr('total'), style: const TextStyle(fontSize: 16)),
                Text(dzd(_total), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(ref.tr('remaining')),
                Text(dzd(_remaining),
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: _remaining > 0.004 ? Colors.red : Colors.green.shade700)),
              ],
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _saving ? null : _confirm,
              child: _saving
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(ref.tr('confirm_sale')),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _ProductPicker extends ConsumerStatefulWidget {
  const _ProductPicker();

  @override
  ConsumerState<_ProductPicker> createState() => _ProductPickerState();
}

class _ProductPickerState extends ConsumerState<_ProductPicker> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final products = ref.watch(productsProvider(_q));

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.8,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  autofocus: true,
                  onChanged: (v) => setState(() => _q = v),
                  decoration: InputDecoration(
                    hintText: ref.tr('search'),
                    prefixIcon: const Icon(Icons.search),
                  ),
                ),
              ),
              Expanded(
                child: products.when(
                  loading: () => const Center(child: CircularProgressIndicator()),
                  error: (e, _) => Center(child: Text('$e')),
                  data: (list) => ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (_, i) {
                      final p = list[i];
                      return ListTile(
                        title: Text(p.displayName(lang)),
                        subtitle: Text('${ref.tr('stock')}: ${p.stockQty}'),
                        trailing: Text(dzd(p.purchasePrice)),
                        onTap: () => Navigator.of(context).pop(p),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

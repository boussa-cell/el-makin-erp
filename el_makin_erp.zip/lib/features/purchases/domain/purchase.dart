class PurchaseSummary {
  final String id;
  final String invoiceNo;
  final String? supplierName;
  final double total;
  final double paid;
  final double remaining;
  final DateTime createdAt;

  const PurchaseSummary({
    required this.id,
    required this.invoiceNo,
    this.supplierName,
    required this.total,
    required this.paid,
    required this.remaining,
    required this.createdAt,
  });

  factory PurchaseSummary.fromMap(Map<String, dynamic> m) {
    final s = m['suppliers'];
    return PurchaseSummary(
      id: m['id'] as String,
      invoiceNo: m['invoice_no'] as String,
      supplierName: s is Map ? s['name'] as String? : null,
      total: (m['total'] as num).toDouble(),
      paid: (m['paid'] as num).toDouble(),
      remaining: (m['remaining'] as num).toDouble(),
      createdAt: DateTime.parse(m['created_at'] as String).toLocal(),
    );
  }
}

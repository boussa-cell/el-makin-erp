import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../data/customer_repository.dart';
import '../domain/customer.dart';

class CustomerFormSheet extends ConsumerStatefulWidget {
  final Customer? customer;
  const CustomerFormSheet({super.key, this.customer});

  @override
  ConsumerState<CustomerFormSheet> createState() => _CustomerFormSheetState();
}

class _CustomerFormSheetState extends ConsumerState<CustomerFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController name, phone, address, wilaya, shipping, notes;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final c = widget.customer;
    name = TextEditingController(text: c?.name ?? '');
    phone = TextEditingController(text: c?.phone ?? '');
    address = TextEditingController(text: c?.address ?? '');
    wilaya = TextEditingController(text: c?.wilaya ?? '');
    shipping = TextEditingController(text: c?.shippingCenter ?? '');
    notes = TextEditingController(text: c?.notes ?? '');
  }

  @override
  void dispose() {
    for (final c in [name, phone, address, wilaya, shipping, notes]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await ref.read(customerRepoProvider).save(Customer(
            id: widget.customer?.id,
            name: name.text,
            phone: phone.text,
            address: address.text,
            wilaya: wilaya.text,
            shippingCenter: shipping.text,
            notes: notes.text,
          ));
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  Widget _field(TextEditingController c, String label,
      {bool required = false, TextInputType? type}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: type,
        decoration: InputDecoration(labelText: label),
        validator: required
            ? (v) => (v == null || v.trim().isEmpty) ? ref.tr('required') : null
            : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(ref.tr(widget.customer == null ? 'add_customer' : 'edit_customer'),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 16),
                _field(name, ref.tr('name'), required: true),
                _field(phone, ref.tr('phone'), type: TextInputType.phone),
                _field(address, ref.tr('address')),
                _field(wilaya, ref.tr('wilaya')),
                _field(shipping, ref.tr('shipping_center')),
                _field(notes, ref.tr('notes')),
                FilledButton(
                  onPressed: _saving ? null : _save,
                  child: Text(ref.tr('save')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

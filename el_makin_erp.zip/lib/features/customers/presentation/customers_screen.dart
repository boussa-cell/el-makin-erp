import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../data/customer_repository.dart';
import '../domain/customer.dart';
import 'customer_form_sheet.dart';

class CustomersScreen extends ConsumerStatefulWidget {
  const CustomersScreen({super.key});

  @override
  ConsumerState<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends ConsumerState<CustomersScreen> {
  String _q = '';

  Future<void> _openForm([Customer? c]) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => CustomerFormSheet(customer: c),
    );
    if (saved == true) ref.invalidate(customersProvider);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final customers = ref.watch(customersProvider(_q));

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('customers'))),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _openForm(),
          icon: const Icon(Icons.person_add_alt_1),
          label: Text(ref.tr('add_customer')),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: '${ref.tr('name')} / ${ref.tr('phone')}',
                  prefixIcon: const Icon(Icons.search),
                ),
              ),
            ),
            Expanded(
              child: customers.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
                data: (list) {
                  if (list.isEmpty) return Center(child: Text(ref.tr('no_customers')));
                  return ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final c = list[i];
                      return Card(
                        child: ListTile(
                          onTap: () => _openForm(c),
                          leading: const CircleAvatar(child: Icon(Icons.person)),
                          title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text([
                            if (c.phone != null) c.phone!,
                            if (c.wilaya != null) c.wilaya!,
                          ].join('  •  ')),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(ref.tr('balance'), style: const TextStyle(fontSize: 11)),
                              Text(dzd(c.balance),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: c.balance > 0 ? Colors.red : Colors.green.shade700,
                                  )),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

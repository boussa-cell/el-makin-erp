import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/local/local_db.dart';
import '../../../core/sync/net.dart';
import '../domain/customer.dart';

class CustomerRepository {
  final _db = Supabase.instance.client;

  Future<List<Customer>> list({String q = ''}) => withNetwork(
        () async {
          var query = _db.from('customers').select().isFilter('deleted_at', null);
          final s = q.trim().replaceAll(RegExp(r'[,()%]'), '');
          if (s.isNotEmpty) {
            query = query.or('name.ilike.%$s%,phone.ilike.%$s%');
          }
          final rows = await query.order('name').limit(200);
          return rows.map(Customer.fromMap).toList();
        },
        () async => (await CustomerCache.search(q)).map(Customer.fromMap).toList(),
      );

  /// بدون إنترنت: يُحفظ محليًا ويُرسل تلقائيًا لاحقًا (المعرّف يُنشأ من الجهاز).
  Future<void> save(Customer c) async {
    final id = c.id ?? const Uuid().v4();
    final map = {...c.toMap(), 'id': id};
    await withNetwork<void>(
      () => _db.from('customers').upsert(map),
      () async => Outbox.add('upsert_customer', map).then((_) {}),
    );
    await CustomerCache.upsert({'balance': c.balance, ...map});
  }
}

final customerRepoProvider = Provider((_) => CustomerRepository());

final customersProvider = FutureProvider.autoDispose.family<List<Customer>, String>(
  (ref, q) => ref.read(customerRepoProvider).list(q: q),
);

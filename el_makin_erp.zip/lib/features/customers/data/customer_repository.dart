import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/local/local_db.dart';
import '../../../core/sync/net.dart';
import '../domain/customer.dart';

class CustomerRepository {
  final _db = Supabase.instance.client;

  Future<List<Customer>> list({String q = ''}) async {
    try {
      var query = _db.from('customers').select().isFilter('deleted_at', null);
      final s = q.trim().replaceAll(RegExp(r'[,()%]'), '');
      if (s.isNotEmpty) {
        query = query.or('name.ilike.%$s%,phone.ilike.%$s%');
      }
      final rows = await query.order('name').limit(200).timeout(netTimeout);
      return rows.map(Customer.fromMap).toList();
    } catch (e) {
      if (!isNetworkError(e)) rethrow;
      final rows = await CustomerCache.search(q);
      return rows.map(Customer.fromMap).toList();
    }
  }

  /// بدون إنترنت: يُحفظ محليًا ويُرسل تلقائيًا لاحقًا (المعرّف يُنشأ من الجهاز).
  Future<void> save(Customer c) async {
    final id = c.id ?? const Uuid().v4();
    final map = {...c.toMap(), 'id': id};
    try {
      await _db.from('customers').upsert(map).timeout(netTimeout);
    } catch (e) {
      if (!isNetworkError(e)) rethrow;
      await Outbox.add('upsert_customer', map);
    }
    await CustomerCache.upsert({'balance': c.balance, ...map});
  }
}

final customerRepoProvider = Provider((_) => CustomerRepository());

final customersProvider = FutureProvider.autoDispose.family<List<Customer>, String>(
  (ref, q) => ref.read(customerRepoProvider).list(q: q),
);

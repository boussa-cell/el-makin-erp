import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../domain/customer.dart';

class CustomerRepository {
  final _db = Supabase.instance.client;

  Future<List<Customer>> list({String q = ''}) async {
    var query = _db.from('customers').select().isFilter('deleted_at', null);
    final s = q.trim().replaceAll(RegExp(r'[,()%]'), '');
    if (s.isNotEmpty) {
      query = query.or('name.ilike.%$s%,phone.ilike.%$s%');
    }
    final rows = await query.order('name').limit(200);
    return rows.map(Customer.fromMap).toList();
  }

  Future<void> save(Customer c) => _db.from('customers').upsert(c.toMap());
}

final customerRepoProvider = Provider((_) => CustomerRepository());

final customersProvider = FutureProvider.autoDispose.family<List<Customer>, String>(
  (ref, q) => ref.read(customerRepoProvider).list(q: q),
);

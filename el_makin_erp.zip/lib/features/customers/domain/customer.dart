class Customer {
  final String? id;
  final String name;
  final String? phone;
  final String? address;
  final String? wilaya;
  final String? shippingCenter;
  final String? notes;
  final double balance;

  const Customer({
    this.id,
    required this.name,
    this.phone,
    this.address,
    this.wilaya,
    this.shippingCenter,
    this.notes,
    this.balance = 0,
  });

  factory Customer.fromMap(Map<String, dynamic> m) => Customer(
        id: m['id'] as String?,
        name: m['name'] as String,
        phone: m['phone'] as String?,
        address: m['address'] as String?,
        wilaya: m['wilaya'] as String?,
        shippingCenter: m['shipping_center'] as String?,
        notes: m['notes'] as String?,
        balance: ((m['balance'] ?? 0) as num).toDouble(),
      );

  static String? _n(String? v) => (v == null || v.trim().isEmpty) ? null : v.trim();

  // لا نرسل الرصيد: يتغير فقط عبر عمليات البيع والدفع
  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name': name.trim(),
        'phone': _n(phone),
        'address': _n(address),
        'wilaya': _n(wilaya),
        'shipping_center': _n(shippingCenter),
        'notes': _n(notes),
      };
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/auth/role_provider.dart';
import '../../../core/l10n/strings.dart';

/// حسابي: الاسم والصلاحية وتغيير كلمة المرور.
class AccountScreen extends ConsumerStatefulWidget {
  const AccountScreen({super.key});

  @override
  ConsumerState<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends ConsumerState<AccountScreen> {
  final _pass = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _pass.dispose();
    super.dispose();
  }

  void _msg(String t) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  Future<void> _change() async {
    if (_pass.text.length < 6) return _msg(ref.tr('weak_password'));
    setState(() => _busy = true);
    try {
      await Supabase.instance.client.auth.updateUser(UserAttributes(password: _pass.text));
      _pass.clear();
      _msg(ref.tr('password_changed'));
    } on AuthException catch (e) {
      _msg(e.message);
    } catch (e) {
      _msg('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final name = ref.watch(userNameProvider).value ?? '';
    final role = ref.watch(roleProvider).value ?? 'vendeur';
    final email = Supabase.instance.client.auth.currentUser?.email ?? '';

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('my_account'))),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person)),
                title: Text(name.isEmpty ? email : name,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('$email\n${ref.tr('role_$role')}'),
                isThreeLine: true,
              ),
            ),
            const SizedBox(height: 16),
            Text(ref.tr('change_password'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            TextField(
              controller: _pass,
              obscureText: true,
              decoration: InputDecoration(labelText: ref.tr('new_password')),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _busy ? null : _change,
              child: Text(ref.tr('save')),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../data/expenses_repository.dart';

const _categories = ['rent', 'electricity', 'transport', 'salaries', 'other'];

class ExpensesScreen extends ConsumerWidget {
  const ExpensesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final expenses = ref.watch(expensesProvider);
    final df = DateFormat('yyyy-MM-dd');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('expenses'))),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            final ok = await showModalBottomSheet<bool>(
              context: context,
              isScrollControlled: true,
              builder: (_) => const _ExpenseForm(),
            );
            if (ok == true) ref.invalidate(expensesProvider);
          },
          icon: const Icon(Icons.add),
          label: Text(ref.tr('add_expense')),
        ),
        body: expenses.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) {
            if (list.isEmpty) return Center(child: Text(ref.tr('no_expenses')));
            final total = list.fold(0.0, (s, e) => s + e.amount);
            return ListView(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              children: [
                Card(
                  child: ListTile(
                    title: Text(ref.tr('expenses_total')),
                    trailing: Text(dzd(total),
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                  ),
                ),
                for (final e in list)
                  Card(
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.payments_outlined)),
                      title: Text(ref.tr('exp_${e.category}'),
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${df.format(e.date)}${(e.note ?? '').isEmpty ? '' : '\n${e.note}'}'),
                      isThreeLine: (e.note ?? '').isNotEmpty,
                      trailing: Text(dzd(e.amount),
                          style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.red)),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ExpenseForm extends ConsumerStatefulWidget {
  const _ExpenseForm();

  @override
  ConsumerState<_ExpenseForm> createState() => _ExpenseFormState();
}

class _ExpenseFormState extends ConsumerState<_ExpenseForm> {
  final String _id = const Uuid().v4();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  String _category = 'other';
  DateTime _date = DateTime.now();
  bool _saving = false;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) setState(() => _date = d);
  }

  Future<void> _save() async {
    final v = double.tryParse(_amount.text.replaceAll(',', '.')) ?? 0;
    if (v <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ref.tr('required'))));
      return;
    }
    setState(() => _saving = true);
    try {
      await ref.read(expensesRepoProvider).add(
            id: _id,
            category: _category,
            amount: v,
            note: _note.text,
            dateIso: DateFormat('yyyy-MM-dd').format(_date),
          );
      if (mounted) Navigator.of(context).pop(true);
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(ref.tr('add_expense'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: InputDecoration(labelText: ref.tr('category')),
                items: [
                  for (final c in _categories)
                    DropdownMenuItem(value: c, child: Text(ref.tr('exp_$c'))),
                ],
                onChanged: (v) => setState(() => _category = v ?? 'other'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _amount,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: ref.tr('amount')),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                onPressed: _pickDate,
                icon: const Icon(Icons.calendar_today),
                label: Text('${ref.tr('date')}: ${DateFormat('yyyy-MM-dd').format(_date)}'),
              ),
              const SizedBox(height: 12),
              TextField(controller: _note, decoration: InputDecoration(labelText: ref.tr('note'))),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: Text(ref.tr('save')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

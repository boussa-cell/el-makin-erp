import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Expense {
  final String id;
  final String category;
  final double amount;
  final String? note;
  final DateTime date;

  const Expense({
    required this.id,
    required this.category,
    required this.amount,
    this.note,
    required this.date,
  });

  factory Expense.fromMap(Map<String, dynamic> m) => Expense(
        id: m['id'] as String,
        category: m['category'] as String,
        amount: (m['amount'] as num).toDouble(),
        note: m['note'] as String?,
        date: DateTime.parse(m['expense_date'] as String),
      );
}

class ExpensesRepository {
  final _db = Supabase.instance.client;

  Future<List<Expense>> list() async {
    final rows = await _db
        .from('expenses')
        .select()
        .order('expense_date', ascending: false)
        .order('created_at', ascending: false)
        .limit(200);
    return rows.map(Expense.fromMap).toList();
  }

  Future<void> add({
    required String id,
    required String category,
    required double amount,
    String? note,
    required String dateIso, // yyyy-MM-dd
  }) async {
    await _db.from('expenses').insert({
      'id': id,
      'category': category,
      'amount': amount,
      'note': (note == null || note.trim().isEmpty) ? null : note.trim(),
      'expense_date': dateIso,
    });
  }
}

final expensesRepoProvider = Provider((_) => ExpensesRepository());

final expensesProvider = FutureProvider.autoDispose<List<Expense>>(
  (ref) => ref.read(expensesRepoProvider).list(),
);

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Category {
  final String? id;
  final String nameAr;
  final String? nameFr;
  const Category({this.id, required this.nameAr, this.nameFr});

  factory Category.fromMap(Map<String, dynamic> m) => Category(
        id: m['id'] as String?,
        nameAr: m['name_ar'] as String,
        nameFr: m['name_fr'] as String?,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name_ar': nameAr.trim(),
        'name_fr': (nameFr == null || nameFr!.trim().isEmpty) ? null : nameFr!.trim(),
      };
}

class Brand {
  final String? id;
  final String name;
  const Brand({this.id, required this.name});

  factory Brand.fromMap(Map<String, dynamic> m) =>
      Brand(id: m['id'] as String?, name: m['name'] as String);

  Map<String, dynamic> toMap() => {if (id != null) 'id': id, 'name': name.trim()};
}

class CatalogRepository {
  final _db = Supabase.instance.client;

  Future<List<Category>> categories() async {
    final rows = await _db.from('categories').select().isFilter('deleted_at', null).order('name_ar');
    return rows.map(Category.fromMap).toList();
  }

  Future<List<Brand>> brands() async {
    final rows = await _db.from('brands').select().isFilter('deleted_at', null).order('name');
    return rows.map(Brand.fromMap).toList();
  }

  Future<void> saveCategory(Category c) => _db.from('categories').upsert(c.toMap());
  Future<void> saveBrand(Brand b) => _db.from('brands').upsert(b.toMap());

  Future<void> deleteCategory(String id) => _db
      .from('categories')
      .update({'deleted_at': DateTime.now().toUtc().toIso8601String()}).eq('id', id);

  Future<void> deleteBrand(String id) => _db
      .from('brands')
      .update({'deleted_at': DateTime.now().toUtc().toIso8601String()}).eq('id', id);
}

final catalogRepoProvider = Provider((_) => CatalogRepository());

final categoriesProvider = FutureProvider.autoDispose<List<Category>>(
  (ref) => ref.read(catalogRepoProvider).categories(),
);

final brandsProvider = FutureProvider.autoDispose<List<Brand>>(
  (ref) => ref.read(catalogRepoProvider).brands(),
);

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../data/catalog_repository.dart';

/// إدارة التصنيفات والماركات (تبويبان).
class CatalogScreen extends ConsumerWidget {
  const CatalogScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text(ref.tr('categories_brands')),
            bottom: TabBar(
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              indicatorColor: Colors.white,
              tabs: [Tab(text: ref.tr('categories')), Tab(text: ref.tr('brands'))],
            ),
          ),
          body: const TabBarView(children: [_CategoriesTab(), _BrandsTab()]),
        ),
      ),
    );
  }
}

Future<String?> _askText(BuildContext context, WidgetRef ref, String title,
    {String initial = '', String? initial2, String? label2}) async {
  // يعيد "النص الأول" أو "النص الأول|||النص الثاني" إن وُجد حقل ثانٍ
  final c1 = TextEditingController(text: initial);
  final c2 = TextEditingController(text: initial2 ?? '');
  final ok = await showDialog<bool>(
    context: context,
    builder: (_) => Directionality(
      textDirection: ref.read(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: c1, decoration: InputDecoration(labelText: ref.tr('name'))),
            if (label2 != null) ...[
              const SizedBox(height: 12),
              TextField(controller: c2, decoration: InputDecoration(labelText: label2)),
            ],
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(false), child: Text(ref.tr('cancel'))),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(ref.tr('save')),
          ),
        ],
      ),
    ),
  );
  final a = c1.text.trim();
  final b = c2.text.trim();
  c1.dispose();
  c2.dispose();
  if (ok != true || a.isEmpty) return null;
  return label2 == null ? a : '$a|||$b';
}

class _CategoriesTab extends ConsumerWidget {
  const _CategoriesTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(categoriesProvider);
    final repo = ref.read(catalogRepoProvider);

    Future<void> edit([Category? c]) async {
      final r = await _askText(context, ref, ref.tr(c == null ? 'add_category' : 'edit'),
          initial: c?.nameAr ?? '', initial2: c?.nameFr, label2: ref.tr('name_fr'));
      if (r == null) return;
      final parts = r.split('|||');
      try {
        await repo.saveCategory(Category(id: c?.id, nameAr: parts[0], nameFr: parts.length > 1 ? parts[1] : null));
        ref.invalidate(categoriesProvider);
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
        }
      }
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'cat_fab',
        onPressed: () => edit(),
        icon: const Icon(Icons.add),
        label: Text(ref.tr('add_category')),
      ),
      body: data.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
        data: (list) {
          if (list.isEmpty) return Center(child: Text(ref.tr('no_items')));
          return ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            children: [
              for (final c in list)
                Card(
                  child: ListTile(
                    onTap: () => edit(c),
                    title: Text(c.nameAr, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: (c.nameFr ?? '').isEmpty ? null : Text(c.nameFr!),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await repo.deleteCategory(c.id!);
                        ref.invalidate(categoriesProvider);
                      },
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _BrandsTab extends ConsumerWidget {
  const _BrandsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(brandsProvider);
    final repo = ref.read(catalogRepoProvider);

    Future<void> edit([Brand? b]) async {
      final r = await _askText(context, ref, ref.tr(b == null ? 'add_brand' : 'edit'),
          initial: b?.name ?? '');
      if (r == null) return;
      try {
        await repo.saveBrand(Brand(id: b?.id, name: r));
        ref.invalidate(brandsProvider);
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
        }
      }
    }

    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'brand_fab',
        onPressed: () => edit(),
        icon: const Icon(Icons.add),
        label: Text(ref.tr('add_brand')),
      ),
      body: data.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
        data: (list) {
          if (list.isEmpty) return Center(child: Text(ref.tr('no_items')));
          return ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            children: [
              for (final b in list)
                Card(
                  child: ListTile(
                    onTap: () => edit(b),
                    title: Text(b.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await repo.deleteBrand(b.id!);
                        ref.invalidate(brandsProvider);
                      },
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

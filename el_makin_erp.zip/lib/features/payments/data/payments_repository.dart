import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StatementEntry {
  final DateTime date;
  final bool isPayment;
  final String title;
  final String? note;
  final double total;
  final double paid;
  final double delta; // التغير في الرصيد: موجب = دين جديد، سالب = تسديد

  const StatementEntry({
    required this.date,
    required this.isPayment,
    required this.title,
    this.note,
    this.total = 0,
    this.paid = 0,
    required this.delta,
  });
}

class PaymentsRepository {
  final _db = Supabase.instance.client;

  /// kind = 'customer' أو 'supplier'. نفس id عند إعادة المحاولة لا يكرر التسديد.
  Future<void> record({
    required String id,
    required String kind,
    required String partyId,
    required double amount,
    String? note,
  }) async {
    await _db.rpc('record_payment', params: {
      'p_id': id,
      'p_kind': kind,
      'p_party_id': partyId,
      'p_amount': amount,
      'p_note': (note == null || note.trim().isEmpty) ? null : note.trim(),
    });
  }

  Future<double> balance(String kind, String id) async {
    final table = kind == 'customer' ? 'customers' : 'suppliers';
    final row = await _db.from(table).select('balance').eq('id', id).single();
    return ((row['balance'] ?? 0) as num).toDouble();
  }

  Future<List<StatementEntry>> statement(String kind, String id) async {
    final isC = kind == 'customer';
    final col = isC ? 'customer_id' : 'supplier_id';
    final docs = await _db
        .from(isC ? 'sales' : 'purchases')
        .select('invoice_no, total, paid, remaining, created_at')
        .eq(col, id);
    final pays = await _db.from('payments').select('amount, note, created_at').eq(col, id);

    final list = <StatementEntry>[
      for (final d in docs)
        StatementEntry(
          date: DateTime.parse(d['created_at'] as String).toLocal(),
          isPayment: false,
          title: d['invoice_no'] as String,
          total: (d['total'] as num).toDouble(),
          paid: (d['paid'] as num).toDouble(),
          delta: (d['remaining'] as num).toDouble(),
        ),
      for (final p in pays)
        StatementEntry(
          date: DateTime.parse(p['created_at'] as String).toLocal(),
          isPayment: true,
          title: '',
          note: p['note'] as String?,
          delta: -(p['amount'] as num).toDouble(),
        ),
    ];
    list.sort((a, b) => b.date.compareTo(a.date));
    return list;
  }
}

final paymentsRepoProvider = Provider((_) => PaymentsRepository());

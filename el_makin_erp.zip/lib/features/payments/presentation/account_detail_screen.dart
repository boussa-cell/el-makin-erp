import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../data/payments_repository.dart';
import 'payment_dialog.dart';

/// شاشة حساب عميل أو مورد: الرصيد + التسديد + كشف الحساب.
class AccountDetailScreen extends ConsumerStatefulWidget {
  final String kind; // 'customer' | 'supplier'
  final String partyId;
  final String name;
  final Future<void> Function()? onEdit;

  const AccountDetailScreen({
    super.key,
    required this.kind,
    required this.partyId,
    required this.name,
    this.onEdit,
  });

  @override
  ConsumerState<AccountDetailScreen> createState() => _AccountDetailScreenState();
}

class _AccountDetailScreenState extends ConsumerState<AccountDetailScreen> {
  late Future<double> _balance;
  late Future<List<StatementEntry>> _statement;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final repo = ref.read(paymentsRepoProvider);
    _balance = repo.balance(widget.kind, widget.partyId);
    _statement = repo.statement(widget.kind, widget.partyId);
  }

  Future<void> _pay(double balance) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => PaymentDialog(
        kind: widget.kind,
        partyId: widget.partyId,
        partyName: widget.name,
        balance: balance,
      ),
    );
    if (ok == true) setState(_load);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.name)),
        body: Column(
          children: [
            FutureBuilder<double>(
              future: _balance,
              builder: (context, snap) {
                final bal = snap.data ?? 0;
                return Card(
                  margin: const EdgeInsets.all(12),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Text(ref.tr('balance')),
                        const SizedBox(height: 4),
                        Text(
                          snap.hasData ? dzd(bal) : '...',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                            color: bal > 0 ? Colors.red : Colors.green.shade700,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: bal > 0 ? () => _pay(bal) : null,
                                icon: const Icon(Icons.payments_outlined),
                                label: Text(ref.tr('pay')),
                              ),
                            ),
                            if (widget.onEdit != null) ...[
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton.icon(
                                  style: OutlinedButton.styleFrom(
                                      minimumSize: const Size.fromHeight(52)),
                                  onPressed: () async {
                                    await widget.onEdit!();
                                    if (mounted) setState(_load);
                                  },
                                  icon: const Icon(Icons.edit_outlined),
                                  label: Text(ref.tr('edit')),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: Text(ref.tr('statement'),
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ),
            ),
            Expanded(
              child: FutureBuilder<List<StatementEntry>>(
                future: _statement,
                builder: (context, snap) {
                  if (snap.hasError) return Center(child: Text('${snap.error}'));
                  if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                  final list = snap.data!;
                  if (list.isEmpty) return Center(child: Text(ref.tr('no_entries')));
                  return ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: list.length,
                    itemBuilder: (_, i) {
                      final e = list[i];
                      return Card(
                        child: ListTile(
                          leading: Icon(
                            e.isPayment ? Icons.south_west : Icons.receipt_long,
                            color: e.isPayment ? Colors.green.shade700 : Colors.orange.shade800,
                          ),
                          title: Text(e.isPayment ? ref.tr('payment') : e.title,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(e.isPayment
                              ? '${df.format(e.date)}${(e.note ?? '').isEmpty ? '' : '\n${e.note}'}'
                              : '${df.format(e.date)}\n${ref.tr('total')}: ${dzd(e.total)}  •  ${ref.tr('paid')}: ${dzd(e.paid)}'),
                          isThreeLine: true,
                          trailing: Text(
                            '${e.delta > 0 ? '+' : ''}${dzd(e.delta)}',
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              color: e.delta > 0
                                  ? Colors.red
                                  : (e.delta < 0 ? Colors.green.shade700 : Colors.grey),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

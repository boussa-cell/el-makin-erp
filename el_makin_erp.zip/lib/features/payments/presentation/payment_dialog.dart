import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../data/payments_repository.dart';

class PaymentDialog extends ConsumerStatefulWidget {
  final String kind;
  final String partyId;
  final String partyName;
  final double balance;

  const PaymentDialog({
    super.key,
    required this.kind,
    required this.partyId,
    required this.partyName,
    required this.balance,
  });

  @override
  ConsumerState<PaymentDialog> createState() => _PaymentDialogState();
}

class _PaymentDialogState extends ConsumerState<PaymentDialog> {
  final String _paymentId = const Uuid().v4();
  late final TextEditingController _amount =
      TextEditingController(text: widget.balance.toStringAsFixed(2));
  final _note = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _confirm() async {
    final v = double.tryParse(_amount.text.replaceAll(',', '.')) ?? 0;
    if (v <= 0 || v > widget.balance + 0.001) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ref.tr('invalid_paid'))));
      return;
    }
    setState(() => _saving = true);
    try {
      await ref.read(paymentsRepoProvider).record(
            id: _paymentId,
            kind: widget.kind,
            partyId: widget.partyId,
            amount: v,
            note: _note.text,
          );
      if (mounted) Navigator.of(context).pop(true);
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: AlertDialog(
        title: Text('${ref.tr('pay')} - ${widget.partyName}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${ref.tr('balance')}: ${dzd(widget.balance)}'),
            const SizedBox(height: 12),
            TextField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: ref.tr('amount')),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _note,
              decoration: InputDecoration(labelText: ref.tr('note')),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: _saving ? null : () => Navigator.of(context).pop(false),
            child: Text(ref.tr('cancel')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
            onPressed: _saving ? null : _confirm,
            child: Text(ref.tr('pay')),
          ),
        ],
      ),
    );
  }
}

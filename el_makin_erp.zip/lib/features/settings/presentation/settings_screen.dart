import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../data/settings_repository.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _footer = TextEditingController();
  final _whatsapp = TextEditingController();
  final _messenger = TextEditingController();
  final _email = TextEditingController();
  String _lang = 'ar';
  String _paper = 'a4';
  bool _showQr = true;
  bool _loaded = false;
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    _footer.dispose();
    _whatsapp.dispose();
    _messenger.dispose();
    _email.dispose();
    super.dispose();
  }

  void _fill(ShopSettings s) {
    _name.text = s.shopName;
    _phone.text = s.phone;
    _address.text = s.address;
    _footer.text = s.footer;
    _whatsapp.text = s.whatsapp;
    _messenger.text = s.messenger;
    _email.text = s.contactEmail;
    _lang = s.invoiceLang;
    _paper = s.paper;
    _showQr = s.showQr;
    _loaded = true;
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await ref.read(settingsRepoProvider).save(ShopSettings(
            shopName: _name.text.trim().isEmpty ? 'EL MAKIN' : _name.text.trim(),
            phone: _phone.text.trim(),
            address: _address.text.trim(),
            footer: _footer.text.trim(),
            whatsapp: _whatsapp.text.replaceAll(RegExp(r'\D'), ''),
            messenger: _messenger.text.trim(),
            contactEmail: _email.text.trim(),
            invoiceLang: _lang,
            paper: _paper,
            showQr: _showQr,
          ));
      ref.invalidate(settingsProvider);
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ref.tr('saved'))));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final settings = ref.watch(settingsProvider);

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('settings'))),
        body: settings.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (s) {
            if (!_loaded) _fill(s);
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                TextField(
                    controller: _name, decoration: InputDecoration(labelText: ref.tr('shop_name'))),
                const SizedBox(height: 12),
                TextField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(labelText: ref.tr('phone')),
                ),
                const SizedBox(height: 12),
                TextField(
                    controller: _address, decoration: InputDecoration(labelText: ref.tr('address'))),
                const SizedBox(height: 12),
                TextField(
                    controller: _footer,
                    maxLines: 2,
                    decoration: InputDecoration(labelText: ref.tr('footer_text'))),
                const SizedBox(height: 12),
                TextField(
                  controller: _whatsapp,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(labelText: ref.tr('whatsapp_number')),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _messenger,
                  decoration: InputDecoration(labelText: ref.tr('messenger_page')),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(labelText: ref.tr('contact_email')),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _lang,
                  decoration: InputDecoration(labelText: ref.tr('invoice_lang')),
                  items: [
                    DropdownMenuItem(value: 'ar', child: Text(ref.tr('arabic'))),
                    DropdownMenuItem(value: 'fr', child: Text(ref.tr('french'))),
                  ],
                  onChanged: (v) => setState(() => _lang = v ?? 'ar'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _paper,
                  decoration: InputDecoration(labelText: ref.tr('paper')),
                  items: [
                    DropdownMenuItem(value: 'a4', child: Text(ref.tr('paper_a4'))),
                    DropdownMenuItem(value: 'thermal', child: Text(ref.tr('paper_thermal'))),
                  ],
                  onChanged: (v) => setState(() => _paper = v ?? 'a4'),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(ref.tr('show_qr')),
                  value: _showQr,
                  onChanged: (v) => setState(() => _showQr = v),
                ),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: _saving ? null : _save,
                  child: Text(ref.tr('save')),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

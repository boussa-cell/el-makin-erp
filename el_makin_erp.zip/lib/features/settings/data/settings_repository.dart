import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/local/local_db.dart';
import '../../../core/sync/net.dart';

class ShopSettings {
  final String shopName;
  final String phone;
  final String address;
  final String footer;
  final String invoiceLang; // ar | fr
  final String paper; // a4 | thermal
  final bool showQr;
  final String whatsapp; // رقم دولي بدون +
  final String messenger; // اسم صفحة ماسنجر
  final String contactEmail; // بريد استقبال رسائل وطلبات الموقع

  const ShopSettings({
    this.shopName = 'EL MAKIN',
    this.phone = '',
    this.address = '',
    this.footer = 'شكرًا لتعاملكم معنا',
    this.invoiceLang = 'ar',
    this.paper = 'a4',
    this.showQr = true,
    this.whatsapp = '',
    this.messenger = '',
    this.contactEmail = '',
  });

  factory ShopSettings.fromMap(Map<String, String> m) => ShopSettings(
        shopName: m['shop_name'] ?? 'EL MAKIN',
        phone: m['phone'] ?? '',
        address: m['address'] ?? '',
        footer: m['footer'] ?? '',
        invoiceLang: m['invoice_lang'] ?? 'ar',
        paper: m['paper'] ?? 'a4',
        showQr: (m['show_qr'] ?? '1') == '1',
        whatsapp: m['whatsapp'] ?? '',
        messenger: m['messenger'] ?? '',
        contactEmail: m['contact_email'] ?? '',
      );

  Map<String, String> toMap() => {
        'shop_name': shopName,
        'phone': phone,
        'address': address,
        'footer': footer,
        'invoice_lang': invoiceLang,
        'paper': paper,
        'show_qr': showQr ? '1' : '0',
        'whatsapp': whatsapp,
        'messenger': messenger,
        'contact_email': contactEmail,
      };
}

class SettingsRepository {
  final _db = Supabase.instance.client;

  Future<ShopSettings> load() => withNetwork<ShopSettings>(
        () async {
          final rows = await _db.from('settings').select('key, value');
          final m = {for (final r in rows) r['key'] as String: (r['value'] as String?) ?? ''};
          await LocalKv.set('settings', jsonEncode(m));
          return ShopSettings.fromMap(m);
        },
        () async {
          final cached = await LocalKv.get('settings');
          if (cached == null) return const ShopSettings();
          final m = (jsonDecode(cached) as Map).map((k, v) => MapEntry('$k', '$v'));
          return ShopSettings.fromMap(m);
        },
      );

  Future<void> save(ShopSettings s) async {
    await _db.from('settings').upsert([
      for (final e in s.toMap().entries) {'key': e.key, 'value': e.value},
    ]);
  }
}

final settingsRepoProvider = Provider((_) => SettingsRepository());

final settingsProvider =
    FutureProvider.autoDispose<ShopSettings>((ref) => ref.read(settingsRepoProvider).load());

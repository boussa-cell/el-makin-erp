import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../data/orders_repository.dart';
import 'order_detail_screen.dart';

Color statusColor(String s) {
  switch (s) {
    case 'confirmed':
      return Colors.blue;
    case 'shipped':
      return Colors.orange.shade800;
    case 'delivered':
      return Colors.green.shade700;
    case 'cancelled':
      return Colors.red;
    default:
      return Colors.indigo;
  }
}

class OrdersScreen extends ConsumerStatefulWidget {
  const OrdersScreen({super.key});

  @override
  ConsumerState<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends ConsumerState<OrdersScreen> {
  String _status = '';

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final orders = ref.watch(ordersProvider(_status));
    final df = DateFormat('yyyy-MM-dd HH:mm');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('orders'))),
        body: Column(
          children: [
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                children: [
                  for (final s in ['', ...orderStatuses])
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(
                        label: Text(s.isEmpty ? ref.tr('all') : ref.tr('st_$s')),
                        selected: _status == s,
                        onSelected: (_) => setState(() => _status = s),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(
              child: orders.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
                data: (list) {
                  if (list.isEmpty) return Center(child: Text(ref.tr('no_orders')));
                  return RefreshIndicator(
                    onRefresh: () async => ref.invalidate(ordersProvider),
                    child: ListView.builder(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final o = list[i];
                        return Card(
                          child: ListTile(
                            onTap: () async {
                              await Navigator.of(context).push(MaterialPageRoute(
                                builder: (_) => OrderDetailScreen(order: o),
                              ));
                              ref.invalidate(ordersProvider);
                            },
                            title: Text('${o.orderNo}  •  ${o.name}',
                                style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text(
                                '${o.wilaya ?? ''}\n${df.format(o.createdAt)}'),
                            isThreeLine: true,
                            trailing: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(dzd(o.total),
                                    style: const TextStyle(fontWeight: FontWeight.w800)),
                                Text(ref.tr('st_${o.status}'),
                                    style: TextStyle(
                                        color: statusColor(o.status), fontWeight: FontWeight.w700)),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/contact_links.dart';
import '../../../core/utils/money.dart';
import '../data/orders_repository.dart';
import 'orders_screen.dart';

class OrderDetailScreen extends ConsumerStatefulWidget {
  final OrderRow order;
  const OrderDetailScreen({super.key, required this.order});

  @override
  ConsumerState<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends ConsumerState<OrderDetailScreen> {
  late String _status = widget.order.status;
  late String? _saleId = widget.order.saleId;
  late Future<List<OrderItemRow>> _items;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _items = ref.read(ordersRepoProvider).items(widget.order.id);
  }

  void _msg(String t) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  String _err(Object e) {
    if (e is PostgrestException) return e.message;
    final s = '$e';
    return s.contains('need_online') ? ref.tr('need_online') : s;
  }

  Future<void> _setStatus(String s) async {
    setState(() => _busy = true);
    try {
      await ref.read(ordersRepoProvider).setStatus(widget.order.id, s);
      setState(() => _status = s);
    } catch (e) {
      _msg(_err(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _convert(List<OrderItemRow> items) async {
    final c = TextEditingController(text: '0');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ref.read(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: AlertDialog(
          title: Text(ref.tr('convert_invoice')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(ref.tr('convert_hint')),
              const SizedBox(height: 12),
              TextField(
                controller: c,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: ref.tr('paid')),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false), child: Text(ref.tr('cancel'))),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
              onPressed: () => Navigator.of(context).pop(true),
              child: Text(ref.tr('confirm')),
            ),
          ],
        ),
      ),
    );
    final paid = double.tryParse(c.text.replaceAll(',', '.')) ?? 0;
    c.dispose();
    if (ok != true) return;

    setState(() => _busy = true);
    try {
      await ref.read(ordersRepoProvider).convertToInvoice(widget.order, items, paid);
      setState(() {
        _saleId = widget.order.id;
        if (_status == 'new') _status = 'confirmed';
      });
      _msg(ref.tr('invoiced'));
    } catch (e) {
      _msg(_err(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final o = widget.order;

    Widget row(String k, String? v) => (v == null || v.isEmpty)
        ? const SizedBox.shrink()
        : Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(width: 110, child: Text(k, style: const TextStyle(color: Colors.black54))),
                Expanded(child: Text(v, style: const TextStyle(fontWeight: FontWeight.w600))),
              ],
            ),
          );

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(o.orderNo)),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(ref.tr('customer_info'),
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 8),
                    row(ref.tr('name'), o.name),
                    row(ref.tr('phone'), o.phone),
                    row(ref.tr('wilaya'), o.wilaya),
                    row(ref.tr('address'), o.address),
                    row(ref.tr('shipping_center'), o.center),
                    row(ref.tr('note'), o.note),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                            onPressed: () => callPhone(o.phone),
                            icon: const Icon(Icons.call),
                            label: Text(ref.tr('call')),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                            onPressed: () => openWhatsApp(
                                o.phone, '${o.orderNo}\n${ref.tr('total')}: ${dzd(o.total)}'),
                            icon: const Icon(Icons.chat),
                            label: Text(ref.tr('whatsapp')),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            FutureBuilder<List<OrderItemRow>>(
              future: _items,
              builder: (context, snap) {
                if (snap.hasError) return Text('${ref.tr('error')}\n${snap.error}');
                if (!snap.hasData) return const LinearProgressIndicator();
                final items = snap.data!;
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Card(
                      child: Column(
                        children: [
                          for (final i in items)
                            ListTile(
                              dense: true,
                              title: Text(i.name),
                              subtitle: Text('${i.qty} × ${dzd(i.price)}'),
                              trailing: Text(dzd(i.total),
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                            ),
                          const Divider(height: 1),
                          ListTile(
                            title: Text(ref.tr('total')),
                            trailing: Text(dzd(o.total),
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: _status,
                      decoration: InputDecoration(labelText: ref.tr('status_label')),
                      items: [
                        for (final s in orderStatuses)
                          DropdownMenuItem(
                            value: s,
                            child: Text(ref.tr('st_$s'), style: TextStyle(color: statusColor(s))),
                          ),
                      ],
                      onChanged: _busy ? null : (v) => v == null ? null : _setStatus(v),
                    ),
                    const SizedBox(height: 12),
                    if (_saleId != null)
                      Card(
                        color: const Color(0xFFE3F6E8),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text('✅ ${ref.tr('invoiced')}'),
                        ),
                      )
                    else if (_status != 'cancelled')
                      FilledButton.icon(
                        onPressed: _busy ? null : () => _convert(items),
                        icon: const Icon(Icons.receipt_long),
                        label: Text(ref.tr('convert_invoice')),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

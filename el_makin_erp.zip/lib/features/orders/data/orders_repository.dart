import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/sync/net.dart';
import '../../products/domain/product.dart';
import '../../sales/data/sales_repository.dart';

const orderStatuses = ['new', 'confirmed', 'shipped', 'delivered', 'cancelled'];

class OrderRow {
  final String id;
  final String orderNo;
  final String name;
  final String phone;
  final String? wilaya;
  final String? address;
  final String? center;
  final String? note;
  final String status;
  final double total;
  final DateTime createdAt;
  final String? saleId;

  const OrderRow({
    required this.id,
    required this.orderNo,
    required this.name,
    required this.phone,
    this.wilaya,
    this.address,
    this.center,
    this.note,
    required this.status,
    required this.total,
    required this.createdAt,
    this.saleId,
  });

  factory OrderRow.fromMap(Map<String, dynamic> m) => OrderRow(
        id: m['id'] as String,
        orderNo: m['order_no'] as String,
        name: m['customer_name'] as String,
        phone: m['phone'] as String,
        wilaya: m['wilaya'] as String?,
        address: m['address'] as String?,
        center: m['shipping_center'] as String?,
        note: m['note'] as String?,
        status: m['status'] as String,
        total: (m['total'] as num).toDouble(),
        createdAt: DateTime.parse(m['created_at'] as String).toLocal(),
        saleId: m['sale_id'] as String?,
      );
}

class OrderItemRow {
  final String productId;
  final String name;
  final double qty;
  final double price;
  final double total;

  const OrderItemRow({
    required this.productId,
    required this.name,
    required this.qty,
    required this.price,
    required this.total,
  });

  factory OrderItemRow.fromMap(Map<String, dynamic> m) => OrderItemRow(
        productId: m['product_id'] as String,
        name: m['product_name'] as String,
        qty: (m['qty'] as num).toDouble(),
        price: (m['unit_price'] as num).toDouble(),
        total: (m['total'] as num).toDouble(),
      );
}

class OrdersRepository {
  final _db = Supabase.instance.client;

  Future<List<OrderRow>> list({String status = ''}) async {
    var q = _db.from('orders').select();
    if (status.isNotEmpty) q = q.eq('status', status);
    final rows = await q.order('created_at', ascending: false).limit(200);
    return rows.map(OrderRow.fromMap).toList();
  }

  Future<List<OrderItemRow>> items(String orderId) async {
    final rows =
        await _db.from('order_items').select().eq('order_id', orderId).order('product_name');
    return rows.map(OrderItemRow.fromMap).toList();
  }

  Future<void> setStatus(String id, String status) async {
    final res = await _db.from('orders').update({'status': status}).eq('id', id).select();
    if (res.isEmpty) throw Exception('not allowed');
  }

  /// ينشئ (أو يجد) العميل بالهاتف ثم فاتورة بيع بسعر التجزئة بنفس معرّف الطلب
  /// (إعادة المحاولة لا تكرر الفاتورة)، ثم يربط الطلب بها.
  Future<void> convertToInvoice(OrderRow o, List<OrderItemRow> items, double paid) async {
    if (!Net.online) throw Exception('need_online');

    final existing = await _db
        .from('customers')
        .select('id')
        .eq('phone', o.phone)
        .isFilter('deleted_at', null)
        .limit(1);
    String customerId;
    if (existing.isNotEmpty) {
      customerId = existing.first['id'] as String;
    } else {
      customerId = const Uuid().v4();
      await _db.from('customers').insert({
        'id': customerId,
        'name': o.name,
        'phone': o.phone,
        'address': o.address,
        'wilaya': o.wilaya,
        'shipping_center': o.center,
      });
    }

    await SalesRepository().createSale(
      saleId: o.id,
      customerId: customerId,
      customerName: o.name,
      tier: PriceTier.retail,
      paid: paid,
      note: o.orderNo,
      items: [for (final i in items) {'product_id': i.productId, 'qty': i.qty}],
      localLines: [for (final i in items) {'name': i.name, 'qty': i.qty, 'price': i.price}],
    );

    await _db
        .from('orders')
        .update({'sale_id': o.id, if (o.status == 'new') 'status': 'confirmed'}).eq('id', o.id);
  }
}

final ordersRepoProvider = Provider((_) => OrdersRepository());

final ordersProvider = FutureProvider.autoDispose.family<List<OrderRow>, String>(
  (ref, status) => ref.read(ordersRepoProvider).list(status: status),
);

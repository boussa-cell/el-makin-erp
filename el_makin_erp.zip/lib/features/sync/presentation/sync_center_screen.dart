import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../../../core/local/local_db.dart';
import '../../../core/sync/sync_controller.dart';
import '../../../core/utils/money.dart';

class SyncCenterScreen extends ConsumerWidget {
  const SyncCenterScreen({super.key});

  String _summary(WidgetRef ref, OutboxItem it) {
    final p = it.payload;
    switch (it.op) {
      case 'create_sale':
        final l = (p['local'] as Map?) ?? const {};
        final total = (l['total'] as num?)?.toDouble();
        return '${l['invoice_no'] ?? ''}  •  ${l['customer'] ?? ref.tr('walk_in')}'
            '${total == null ? '' : '\n${ref.tr('total')}: ${dzd(total)}'}';
      case 'upsert_customer':
        return '${p['name'] ?? ''}';
      case 'record_payment':
        return '${ref.tr('amount')}: ${dzd((p['amount'] as num).toDouble())}';
      default:
        return it.op;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final items = ref.watch(outboxProvider);
    final syncing = ref.watch(syncingProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    Future<void> syncNow() => ref.read(syncControllerProvider).syncNow();

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('sync_center'))),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: FilledButton.icon(
                onPressed: syncing ? null : syncNow,
                icon: const Icon(Icons.sync),
                label: Text(syncing ? ref.tr('syncing') : ref.tr('sync_now')),
              ),
            ),
            Expanded(
              child: items.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('$e')),
                data: (list) {
                  if (list.isEmpty) return Center(child: Text(ref.tr('nothing_pending')));
                  return ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                    itemCount: list.length,
                    itemBuilder: (_, i) {
                      final it = list[i];
                      final failed = it.status == 'failed';
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(failed ? Icons.error_outline : Icons.schedule,
                                      color: failed ? Colors.red : Colors.orange.shade800),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(ref.tr('op_${it.op}'),
                                        style: const TextStyle(fontWeight: FontWeight.w800)),
                                  ),
                                  Text(ref.tr(failed ? 'status_failed' : 'status_pending'),
                                      style: TextStyle(
                                          color: failed ? Colors.red : Colors.orange.shade800,
                                          fontWeight: FontWeight.w700)),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(_summary(ref, it)),
                              Text(df.format(it.createdAt), style: const TextStyle(fontSize: 11)),
                              if (failed && (it.error ?? '').isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Text(it.error!,
                                      style: const TextStyle(color: Colors.red, fontSize: 12)),
                                ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  if (failed)
                                    TextButton.icon(
                                      onPressed: () async {
                                        await Outbox.markPending(it.id);
                                        await syncNow();
                                      },
                                      icon: const Icon(Icons.refresh),
                                      label: Text(ref.tr('retry')),
                                    ),
                                  TextButton.icon(
                                    onPressed: () async {
                                      final ok = await showDialog<bool>(
                                        context: context,
                                        builder: (_) => Directionality(
                                          textDirection:
                                              lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
                                          child: AlertDialog(
                                            content: Text(ref.tr('confirm_discard')),
                                            actions: [
                                              TextButton(
                                                onPressed: () => Navigator.of(context).pop(false),
                                                child: Text(ref.tr('cancel')),
                                              ),
                                              FilledButton(
                                                style: FilledButton.styleFrom(
                                                    minimumSize: const Size(100, 44)),
                                                onPressed: () => Navigator.of(context).pop(true),
                                                child: Text(ref.tr('discard')),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                      if (ok == true) {
                                        await Outbox.remove(it.id);
                                        await syncNow();
                                      }
                                    },
                                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                                    label: Text(ref.tr('discard'),
                                        style: const TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

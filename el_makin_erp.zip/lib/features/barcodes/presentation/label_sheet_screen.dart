import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/pdf/pdf_export.dart';
import '../../../core/utils/money.dart';
import '../../products/domain/product.dart';

/// ورقة ملصقات باركود (A4، 3 أعمدة) للمعاينة والطباعة.
class LabelSheetScreen extends ConsumerStatefulWidget {
  final List<({Product product, int copies})> items;
  final String type; // code128 | ean13 | qr

  const LabelSheetScreen({super.key, required this.items, required this.type});

  @override
  ConsumerState<LabelSheetScreen> createState() => _LabelSheetScreenState();
}

class _LabelSheetScreenState extends ConsumerState<LabelSheetScreen> {
  final _key = GlobalKey();
  bool _busy = false;

  Barcode get _barcode {
    switch (widget.type) {
      case 'ean13':
        return Barcode.ean13();
      case 'qr':
        return Barcode.qrCode();
      default:
        return Barcode.code128();
    }
  }

  Widget _label(Product p, String lang) {
    final isQr = widget.type == 'qr';
    return Container(
      width: 176,
      height: 112,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black26),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        children: [
          Text(
            p.displayName(lang),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.black),
          ),
          const SizedBox(height: 2),
          Expanded(
            child: Center(
              child: BarcodeWidget(
                barcode: _barcode,
                data: p.barcode!,
                height: isQr ? 52 : 44,
                width: isQr ? 52 : 150,
                drawText: !isQr,
                style: const TextStyle(fontSize: 9, color: Colors.black),
                errorBuilder: (context, error) => Text(
                  error,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 9, color: Colors.red),
                ),
              ),
            ),
          ),
          Text(dzd(p.retailPrice),
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.black)),
        ],
      ),
    );
  }

  Future<void> _run(bool share) async {
    setState(() => _busy = true);
    try {
      final bytes = await boundaryToPdf(_key, thermal: false);
      if (share) {
        await sharePdf(bytes, 'barcodes.pdf');
      } else {
        await printPdf(bytes, 'barcodes');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('barcode_labels'))),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(8),
                child: FittedBox(
                  fit: BoxFit.fitWidth,
                  child: RepaintBoundary(
                    key: _key,
                    child: Container(
                      width: 595,
                      color: Colors.white,
                      padding: const EdgeInsets.all(16),
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final it in widget.items)
                            for (var i = 0; i < it.copies; i++) _label(it.product, lang),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _busy ? null : () => _run(false),
                        icon: const Icon(Icons.print),
                        label: Text(ref.tr('print')),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.tonalIcon(
                        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                        onPressed: _busy ? null : () => _run(true),
                        icon: const Icon(Icons.share),
                        label: Text(ref.tr('share_pdf')),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

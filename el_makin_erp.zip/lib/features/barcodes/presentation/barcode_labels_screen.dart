import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../products/data/product_repository.dart';
import '../../products/domain/product.dart';
import 'label_sheet_screen.dart';

/// اختيار المنتجات وعدد الملصقات ونوع الباركود.
class BarcodeLabelsScreen extends ConsumerStatefulWidget {
  const BarcodeLabelsScreen({super.key});

  @override
  ConsumerState<BarcodeLabelsScreen> createState() => _BarcodeLabelsScreenState();
}

class _BarcodeLabelsScreenState extends ConsumerState<BarcodeLabelsScreen> {
  String _q = '';
  String _type = 'code128';
  final Map<String, int> _copies = {}; // productId -> copies
  final Map<String, Product> _selected = {};

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final products = ref.watch(productsProvider(_q));

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('barcode_labels'))),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: FilledButton.icon(
              onPressed: _selected.isEmpty
                  ? null
                  : () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => LabelSheetScreen(
                          items: [
                            for (final p in _selected.values) (product: p, copies: _copies[p.id!] ?? 1),
                          ],
                          type: _type,
                        ),
                      )),
              icon: const Icon(Icons.print),
              label: Text('${ref.tr('preview_print')} (${_selected.length})'),
            ),
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
              child: TextField(
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: ref.tr('search'),
                  prefixIcon: const Icon(Icons.search),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: SegmentedButton<String>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 'code128', label: Text('Code128')),
                  ButtonSegment(value: 'ean13', label: Text('EAN-13')),
                  ButtonSegment(value: 'qr', label: Text('QR')),
                ],
                selected: {_type},
                onSelectionChanged: (s) => setState(() => _type = s.first),
              ),
            ),
            Expanded(
              child: products.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
                data: (all) {
                  final list = all.where((p) => (p.barcode ?? '').isNotEmpty).toList();
                  if (list.isEmpty) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(ref.tr('no_barcode_products'), textAlign: TextAlign.center),
                      ),
                    );
                  }
                  return ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (_, i) {
                      final p = list[i];
                      final on = _selected.containsKey(p.id);
                      final n = _copies[p.id!] ?? 1;
                      return ListTile(
                        onTap: () => setState(() {
                          if (on) {
                            _selected.remove(p.id);
                          } else {
                            _selected[p.id!] = p;
                            _copies.putIfAbsent(p.id!, () => 1);
                          }
                        }),
                        leading: Icon(on ? Icons.check_box : Icons.check_box_outline_blank,
                            color: on ? const Color(0xFF1565D8) : null),
                        title: Text(p.displayName(lang)),
                        subtitle: Text(p.barcode!),
                        trailing: on
                            ? Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.remove_circle_outline),
                                    onPressed: n > 1 ? () => setState(() => _copies[p.id!] = n - 1) : null,
                                  ),
                                  Text('$n', style: const TextStyle(fontWeight: FontWeight.w800)),
                                  IconButton(
                                    icon: const Icon(Icons.add_circle_outline),
                                    onPressed: () => setState(() => _copies[p.id!] = n + 1),
                                  ),
                                ],
                              )
                            : null,
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StockMovement {
  final String productName;
  final String type; // sale | purchase | adjust
  final double qtyChange;
  final String? reason;
  final DateTime createdAt;

  const StockMovement({
    required this.productName,
    required this.type,
    required this.qtyChange,
    this.reason,
    required this.createdAt,
  });

  factory StockMovement.fromMap(Map<String, dynamic> m) {
    final p = m['products'];
    return StockMovement(
      productName: p is Map ? (p['name_ar'] as String? ?? '-') : '-',
      type: m['movement_type'] as String,
      qtyChange: (m['qty_change'] as num).toDouble(),
      reason: m['reason'] as String?,
      createdAt: DateTime.parse(m['created_at'] as String).toLocal(),
    );
  }
}

class StockRepository {
  final _db = Supabase.instance.client;

  Future<void> adjust({
    required String id,
    required String productId,
    required double newQty,
    required String reason,
  }) async {
    await _db.rpc('adjust_stock', params: {
      'p_id': id,
      'p_product_id': productId,
      'p_new_qty': newQty,
      'p_reason': reason,
    });
  }

  Future<List<StockMovement>> movements() async {
    final rows = await _db
        .from('stock_movements')
        .select('movement_type, qty_change, reason, created_at, products(name_ar)')
        .order('created_at', ascending: false)
        .limit(200);
    return rows.map(StockMovement.fromMap).toList();
  }
}

final stockRepoProvider = Provider((_) => StockRepository());

final stockMovementsProvider = FutureProvider.autoDispose<List<StockMovement>>(
  (ref) => ref.read(stockRepoProvider).movements(),
);

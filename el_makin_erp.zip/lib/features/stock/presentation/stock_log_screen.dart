import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../data/stock_repository.dart';

class StockLogScreen extends ConsumerWidget {
  const StockLogScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final moves = ref.watch(stockMovementsProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('stock_log'))),
        body: moves.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) {
            if (list.isEmpty) return Center(child: Text(ref.tr('no_movements')));
            return RefreshIndicator(
              onRefresh: () async => ref.invalidate(stockMovementsProvider),
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final m = list[i];
                  final plus = m.qtyChange > 0;
                  return Card(
                    child: ListTile(
                      leading: Icon(
                        plus ? Icons.add_circle_outline : Icons.remove_circle_outline,
                        color: plus ? Colors.green.shade700 : Colors.red,
                      ),
                      title: Text(m.productName, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(
                          '${ref.tr('mv_${m.type}')} • ${df.format(m.createdAt)}${(m.reason ?? '').isEmpty ? '' : '\n${m.reason}'}'),
                      isThreeLine: (m.reason ?? '').isNotEmpty,
                      trailing: Text(
                        '${plus ? '+' : ''}${m.qtyChange}',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          color: plus ? Colors.green.shade700 : Colors.red,
                        ),
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/l10n/strings.dart';
import '../../products/domain/product.dart';
import '../data/stock_repository.dart';

class StockAdjustDialog extends ConsumerStatefulWidget {
  final Product product;
  const StockAdjustDialog({super.key, required this.product});

  @override
  ConsumerState<StockAdjustDialog> createState() => _StockAdjustDialogState();
}

class _StockAdjustDialogState extends ConsumerState<StockAdjustDialog> {
  final String _id = const Uuid().v4();
  late final TextEditingController _qty =
      TextEditingController(text: widget.product.stockQty.toString());
  final _reason = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _qty.dispose();
    _reason.dispose();
    super.dispose();
  }

  void _msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _confirm() async {
    final q = double.tryParse(_qty.text.replaceAll(',', '.'));
    if (q == null || q < 0) return _msg(ref.tr('required'));
    if (_reason.text.trim().isEmpty) return _msg(ref.tr('reason'));
    setState(() => _saving = true);
    try {
      await ref.read(stockRepoProvider).adjust(
            id: _id,
            productId: widget.product.id!,
            newQty: q,
            reason: _reason.text.trim(),
          );
      if (mounted) Navigator.of(context).pop(true);
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        _msg(e.message);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        _msg('$e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: AlertDialog(
        title: Text(widget.product.displayName(lang)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${ref.tr('current_stock')}: ${widget.product.stockQty}'),
            const SizedBox(height: 12),
            TextField(
              controller: _qty,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: ref.tr('new_qty')),
            ),
            const SizedBox(height: 12),
            TextField(controller: _reason, decoration: InputDecoration(labelText: ref.tr('reason'))),
          ],
        ),
        actions: [
          TextButton(
            onPressed: _saving ? null : () => Navigator.of(context).pop(false),
            child: Text(ref.tr('cancel')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
            onPressed: _saving ? null : _confirm,
            child: Text(ref.tr('save')),
          ),
        ],
      ),
    );
  }
}

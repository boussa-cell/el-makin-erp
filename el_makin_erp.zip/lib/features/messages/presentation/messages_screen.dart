import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../../../core/utils/contact_links.dart';
import '../data/messages_repository.dart';

class MessagesScreen extends ConsumerWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final messages = ref.watch(messagesProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('messages'))),
        body: messages.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) {
            if (list.isEmpty) return Center(child: Text(ref.tr('no_messages')));
            return RefreshIndicator(
              onRefresh: () async => ref.invalidate(messagesProvider),
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final m = list[i];
                  final hasPhone = (m.phone ?? '').isNotEmpty;
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(m.name,
                                    style: const TextStyle(fontWeight: FontWeight.w800)),
                              ),
                              Text(df.format(m.createdAt), style: const TextStyle(fontSize: 11)),
                            ],
                          ),
                          if (hasPhone) Text(m.phone!, style: const TextStyle(color: Colors.black54)),
                          const SizedBox(height: 6),
                          Text(m.message),
                          if (hasPhone)
                            Row(
                              children: [
                                TextButton.icon(
                                  onPressed: () => callPhone(m.phone!),
                                  icon: const Icon(Icons.call),
                                  label: Text(ref.tr('call')),
                                ),
                                TextButton.icon(
                                  onPressed: () => openWhatsApp(m.phone!),
                                  icon: const Icon(Icons.chat),
                                  label: Text(ref.tr('whatsapp')),
                                ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

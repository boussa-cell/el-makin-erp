import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ContactMessage {
  final String name;
  final String? phone;
  final String message;
  final DateTime createdAt;

  const ContactMessage({
    required this.name,
    this.phone,
    required this.message,
    required this.createdAt,
  });

  factory ContactMessage.fromMap(Map<String, dynamic> m) => ContactMessage(
        name: m['name'] as String,
        phone: m['phone'] as String?,
        message: m['message'] as String,
        createdAt: DateTime.parse(m['created_at'] as String).toLocal(),
      );
}

class MessagesRepository {
  final _db = Supabase.instance.client;

  Future<List<ContactMessage>> list() async {
    final rows =
        await _db.from('contact_messages').select().order('created_at', ascending: false).limit(200);
    return rows.map(ContactMessage.fromMap).toList();
  }
}

final messagesProvider = FutureProvider.autoDispose<List<ContactMessage>>(
  (ref) => MessagesRepository().list(),
);

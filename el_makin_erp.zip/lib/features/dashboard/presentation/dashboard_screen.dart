import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/auth/role_provider.dart';
import '../../../core/l10n/strings.dart';
import '../../cash/presentation/cash_screen.dart';
import '../../customers/presentation/customers_screen.dart';
import '../../expenses/presentation/expenses_screen.dart';
import '../../messages/presentation/messages_screen.dart';
import '../../orders/presentation/orders_screen.dart';
import '../../pos/presentation/pos_screen.dart';
import '../../products/presentation/products_screen.dart';
import '../../purchases/presentation/purchases_screen.dart';
import '../../backup/presentation/backup_screen.dart';
import '../../catalog/presentation/catalog_screen.dart';
import '../../barcodes/presentation/barcode_labels_screen.dart';
import '../../../core/sync/sync_controller.dart';
import '../../sync/presentation/sync_center_screen.dart';
import '../../reports/presentation/reports_screen.dart';
import '../../settings/presentation/settings_screen.dart';
import '../../sales/presentation/invoices_screen.dart';
import '../../stock/presentation/stock_log_screen.dart';
import '../../suppliers/presentation/suppliers_screen.dart';
import '../../users/presentation/users_screen.dart';

const _all = {'admin', 'manager', 'vendeur'};
const _mgr = {'admin', 'manager'};
const _adm = {'admin'};

class _Tile {
  final String key;
  final IconData icon;
  final Widget? screen;
  final Set<String> roles;
  const _Tile(this.key, this.icon, {this.screen, this.roles = _all});
}

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final role = ref.watch(roleProvider);

    final tiles = <_Tile>[
      const _Tile('products', Icons.inventory_2_rounded, screen: ProductsScreen()),
      const _Tile('pos', Icons.point_of_sale_rounded, screen: PosScreen()),
      const _Tile('invoices', Icons.receipt_long_rounded, screen: InvoicesScreen()),
      const _Tile('categories_brands', Icons.category_rounded, screen: CatalogScreen(), roles: _mgr),
      const _Tile('orders', Icons.shopping_bag_rounded, screen: OrdersScreen(), roles: _mgr),
      const _Tile('messages', Icons.mail_rounded, screen: MessagesScreen(), roles: _mgr),
      const _Tile('purchases', Icons.move_to_inbox_rounded, screen: PurchasesScreen(), roles: _mgr),
      const _Tile('customers', Icons.groups_rounded, screen: CustomersScreen()),
      const _Tile('suppliers', Icons.local_shipping_rounded, screen: SuppliersScreen(), roles: _mgr),
      const _Tile('customer_balances', Icons.account_balance_wallet_rounded,
          screen: CustomersScreen(debtorsOnly: true), roles: _mgr),
      const _Tile('supplier_balances', Icons.credit_card_rounded,
          screen: SuppliersScreen(debtorsOnly: true), roles: _mgr),
      const _Tile('cash_box', Icons.savings_rounded, screen: CashScreen(), roles: _mgr),
      const _Tile('expenses', Icons.payments_rounded, screen: ExpensesScreen(), roles: _mgr),
      const _Tile('stock_log', Icons.swap_vert_rounded, screen: StockLogScreen(), roles: _mgr),
      const _Tile('reports', Icons.bar_chart_rounded, screen: ReportsScreen(), roles: _mgr),
      const _Tile('users', Icons.admin_panel_settings_rounded, screen: UsersScreen(), roles: _adm),
      const _Tile('barcode', Icons.qr_code_2_rounded, screen: BarcodeLabelsScreen(), roles: _mgr),
      const _Tile('settings', Icons.settings_rounded, screen: SettingsScreen(), roles: _adm),
      const _Tile('backup', Icons.cloud_sync_rounded, screen: BackupScreen(), roles: _adm),
    ];

    Widget grid(String r) {
      final visible = tiles.where((t) => t.roles.contains(r)).toList();
      return LayoutBuilder(
        builder: (context, c) {
          final cols = c.maxWidth > 900 ? 5 : (c.maxWidth > 600 ? 4 : 2);
          return GridView.builder(
            padding: const EdgeInsets.all(14),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: cols,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.1,
            ),
            itemCount: visible.length,
            itemBuilder: (_, i) {
              final t = visible[i];
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () {
                    if (t.screen == null) {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(SnackBar(content: Text(ref.tr('soon'))));
                    } else {
                      Navigator.of(context).push(MaterialPageRoute(builder: (_) => t.screen!));
                    }
                  },
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: const Color(0xFF1565D8),
                        child: Icon(t.icon, color: Colors.white, size: 30),
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: Text(ref.tr(t.key),
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      );
    }

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('EL MAKIN ERP'),
          actions: [
            const _SyncButton(),
            TextButton(
              onPressed: () => ref.read(langProvider.notifier).state = lang == 'ar' ? 'fr' : 'ar',
              child: Text(lang == 'ar' ? 'Français' : 'العربية',
                  style: const TextStyle(color: Colors.white)),
            ),
            IconButton(
              tooltip: ref.tr('logout'),
              icon: const Icon(Icons.logout),
              onPressed: () => Supabase.instance.client.auth.signOut(),
            ),
          ],
        ),
        body: role.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => grid('vendeur'),
          data: grid,
        ),
      ),
    );
  }
}


/// أيقونة المزامنة مع عدد العمليات المعلّقة.
class _SyncButton extends ConsumerWidget {
  const _SyncButton();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final count = ref.watch(pendingCountProvider).value ?? 0;
    final syncing = ref.watch(syncingProvider);
    final online = ref.watch(onlineProvider).value ?? true;
    return IconButton(
      tooltip: ref.tr('sync_center'),
      onPressed: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => const SyncCenterScreen())),
      icon: Badge(
        isLabelVisible: count > 0,
        label: Text('$count'),
        child: Icon(!online
            ? Icons.cloud_off
            : (syncing ? Icons.sync : (count > 0 ? Icons.cloud_upload : Icons.cloud_done))),
      ),
    );
  }
}

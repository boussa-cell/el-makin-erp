import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/l10n/strings.dart';
import '../../customers/presentation/customers_screen.dart';
import '../../pos/presentation/pos_screen.dart';
import '../../purchases/presentation/purchases_screen.dart';
import '../../suppliers/presentation/suppliers_screen.dart';
import '../../sales/presentation/invoices_screen.dart';
import '../../products/presentation/products_screen.dart';

class _Tile {
  final String key;
  final IconData icon;
  final Widget? screen;
  const _Tile(this.key, this.icon, [this.screen]);
}

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final tiles = <_Tile>[
      const _Tile('products', Icons.inventory_2_rounded, ProductsScreen()),
      const _Tile('pos', Icons.point_of_sale_rounded, PosScreen()),
      const _Tile('invoices', Icons.receipt_long_rounded, InvoicesScreen()),
      const _Tile('purchases', Icons.move_to_inbox_rounded, PurchasesScreen()),
      const _Tile('customers', Icons.groups_rounded, CustomersScreen()),
      const _Tile('suppliers', Icons.local_shipping_rounded, SuppliersScreen()),
      const _Tile('customer_balances', Icons.account_balance_wallet_rounded, CustomersScreen(debtorsOnly: true)),
      const _Tile('supplier_balances', Icons.credit_card_rounded, SuppliersScreen(debtorsOnly: true)),
      const _Tile('reports', Icons.bar_chart_rounded),
      const _Tile('barcode', Icons.qr_code_2_rounded),
      const _Tile('settings', Icons.settings_rounded),
      const _Tile('backup', Icons.cloud_sync_rounded),
    ];

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('EL MAKIN ERP'),
          actions: [
            TextButton(
              onPressed: () => ref.read(langProvider.notifier).state = lang == 'ar' ? 'fr' : 'ar',
              child: Text(lang == 'ar' ? 'Français' : 'العربية',
                  style: const TextStyle(color: Colors.white)),
            ),
            IconButton(
              tooltip: ref.tr('logout'),
              icon: const Icon(Icons.logout),
              onPressed: () => Supabase.instance.client.auth.signOut(),
            ),
          ],
        ),
        body: LayoutBuilder(
          builder: (context, c) {
            final cols = c.maxWidth > 900 ? 5 : (c.maxWidth > 600 ? 4 : 2);
            return GridView.builder(
              padding: const EdgeInsets.all(14),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: cols,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.1,
              ),
              itemCount: tiles.length,
              itemBuilder: (_, i) {
                final t = tiles[i];
                return Card(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {
                      if (t.screen == null) {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(SnackBar(content: Text(ref.tr('soon'))));
                      } else {
                        Navigator.of(context)
                            .push(MaterialPageRoute(builder: (_) => t.screen!));
                      }
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: const Color(0xFF1565D8),
                          child: Icon(t.icon, color: Colors.white, size: 30),
                        ),
                        const SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: Text(ref.tr(t.key),
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

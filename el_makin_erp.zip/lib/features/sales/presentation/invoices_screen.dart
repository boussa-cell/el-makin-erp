import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../data/sales_repository.dart';
import '../domain/sale.dart';

class InvoicesScreen extends ConsumerWidget {
  const InvoicesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final sales = ref.watch(salesProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('invoices'))),
        body: sales.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) {
            if (list.isEmpty) return Center(child: Text(ref.tr('no_invoices')));
            return RefreshIndicator(
              onRefresh: () async => ref.invalidate(salesProvider),
              child: ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: list.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) {
                  final s = list[i];
                  return Card(
                    child: ListTile(
                      onTap: () => showModalBottomSheet<void>(
                        context: context,
                        isScrollControlled: true,
                        builder: (_) => _InvoiceDetail(sale: s),
                      ),
                      title: Text(s.invoiceNo, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${s.customerName ?? ref.tr('walk_in')}\n${df.format(s.createdAt)}'),
                      isThreeLine: true,
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(dzd(s.total), style: const TextStyle(fontWeight: FontWeight.w800)),
                          if (s.remaining > 0)
                            Text('${ref.tr('remaining')}: ${dzd(s.remaining)}',
                                style: const TextStyle(color: Colors.red, fontSize: 12)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

class _InvoiceDetail extends ConsumerWidget {
  final SaleSummary sale;
  const _InvoiceDetail({required this.sale});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(sale.invoiceNo,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: ref.read(salesRepoProvider).items(sale.id),
              builder: (context, snap) {
                if (snap.hasError) return Text('${snap.error}');
                if (!snap.hasData) return const LinearProgressIndicator();
                return Column(
                  children: [
                    for (final it in snap.data!)
                      ListTile(
                        dense: true,
                        title: Text(it['product_name'] as String),
                        subtitle: Text('${it['qty']} × ${dzd(it['unit_price'] as num)}'),
                        trailing: Text(dzd(it['total'] as num),
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                      ),
                  ],
                );
              },
            ),
            const Divider(),
            _row(ref.tr('total'), dzd(sale.total)),
            _row(ref.tr('paid'), dzd(sale.paid)),
            _row(ref.tr('remaining'), dzd(sale.remaining)),
          ],
        ),
      ),
    );
  }

  Widget _row(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.w700))],
        ),
      );
}

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../../customers/data/customer_repository.dart';
import '../../pos/presentation/cart_provider.dart';
import '../../products/domain/product.dart';
import '../data/sales_repository.dart';

class CheckoutSheet extends ConsumerStatefulWidget {
  final List<CartLine> lines;
  final PriceTier tier;
  const CheckoutSheet({super.key, required this.lines, required this.tier});

  @override
  ConsumerState<CheckoutSheet> createState() => _CheckoutSheetState();
}

class _CheckoutSheetState extends ConsumerState<CheckoutSheet> {
  final String _saleId = const Uuid().v4();
  final _discount = TextEditingController();
  final _paid = TextEditingController();
  final _note = TextEditingController();
  String? _customerId;
  bool _paidEdited = false;
  bool _saving = false;

  double _num(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '.')) ?? 0;

  double get _subtotal =>
      widget.lines.fold(0.0, (s, l) => s + l.product.priceFor(widget.tier) * l.qty);
  double get _total => math.max(0.0, _subtotal - _num(_discount));
  double get _paidValue => _paidEdited ? _num(_paid) : _total;
  double get _remaining => _total - _paidValue;

  @override
  void initState() {
    super.initState();
    _paid.text = _subtotal.toStringAsFixed(2);
  }

  @override
  void dispose() {
    _discount.dispose();
    _paid.dispose();
    _note.dispose();
    super.dispose();
  }

  void _syncPaid() {
    if (!_paidEdited) _paid.text = _total.toStringAsFixed(2);
  }

  void _msg(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _confirm() async {
    final paid = _paidValue;
    if (paid < 0 || paid > _total + 0.001) return _msg(ref.tr('invalid_paid'));
    if (_remaining > 0.004 && _customerId == null) return _msg(ref.tr('need_customer'));

    setState(() => _saving = true);
    try {
      final res = await ref.read(salesRepoProvider).createSale(
            saleId: _saleId,
            customerId: _customerId,
            tier: widget.tier,
            discount: _num(_discount),
            paid: _paidEdited ? paid : null,
            note: _note.text,
            items: [
              for (final l in widget.lines) {'product_id': l.product.id, 'qty': l.qty},
            ],
          );
      if (mounted) Navigator.of(context).pop(res);
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        _msg(e.message);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        _msg('$e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final customers = ref.watch(customersProvider(''));

    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(ref.tr('checkout'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              customers.when(
                loading: () => const LinearProgressIndicator(),
                error: (e, _) => Text('$e'),
                data: (list) => DropdownButtonFormField<String?>(
                  value: _customerId,
                  decoration: InputDecoration(labelText: ref.tr('customer')),
                  items: [
                    DropdownMenuItem<String?>(value: null, child: Text(ref.tr('walk_in'))),
                    for (final c in list)
                      DropdownMenuItem<String?>(value: c.id, child: Text(c.name)),
                  ],
                  onChanged: (v) => setState(() => _customerId = v),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(ref.tr('subtotal')),
                  Text(dzd(_subtotal), style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _discount,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: ref.tr('discount')),
                onChanged: (_) => setState(_syncPaid),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => setState(() {
                        _paidEdited = false;
                        _syncPaid();
                      }),
                      child: Text(ref.tr('cash')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => setState(() {
                        _paidEdited = true;
                        _paid.text = '0';
                      }),
                      child: Text(ref.tr('credit')),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _paid,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: ref.tr('paid')),
                onChanged: (_) => setState(() => _paidEdited = true),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _note,
                decoration: InputDecoration(labelText: ref.tr('note')),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(ref.tr('total'), style: const TextStyle(fontSize: 16)),
                  Text(dzd(_total),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(ref.tr('remaining')),
                  Text(dzd(_remaining),
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: _remaining > 0.004 ? Colors.red : Colors.green.shade700)),
                ],
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _saving ? null : _confirm,
                child: _saving
                    ? const SizedBox(
                        height: 22,
                        width: 22,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(ref.tr('confirm_sale')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

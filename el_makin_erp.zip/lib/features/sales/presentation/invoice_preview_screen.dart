import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/pdf/pdf_export.dart';
import '../../settings/data/settings_repository.dart';
import '../data/invoice_repository.dart';
import 'invoice_view.dart';

class InvoicePreviewScreen extends ConsumerStatefulWidget {
  final String saleId;
  const InvoicePreviewScreen({super.key, required this.saleId});

  @override
  ConsumerState<InvoicePreviewScreen> createState() => _InvoicePreviewScreenState();
}

class _InvoicePreviewScreenState extends ConsumerState<InvoicePreviewScreen> {
  final _key = GlobalKey();
  String? _lang;
  String? _paper;
  bool _busy = false;

  Future<void> _run(String invoiceNo, bool share) async {
    setState(() => _busy = true);
    try {
      final bytes = await boundaryToPdf(_key, thermal: _paper == 'thermal');
      if (share) {
        await sharePdf(bytes, '$invoiceNo.pdf');
      } else {
        await printPdf(bytes, invoiceNo);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final appLang = ref.watch(langProvider);
    final inv = ref.watch(invoiceProvider(widget.saleId));
    final shopAsync = ref.watch(settingsProvider);

    return Directionality(
      textDirection: appLang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('invoices'))),
        body: inv.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (d) => shopAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
            data: (shop) {
              _lang ??= shop.invoiceLang;
              _paper ??= shop.paper;
              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      children: [
                        Expanded(
                          child: SegmentedButton<String>(
                            showSelectedIcon: false,
                            segments: [
                              ButtonSegment(value: 'ar', label: Text(ref.tr('arabic'))),
                              ButtonSegment(value: 'fr', label: Text(ref.tr('french'))),
                            ],
                            selected: {_lang!},
                            onSelectionChanged: (s) => setState(() => _lang = s.first),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: SegmentedButton<String>(
                            showSelectedIcon: false,
                            segments: [
                              ButtonSegment(value: 'a4', label: Text(ref.tr('paper_a4'))),
                              ButtonSegment(value: 'thermal', label: Text(ref.tr('paper_thermal'))),
                            ],
                            selected: {_paper!},
                            onSelectionChanged: (s) => setState(() => _paper = s.first),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(8),
                      child: FittedBox(
                        fit: BoxFit.fitWidth,
                        child: RepaintBoundary(
                          key: _key,
                          child: InvoiceView(data: d, shop: shop, lang: _lang!, paper: _paper!),
                        ),
                      ),
                    ),
                  ),
                  SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _busy ? null : () => _run(d.invoiceNo, false),
                              icon: const Icon(Icons.print),
                              label: Text(ref.tr('print')),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                              onPressed: _busy ? null : () => _run(d.invoiceNo, true),
                              icon: const Icon(Icons.share),
                              label: Text(ref.tr('share_pdf')),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

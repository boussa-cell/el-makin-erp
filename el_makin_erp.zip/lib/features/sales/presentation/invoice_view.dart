import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat, NumberFormat;

import '../../../core/utils/money.dart';
import '../../settings/data/settings_repository.dart';
import '../data/invoice_repository.dart';

const _inv = <String, Map<String, String>>{
  'ar': {
    'invoice': 'فاتورة',
    'invoice_no': 'رقم الفاتورة',
    'date': 'التاريخ',
    'customer': 'العميل',
    'phone': 'الهاتف',
    'shipping': 'مركز الشحن',
    'cashier': 'البائع',
    'product': 'المنتج',
    'qty': 'الكمية',
    'price': 'السعر',
    'total': 'الإجمالي',
    'subtotal': 'المجموع',
    'discount': 'الخصم',
    'paid': 'المدفوع',
    'remaining': 'المتبقي',
    'note': 'ملاحظة',
    'walk_in': 'زبون عابر',
  },
  'fr': {
    'invoice': 'Facture',
    'invoice_no': 'N° facture',
    'date': 'Date',
    'customer': 'Client',
    'phone': 'Téléphone',
    'shipping': "Centre d'expédition",
    'cashier': 'Vendeur',
    'product': 'Produit',
    'qty': 'Qté',
    'price': 'Prix',
    'total': 'Total',
    'subtotal': 'Sous-total',
    'discount': 'Remise',
    'paid': 'Payé',
    'remaining': 'Reste',
    'note': 'Note',
    'walk_in': 'Client de passage',
  },
};

/// قالب الفاتورة. يُرسم بعرض ثابت (A4 أو حراري 80mm) ثم يُحوَّل إلى PDF.
class InvoiceView extends StatelessWidget {
  final InvoiceData data;
  final ShopSettings shop;
  final String lang; // ar | fr
  final String paper; // a4 | thermal

  const InvoiceView({
    super.key,
    required this.data,
    required this.shop,
    required this.lang,
    required this.paper,
  });

  @override
  Widget build(BuildContext context) {
    final t = _inv[lang] ?? _inv['ar']!;
    final thermal = paper == 'thermal';
    final width = thermal ? 302.0 : 595.0;
    final fs = thermal ? 11.0 : 13.0;
    final df = DateFormat('yyyy-MM-dd HH:mm');

    Widget kv(String k, String v, {bool bold = false, double? size, Color? color}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 2),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(k, style: TextStyle(fontSize: size)),
              const SizedBox(width: 8),
              Flexible(
                child: Text(v,
                    style: TextStyle(
                        fontSize: size,
                        color: color,
                        fontWeight: bold ? FontWeight.w800 : FontWeight.w600)),
              ),
            ],
          ),
        );

    Widget cell(String text, int flex, {bool bold = false, TextAlign? align}) => Expanded(
          flex: flex,
          child: Text(text,
              textAlign: align,
              style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500)),
        );

    final divider = Divider(height: thermal ? 12 : 18, thickness: 1, color: Colors.black54);

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Container(
        width: width,
        color: Colors.white,
        padding: EdgeInsets.all(thermal ? 10 : 28),
        child: DefaultTextStyle(
          style: TextStyle(color: Colors.black, fontSize: fs),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('EL MAKIN',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 2)),
              if (shop.shopName.trim().isNotEmpty && shop.shopName.trim() != 'EL MAKIN')
                Text(shop.shopName,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              if (shop.phone.isNotEmpty) Text(shop.phone, textAlign: TextAlign.center),
              if (shop.address.isNotEmpty) Text(shop.address, textAlign: TextAlign.center),
              const SizedBox(height: 6),
              Text(t['invoice']!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              divider,
              kv(t['invoice_no']!, data.invoiceNo, bold: true),
              kv(t['date']!, df.format(data.date)),
              kv(t['customer']!, data.customerName ?? t['walk_in']!),
              if ((data.customerPhone ?? '').isNotEmpty) kv(t['phone']!, data.customerPhone!),
              if ((data.shippingCenter ?? '').isNotEmpty) kv(t['shipping']!, data.shippingCenter!),
              kv(t['cashier']!, data.cashier),
              divider,
              Row(children: [
                cell(t['product']!, 5, bold: true),
                cell(t['qty']!, 2, bold: true, align: TextAlign.center),
                cell(t['price']!, 3, bold: true, align: TextAlign.center),
                cell(t['total']!, 3, bold: true, align: TextAlign.center),
              ]),
              const SizedBox(height: 4),
              for (final l in data.lines)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      cell(l.name, 5),
                      cell(l.qty % 1 == 0 ? l.qty.toStringAsFixed(0) : l.qty.toString(), 2,
                          align: TextAlign.center),
                      cell(NumberFormat('#,##0.##').format(l.price), 3, align: TextAlign.center),
                      cell(NumberFormat('#,##0.##').format(l.total), 3, align: TextAlign.center),
                    ],
                  ),
                ),
              divider,
              kv(t['subtotal']!, dzd(data.subtotal)),
              if (data.discount > 0) kv(t['discount']!, dzd(data.discount)),
              kv(t['total']!, dzd(data.total), bold: true, size: fs + 3),
              kv(t['paid']!, dzd(data.paid)),
              kv(t['remaining']!, dzd(data.remaining),
                  bold: data.remaining > 0, color: data.remaining > 0 ? Colors.red.shade800 : null),
              if ((data.note ?? '').isNotEmpty) ...[
                divider,
                Text('${t['note']}: ${data.note}'),
              ],
              if (shop.showQr) ...[
                const SizedBox(height: 12),
                Center(
                  child: BarcodeWidget(
                    barcode: Barcode.qrCode(),
                    data: data.invoiceNo,
                    width: thermal ? 80 : 90,
                    height: thermal ? 80 : 90,
                  ),
                ),
              ],
              if (shop.footer.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(shop.footer,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

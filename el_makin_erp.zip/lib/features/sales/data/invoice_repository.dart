import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InvoiceLine {
  final String name;
  final double qty;
  final double price;
  final double total;
  const InvoiceLine(
      {required this.name, required this.qty, required this.price, required this.total});
}

class InvoiceData {
  final String invoiceNo;
  final DateTime date;
  final String? customerName;
  final String? customerPhone;
  final String? shippingCenter;
  final String cashier;
  final double subtotal;
  final double discount;
  final double total;
  final double paid;
  final double remaining;
  final String? note;
  final List<InvoiceLine> lines;

  const InvoiceData({
    required this.invoiceNo,
    required this.date,
    this.customerName,
    this.customerPhone,
    this.shippingCenter,
    required this.cashier,
    required this.subtotal,
    required this.discount,
    required this.total,
    required this.paid,
    required this.remaining,
    this.note,
    required this.lines,
  });
}

double _d(dynamic v) => v == null ? 0 : (v as num).toDouble();

class InvoiceRepository {
  final _db = Supabase.instance.client;

  Future<InvoiceData> load(String saleId) async {
    final s = await _db
        .from('sales')
        .select('invoice_no, created_at, subtotal, discount, total, paid, remaining, note, '
            'user_id, customers(name, phone, shipping_center)')
        .eq('id', saleId)
        .single();
    final rows = await _db
        .from('sale_items')
        .select('product_name, qty, unit_price, total')
        .eq('sale_id', saleId)
        .order('product_name');

    var cashier = '-';
    try {
      final p = await _db
          .from('profiles')
          .select('full_name')
          .eq('id', s['user_id'] as String)
          .maybeSingle();
      cashier = (p?['full_name'] as String?) ?? '-';
    } catch (_) {}

    final c = s['customers'];
    return InvoiceData(
      invoiceNo: s['invoice_no'] as String,
      date: DateTime.parse(s['created_at'] as String).toLocal(),
      customerName: c is Map ? c['name'] as String? : null,
      customerPhone: c is Map ? c['phone'] as String? : null,
      shippingCenter: c is Map ? c['shipping_center'] as String? : null,
      cashier: cashier,
      subtotal: _d(s['subtotal']),
      discount: _d(s['discount']),
      total: _d(s['total']),
      paid: _d(s['paid']),
      remaining: _d(s['remaining']),
      note: s['note'] as String?,
      lines: [
        for (final r in rows)
          InvoiceLine(
            name: r['product_name'] as String,
            qty: _d(r['qty']),
            price: _d(r['unit_price']),
            total: _d(r['total']),
          ),
      ],
    );
  }
}

final invoiceRepoProvider = Provider((_) => InvoiceRepository());

final invoiceProvider = FutureProvider.autoDispose.family<InvoiceData, String>(
  (ref, saleId) => ref.read(invoiceRepoProvider).load(saleId),
);

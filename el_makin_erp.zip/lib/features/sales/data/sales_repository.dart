import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/auth/role_provider.dart';
import '../../../core/local/local_db.dart';
import '../../../core/sync/net.dart';
import '../../products/domain/product.dart';
import '../domain/sale.dart';
import 'invoice_repository.dart';

String tierKey(PriceTier t) {
  switch (t) {
    case PriceTier.wholesale:
      return 'wholesale';
    case PriceTier.semiWholesale:
      return 'semi_wholesale';
    case PriceTier.retail:
      return 'retail';
  }
}

class SalesRepository {
  final _db = Supabase.instance.client;

  /// يستدعي دالة create_sale في قاعدة البيانات (عملية واحدة ذرّية).
  /// نفس saleId عند إعادة المحاولة لا ينشئ فاتورة مكررة.
  ///
  /// بدون إنترنت: تُحفظ العملية محليًا فورًا بفاتورة مؤقتة (OFF-xxxxxx) وتُرسل
  /// تلقائيًا عند عودة الاتصال، ويأخذ السيرفر رقم الفاتورة الحقيقي وقتها.
  Future<Map<String, dynamic>> createSale({
    required String saleId,
    String? customerId,
    String? customerName,
    required PriceTier tier,
    double discount = 0,
    double? paid,
    String? note,
    required List<Map<String, dynamic>> items,
    required List<Map<String, dynamic>> localLines, // name, qty, price
  }) {
    final cleanNote = (note == null || note.trim().isEmpty) ? null : note.trim();
    return withNetwork<Map<String, dynamic>>(
      () async {
        final res = await _db.rpc('create_sale', params: {
          'p_id': saleId,
          'p_customer_id': customerId,
          'p_tier': tierKey(tier),
          'p_discount': discount,
          'p_paid': paid,
          'p_note': cleanNote,
          'p_items': items,
        });
        return Map<String, dynamic>.from(res as Map);
      },
      () => _saveOffline(
        saleId: saleId,
        customerId: customerId,
        customerName: customerName,
        tier: tier,
        discount: discount,
        paid: paid,
        note: cleanNote,
        items: items,
        localLines: localLines,
      ),
    );
  }

  Future<Map<String, dynamic>> _saveOffline({
    required String saleId,
    String? customerId,
    String? customerName,
    required PriceTier tier,
    required double discount,
    double? paid,
    String? note,
    required List<Map<String, dynamic>> items,
    required List<Map<String, dynamic>> localLines,
  }) async {
    double subtotal = 0;
    for (final l in localLines) {
      subtotal += (l['price'] as num).toDouble() * (l['qty'] as num).toDouble();
    }
    final disc = math.min(math.max(discount, 0.0), subtotal);
    final total = subtotal - disc;
    final paidV = paid ?? total;
    final remaining = total - paidV;
    final tmpNo = 'OFF-${saleId.substring(0, 6).toUpperCase()}';
    final now = DateTime.now();
    final cashier = await cachedUserName();

    final lines = [
      for (final l in localLines)
        {
          'name': l['name'],
          'qty': (l['qty'] as num).toDouble(),
          'price': (l['price'] as num).toDouble(),
          'total': (l['price'] as num).toDouble() * (l['qty'] as num).toDouble(),
        },
    ];

    final local = {
      'invoice_no': tmpNo,
      'total': total,
      'customer': customerName,
      'subtotal': subtotal,
      'discount': disc,
      'paid': paidV,
      'remaining': remaining,
      'note': note,
      'created_at': now.toIso8601String(),
      'cashier': cashier,
      'lines': lines,
    };

    await Outbox.add('create_sale', {
      'id': saleId,
      'customer_id': customerId,
      'tier': tierKey(tier),
      'discount': discount,
      'paid': paid,
      'note': note,
      'items': items,
      'local': local,
    });

    for (final i in items) {
      await ProductCache.adjustStock(i['product_id'] as String, -((i['qty'] as num).toDouble()));
    }
    if (customerId != null && remaining > 0) {
      await CustomerCache.adjustBalance(customerId, remaining);
    }

    return {
      'id': saleId,
      'invoice_no': tmpNo,
      'total': total,
      'paid': paidV,
      'remaining': remaining,
      'offline': true,
      'invoice': invoiceFromLocal(local),
    };
  }

  /// الفواتير المحفوظة على الهاتف ولم تُرسل بعد.
  Future<List<SaleSummary>> _pending() async {
    final out = <SaleSummary>[];
    for (final it in await Outbox.all()) {
      if (it.op != 'create_sale') continue;
      final l = Map<String, dynamic>.from((it.payload['local'] as Map?) ?? const {});
      final total = ((l['total'] ?? 0) as num).toDouble();
      out.add(SaleSummary(
        id: it.payload['id'] as String,
        invoiceNo: (l['invoice_no'] ?? 'OFF') as String,
        customerName: l['customer'] as String?,
        total: total,
        paid: ((l['paid'] ?? total) as num).toDouble(),
        remaining: ((l['remaining'] ?? 0) as num).toDouble(),
        createdAt: DateTime.tryParse('${l['created_at']}') ?? it.createdAt,
        pending: true,
        local: l,
      ));
    }
    return out.reversed.toList();
  }

  /// قائمة الفواتير: المعلّقة أولًا، ثم آخر 100 من السيرفر (أو من النسخة المحفوظة بدون إنترنت).
  Future<List<SaleSummary>> list() async {
    final pending = await _pending();
    final rows = await withNetwork<List<Map<String, dynamic>>>(
      () async {
        final r = await _db
            .from('sales')
            .select('id, invoice_no, total, paid, remaining, created_at, customers(name)')
            .order('created_at', ascending: false)
            .limit(100);
        await LocalKv.set('sales_list', jsonEncode(r));
        return r;
      },
      () async {
        final cached = await LocalKv.get('sales_list');
        if (cached == null) return <Map<String, dynamic>>[];
        return (jsonDecode(cached) as List)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
      },
    );
    return [...pending, ...rows.map(SaleSummary.fromMap)];
  }

  Future<List<Map<String, dynamic>>> items(String saleId) async {
    final rows = await _db.from('sale_items').select().eq('sale_id', saleId).order('product_name');
    return rows;
  }
}

final salesRepoProvider = Provider((_) => SalesRepository());

final salesProvider = FutureProvider.autoDispose<List<SaleSummary>>(
  (ref) => ref.read(salesRepoProvider).list(),
);

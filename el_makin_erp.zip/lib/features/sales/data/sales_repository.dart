import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/local/local_db.dart';
import '../../../core/sync/net.dart';
import '../../products/domain/product.dart';
import '../domain/sale.dart';
import 'invoice_repository.dart';

String tierKey(PriceTier t) {
  switch (t) {
    case PriceTier.wholesale:
      return 'wholesale';
    case PriceTier.semiWholesale:
      return 'semi_wholesale';
    case PriceTier.retail:
      return 'retail';
  }
}

class SalesRepository {
  final _db = Supabase.instance.client;

  /// يستدعي دالة create_sale في قاعدة البيانات (عملية واحدة ذرّية).
  /// نفس saleId عند إعادة المحاولة لا ينشئ فاتورة مكررة.
  ///
  /// بدون إنترنت: تُحفظ العملية محليًا بفاتورة مؤقتة (OFF-xxxxxx) وتُرسل تلقائيًا
  /// عند عودة الاتصال، ويأخذ السيرفر رقم الفاتورة الحقيقي وقتها.
  Future<Map<String, dynamic>> createSale({
    required String saleId,
    String? customerId,
    String? customerName,
    required PriceTier tier,
    double discount = 0,
    double? paid,
    String? note,
    required List<Map<String, dynamic>> items,
    required List<Map<String, dynamic>> localLines, // name, qty, price
  }) async {
    final cleanNote = (note == null || note.trim().isEmpty) ? null : note.trim();
    try {
      final res = await _db.rpc('create_sale', params: {
        'p_id': saleId,
        'p_customer_id': customerId,
        'p_tier': tierKey(tier),
        'p_discount': discount,
        'p_paid': paid,
        'p_note': cleanNote,
        'p_items': items,
      }).timeout(netTimeout);
      return Map<String, dynamic>.from(res as Map);
    } catch (e) {
      if (!isNetworkError(e)) rethrow;
      return _saveOffline(
        saleId: saleId,
        customerId: customerId,
        customerName: customerName,
        tier: tier,
        discount: discount,
        paid: paid,
        note: cleanNote,
        items: items,
        localLines: localLines,
      );
    }
  }

  Future<Map<String, dynamic>> _saveOffline({
    required String saleId,
    String? customerId,
    String? customerName,
    required PriceTier tier,
    required double discount,
    double? paid,
    String? note,
    required List<Map<String, dynamic>> items,
    required List<Map<String, dynamic>> localLines,
  }) async {
    double subtotal = 0;
    for (final l in localLines) {
      subtotal += (l['price'] as num).toDouble() * (l['qty'] as num).toDouble();
    }
    final disc = math.min(math.max(discount, 0.0), subtotal);
    final total = subtotal - disc;
    final paidV = paid ?? total;
    final remaining = total - paidV;
    final tmpNo = 'OFF-${saleId.substring(0, 6).toUpperCase()}';

    await Outbox.add('create_sale', {
      'id': saleId,
      'customer_id': customerId,
      'tier': tierKey(tier),
      'discount': discount,
      'paid': paid,
      'note': note,
      'items': items,
      'local': {'invoice_no': tmpNo, 'total': total, 'customer': customerName},
    });

    for (final i in items) {
      await ProductCache.adjustStock(i['product_id'] as String, -((i['qty'] as num).toDouble()));
    }
    if (customerId != null && remaining > 0) {
      await CustomerCache.adjustBalance(customerId, remaining);
    }

    final invoice = InvoiceData(
      invoiceNo: tmpNo,
      date: DateTime.now(),
      customerName: customerName,
      cashier: _db.auth.currentUser?.email ?? '-',
      subtotal: subtotal,
      discount: disc,
      total: total,
      paid: paidV,
      remaining: remaining,
      note: note,
      lines: [
        for (final l in localLines)
          InvoiceLine(
            name: l['name'] as String,
            qty: (l['qty'] as num).toDouble(),
            price: (l['price'] as num).toDouble(),
            total: (l['price'] as num).toDouble() * (l['qty'] as num).toDouble(),
          ),
      ],
    );

    return {
      'id': saleId,
      'invoice_no': tmpNo,
      'total': total,
      'paid': paidV,
      'remaining': remaining,
      'offline': true,
      'invoice': invoice,
    };
  }

  Future<List<SaleSummary>> list() async {
    final rows = await _db
        .from('sales')
        .select('id, invoice_no, total, paid, remaining, created_at, customers(name)')
        .order('created_at', ascending: false)
        .limit(100);
    return rows.map(SaleSummary.fromMap).toList();
  }

  Future<List<Map<String, dynamic>>> items(String saleId) async {
    final rows = await _db.from('sale_items').select().eq('sale_id', saleId).order('product_name');
    return rows;
  }
}

final salesRepoProvider = Provider((_) => SalesRepository());

final salesProvider = FutureProvider.autoDispose<List<SaleSummary>>(
  (ref) => ref.read(salesRepoProvider).list(),
);

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../products/domain/product.dart';
import '../domain/sale.dart';

String tierKey(PriceTier t) {
  switch (t) {
    case PriceTier.wholesale:
      return 'wholesale';
    case PriceTier.semiWholesale:
      return 'semi_wholesale';
    case PriceTier.retail:
      return 'retail';
  }
}

class SalesRepository {
  final _db = Supabase.instance.client;

  /// يستدعي دالة create_sale في قاعدة البيانات (عملية واحدة ذرّية).
  /// نفس saleId عند إعادة المحاولة لا ينشئ فاتورة مكررة.
  Future<Map<String, dynamic>> createSale({
    required String saleId,
    String? customerId,
    required PriceTier tier,
    double discount = 0,
    double? paid,
    String? note,
    required List<Map<String, dynamic>> items,
  }) async {
    final res = await _db.rpc('create_sale', params: {
      'p_id': saleId,
      'p_customer_id': customerId,
      'p_tier': tierKey(tier),
      'p_discount': discount,
      'p_paid': paid,
      'p_note': (note == null || note.trim().isEmpty) ? null : note.trim(),
      'p_items': items,
    });
    return Map<String, dynamic>.from(res as Map);
  }

  Future<List<SaleSummary>> list() async {
    final rows = await _db
        .from('sales')
        .select('id, invoice_no, total, paid, remaining, created_at, customers(name)')
        .order('created_at', ascending: false)
        .limit(100);
    return rows.map(SaleSummary.fromMap).toList();
  }

  Future<List<Map<String, dynamic>>> items(String saleId) async {
    final rows = await _db.from('sale_items').select().eq('sale_id', saleId).order('product_name');
    return rows;
  }
}

final salesRepoProvider = Provider((_) => SalesRepository());

final salesProvider = FutureProvider.autoDispose<List<SaleSummary>>(
  (ref) => ref.read(salesRepoProvider).list(),
);

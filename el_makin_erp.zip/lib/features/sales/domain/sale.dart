class SaleSummary {
  final String id;
  final String invoiceNo;
  final String? customerName;
  final double total;
  final double paid;
  final double remaining;
  final DateTime createdAt;

  const SaleSummary({
    required this.id,
    required this.invoiceNo,
    this.customerName,
    required this.total,
    required this.paid,
    required this.remaining,
    required this.createdAt,
  });

  factory SaleSummary.fromMap(Map<String, dynamic> m) {
    final c = m['customers'];
    return SaleSummary(
      id: m['id'] as String,
      invoiceNo: m['invoice_no'] as String,
      customerName: c is Map ? c['name'] as String? : null,
      total: (m['total'] as num).toDouble(),
      paid: (m['paid'] as num).toDouble(),
      remaining: (m['remaining'] as num).toDouble(),
      createdAt: DateTime.parse(m['created_at'] as String).toLocal(),
    );
  }
}

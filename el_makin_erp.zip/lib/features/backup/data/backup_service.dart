import 'dart:convert';
import 'dart:typed_data';

import 'package:intl/intl.dart' show DateFormat;
import 'package:supabase_flutter/supabase_flutter.dart';

import 'telegram_backup.dart';

class BackupResult {
  final String name;
  final bool telegramSent;
  final String? telegramError;
  const BackupResult(this.name, {this.telegramSent = false, this.telegramError});
}

class BackupService {
  static final _db = Supabase.instance.client;
  static const _bucket = 'backups';
  static DateTime? _lastCheck;

  static const _tables = [
    'categories',
    'brands',
    'products',
    'customers',
    'suppliers',
    'sales',
    'sale_items',
    'purchases',
    'purchase_items',
    'payments',
    'expenses',
    'cash_transactions',
    'stock_movements',
    'settings',
  ];

  static Future<List<Map<String, dynamic>>> _all(String table) async {
    final out = <Map<String, dynamic>>[];
    final orderCol = table == 'settings' ? 'key' : 'id';
    var from = 0;
    while (true) {
      final rows = await _db
          .from(table)
          .select()
          .order(orderCol)
          .range(from, from + 999)
          .timeout(const Duration(seconds: 60));
      out.addAll(rows);
      if (rows.length < 1000) break;
      from += 1000;
    }
    return out;
  }

  /// يقرأ كل الجداول ويبني ملف JSON واحدًا (دون رفعه).
  static Future<({String name, Uint8List bytes})> buildBackup() async {
    final data = <String, dynamic>{};
    for (final t in _tables) {
      data[t] = await _all(t);
    }
    final payload = {
      'app': 'EL MAKIN ERP',
      'version': 1,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'tables': data,
    };
    final bytes = Uint8List.fromList(utf8.encode(jsonEncode(payload)));
    final name = 'backup_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.json';
    return (name: name, bytes: bytes);
  }

  /// نسخة JSON كاملة: ترفع إلى Storage، وتُرسل إلى تلغرام إن كان الإرسال التلقائي مفعّلًا.
  static Future<BackupResult> createBackup() async {
    final b = await buildBackup();
    await _db.storage.from(_bucket).uploadBinary(
          b.name,
          b.bytes,
          fileOptions: const FileOptions(contentType: 'application/json'),
        );
    final cfg = await TelegramBackup.load();
    if (!cfg.auto || cfg.token.isEmpty || cfg.chat.isEmpty) return BackupResult(b.name);
    final err = await TelegramBackup.send(b.name, b.bytes);
    return BackupResult(b.name, telegramSent: err == null, telegramError: err);
  }

  /// يبني نسخة ويرسلها إلى تلغرام فقط (دون رفعها إلى Supabase).
  static Future<String?> sendToTelegramNow() async {
    final b = await buildBackup();
    return TelegramBackup.send(b.name, b.bytes);
  }

  static Future<List<FileObject>> list() async {
    final files = await _db.storage.from(_bucket).list();
    final out = files.where((f) => f.name.endsWith('.json')).toList();
    out.sort((a, b) => b.name.compareTo(a.name));
    return out;
  }

  static Future<Uint8List> download(String name) => _db.storage.from(_bucket).download(name);

  static DateTime? _parseName(String name) {
    try {
      return DateFormat('yyyyMMdd_HHmmss').parse(name.substring(7, 22));
    } catch (_) {
      return null;
    }
  }

  /// نسخة تلقائية كل 24 ساعة (للمدير فقط)، مع الاحتفاظ بآخر 30 نسخة.
  static Future<void> autoBackupIfDue() async {
    final now = DateTime.now();
    if (_lastCheck != null && now.difference(_lastCheck!) < const Duration(hours: 1)) return;
    _lastCheck = now;
    try {
      final uid = _db.auth.currentUser?.id;
      if (uid == null) return;
      final row = await _db.from('profiles').select('role').eq('id', uid).maybeSingle();
      if (row?['role'] != 'admin') return;

      final files = await list();
      if (files.isNotEmpty) {
        final last = _parseName(files.first.name);
        if (last != null && now.difference(last) < const Duration(hours: 24)) return;
      }
      await createBackup();

      final all = await list();
      if (all.length > 30) {
        await _db.storage.from(_bucket).remove([for (final f in all.skip(30)) f.name]);
      }
    } catch (_) {}
  }

  static Future<Map<String, String>> restoreMissing(String name) async =>
      restoreFromBytes(await download(name));

  /// يعيد السجلات المفقودة فقط (لا يلمس الموجود): تصنيفات، ماركات، موردون، عملاء، منتجات.
  static Future<Map<String, String>> restoreFromBytes(Uint8List bytes) async {
    final json = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
    final tables = json['tables'] as Map<String, dynamic>;
    final result = <String, String>{};

    for (final t in const ['categories', 'brands', 'suppliers', 'customers', 'products']) {
      final rows = ((tables[t] ?? const []) as List)
          .cast<Map>()
          .map((r) => Map<String, dynamic>.from(r))
          .toList();
      var inserted = 0;
      try {
        for (var i = 0; i < rows.length; i += 200) {
          final chunk = rows.sublist(i, i + 200 > rows.length ? rows.length : i + 200);
          final res = await _db
              .from(t)
              .upsert(chunk, onConflict: 'id', ignoreDuplicates: true)
              .select('id');
          inserted += res.length;
        }
        result[t] = '$inserted';
      } catch (e) {
        result[t] = 'error: $e';
      }
    }
    return result;
  }
}

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../../../core/local/local_db.dart';

/// إرسال النسخ الاحتياطية إلى بوت تلغرام. الرمز يُحفظ على هذا الهاتف فقط.
class TelegramBackup {
  static const _kToken = 'tg_token';
  static const _kChat = 'tg_chat';
  static const _kAuto = 'tg_auto';

  static Future<({String token, String chat, bool auto})> load() async => (
        token: (await LocalKv.get(_kToken)) ?? '',
        chat: (await LocalKv.get(_kChat)) ?? '',
        auto: (await LocalKv.get(_kAuto)) == '1',
      );

  static Future<void> save({required String token, required String chat, required bool auto}) async {
    await LocalKv.set(_kToken, token.trim());
    await LocalKv.set(_kChat, chat.trim());
    await LocalKv.set(_kAuto, auto ? '1' : '0');
  }

  /// يعيد null عند النجاح، أو نص الخطأ.
  static Future<String?> send(String name, Uint8List bytes) async {
    final cfg = await load();
    if (cfg.token.isEmpty || cfg.chat.isEmpty) return 'not configured';
    try {
      final req = http.MultipartRequest(
          'POST', Uri.parse('https://api.telegram.org/bot${cfg.token}/sendDocument'))
        ..fields['chat_id'] = cfg.chat
        ..fields['caption'] = 'EL MAKIN ERP backup'
        ..files.add(http.MultipartFile.fromBytes('document', bytes, filename: name));
      final res = await req.send().timeout(const Duration(seconds: 90));
      final body = await res.stream.bytesToString();
      if (res.statusCode == 200) return null;
      try {
        return (jsonDecode(body) as Map)['description']?.toString() ?? 'HTTP ${res.statusCode}';
      } catch (_) {
        return 'HTTP ${res.statusCode}';
      }
    } catch (e) {
      return '$e';
    }
  }

  /// يرسل فقط إذا كان الإرسال التلقائي مفعّلًا ومضبوطًا. يعيد null عند النجاح أو عدم التفعيل.
  static Future<String?> sendIfEnabled(String name, Uint8List bytes) async {
    final cfg = await load();
    if (!cfg.auto || cfg.token.isEmpty || cfg.chat.isEmpty) return null;
    return send(name, bytes);
  }

  /// يقرأ آخر رسالة وصلت للبوت ويعيد معرّف محادثتها (أو null).
  static Future<String?> detectChatId(String token) async {
    try {
      final res = await http
          .get(Uri.parse('https://api.telegram.org/bot${token.trim()}/getUpdates'))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode != 200) return null;
      final results = (jsonDecode(res.body) as Map)['result'] as List? ?? const [];
      for (final u in results.reversed) {
        final m = (u as Map)['message'] ?? u['channel_post'] ?? u['edited_message'];
        final id = (m as Map?)?['chat']?['id'];
        if (id != null) return '$id';
      }
    } catch (_) {}
    return null;
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/pdf/pdf_export.dart';
import '../../sync/presentation/sync_center_screen.dart';
import '../data/backup_service.dart';

final backupsProvider =
    FutureProvider.autoDispose<List<FileObject>>((ref) => BackupService.list());

class BackupScreen extends ConsumerStatefulWidget {
  const BackupScreen({super.key});

  @override
  ConsumerState<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends ConsumerState<BackupScreen> {
  bool _busy = false;

  void _msg(String t) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
    } catch (e) {
      _msg('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _backupNow() => _run(() async {
        await BackupService.createBackup();
        ref.invalidate(backupsProvider);
        _msg(ref.tr('backup_done'));
      });

  Future<void> _share(String name) => _run(() async {
        final bytes = await BackupService.download(name);
        await shareBytesFile(name, bytes, 'application/json');
      });

  Future<void> _restore(String name) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ref.read(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: AlertDialog(
          title: Text(ref.tr('restore_missing')),
          content: Text(ref.tr('restore_hint')),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false), child: Text(ref.tr('cancel'))),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
              onPressed: () => Navigator.of(context).pop(true),
              child: Text(ref.tr('confirm')),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await _run(() async {
      final res = await BackupService.restoreMissing(name);
      _msg('${ref.tr('restore_done')}: ${res.entries.map((e) => '${e.key}=${e.value}').join(' | ')}');
    });
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final backups = ref.watch(backupsProvider);

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('backup'))),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            FilledButton.icon(
              onPressed: _busy ? null : _backupNow,
              icon: const Icon(Icons.cloud_upload),
              label: Text(_busy ? ref.tr('syncing') : ref.tr('backup_now')),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              onPressed: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const SyncCenterScreen())),
              icon: const Icon(Icons.sync),
              label: Text(ref.tr('sync_center')),
            ),
            const SizedBox(height: 8),
            Text(ref.tr('auto_backup_hint'), style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 16),
            Text(ref.tr('backups_list'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            backups.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Text('${ref.tr('error')}\n$e'),
              data: (list) {
                if (list.isEmpty) return Center(child: Text(ref.tr('no_backups')));
                return Column(
                  children: [
                    for (final f in list)
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.description_outlined),
                          title: Text(f.name, style: const TextStyle(fontSize: 13)),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                tooltip: ref.tr('share_backup'),
                                icon: const Icon(Icons.download),
                                onPressed: _busy ? null : () => _share(f.name),
                              ),
                              IconButton(
                                tooltip: ref.tr('restore_missing'),
                                icon: const Icon(Icons.restore),
                                onPressed: _busy ? null : () => _restore(f.name),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/pdf/pdf_export.dart';
import '../../sync/presentation/sync_center_screen.dart';
import '../data/backup_service.dart';
import '../data/telegram_backup.dart';

final backupsProvider =
    FutureProvider.autoDispose<List<FileObject>>((ref) => BackupService.list());

class BackupScreen extends ConsumerStatefulWidget {
  const BackupScreen({super.key});

  @override
  ConsumerState<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends ConsumerState<BackupScreen> {
  bool _busy = false;
  final _token = TextEditingController();
  final _chat = TextEditingController();
  bool _auto = false;

  @override
  void initState() {
    super.initState();
    TelegramBackup.load().then((c) {
      if (!mounted) return;
      setState(() {
        _token.text = c.token;
        _chat.text = c.chat;
        _auto = c.auto;
      });
    });
  }

  @override
  void dispose() {
    _token.dispose();
    _chat.dispose();
    super.dispose();
  }

  void _msg(String t) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
    } catch (e) {
      _msg('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _backupNow() => _run(() async {
        final r = await BackupService.createBackup();
        ref.invalidate(backupsProvider);
        _msg(r.telegramError == null
            ? '${ref.tr('backup_done')}${r.telegramSent ? ' + ${ref.tr('telegram_sent')}' : ''}'
            : '${ref.tr('backup_done')} (Telegram: ${r.telegramError})');
      });

  Future<void> _share(String name) => _run(() async {
        final bytes = await BackupService.download(name);
        await shareBytesFile(name, bytes, 'application/json');
      });

  Future<bool> _confirmRestore() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ref.read(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: AlertDialog(
          title: Text(ref.tr('restore_missing')),
          content: Text(ref.tr('restore_hint')),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false), child: Text(ref.tr('cancel'))),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
              onPressed: () => Navigator.of(context).pop(true),
              child: Text(ref.tr('confirm')),
            ),
          ],
        ),
      ),
    );
    return ok == true;
  }

  String _fmt(Map<String, String> res) =>
      '${ref.tr('restore_done')}: ${res.entries.map((e) => '${e.key}=${e.value}').join(' | ')}';

  Future<void> _restore(String name) async {
    if (!await _confirmRestore()) return;
    await _run(() async => _msg(_fmt(await BackupService.restoreMissing(name))));
  }

  Future<void> _restoreFromFile() async {
    final file = await openFile();
    if (file == null) return;
    if (!await _confirmRestore()) return;
    await _run(() async {
      final bytes = await file.readAsBytes();
      _msg(_fmt(await BackupService.restoreFromBytes(bytes)));
    });
  }

  Future<void> _saveTelegram() async {
    await TelegramBackup.save(token: _token.text, chat: _chat.text, auto: _auto);
    _msg(ref.tr('telegram_saved'));
  }

  Future<void> _detectChat() => _run(() async {
        final id = await TelegramBackup.detectChatId(_token.text);
        if (id == null) return _msg(ref.tr('chat_not_found'));
        setState(() => _chat.text = id);
        _msg(ref.tr('chat_found'));
      });

  Future<void> _sendTelegramNow() => _run(() async {
        await TelegramBackup.save(token: _token.text, chat: _chat.text, auto: _auto);
        final err = await BackupService.sendToTelegramNow();
        _msg(err == null ? ref.tr('telegram_sent') : 'Telegram: $err');
      });

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final backups = ref.watch(backupsProvider);

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('backup'))),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            FilledButton.icon(
              onPressed: _busy ? null : _backupNow,
              icon: const Icon(Icons.cloud_upload),
              label: Text(_busy ? ref.tr('syncing') : ref.tr('backup_now')),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              onPressed: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const SyncCenterScreen())),
              icon: const Icon(Icons.sync),
              label: Text(ref.tr('sync_center')),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              onPressed: _busy ? null : _restoreFromFile,
              icon: const Icon(Icons.restore_page),
              label: Text(ref.tr('restore_from_file')),
            ),
            const SizedBox(height: 8),
            Text(ref.tr('auto_backup_hint'), style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 16),

            // تلغرام
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(ref.tr('telegram_backup'),
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 6),
                    Text(ref.tr('telegram_hint'), style: const TextStyle(fontSize: 12)),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _token,
                      decoration: InputDecoration(labelText: ref.tr('bot_token')),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _chat,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(labelText: ref.tr('chat_id')),
                    ),
                    const SizedBox(height: 6),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(ref.tr('telegram_auto')),
                      value: _auto,
                      onChanged: (v) => setState(() => _auto = v),
                    ),
                    Text(ref.tr('local_only_note'), style: const TextStyle(fontSize: 11)),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                            onPressed: _busy ? null : _detectChat,
                            child: Text(ref.tr('detect_chat')),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
                            onPressed: _busy ? null : _saveTelegram,
                            child: Text(ref.tr('save')),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: _busy ? null : _sendTelegramNow,
                      icon: const Icon(Icons.send),
                      label: Text(ref.tr('send_telegram_now')),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),
            Text(ref.tr('backups_list'),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            backups.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Text('${ref.tr('error')}\n$e'),
              data: (list) {
                if (list.isEmpty) return Center(child: Text(ref.tr('no_backups')));
                return Column(
                  children: [
                    for (final f in list)
                      Card(
                        child: ListTile(
                          leading: const Icon(Icons.description_outlined),
                          title: Text(f.name, style: const TextStyle(fontSize: 13)),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                tooltip: ref.tr('share_backup'),
                                icon: const Icon(Icons.download),
                                onPressed: _busy ? null : () => _share(f.name),
                              ),
                              IconButton(
                                tooltip: ref.tr('restore_missing'),
                                icon: const Icon(Icons.restore),
                                onPressed: _busy ? null : () => _restore(f.name),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/config/env.dart';

class AppUser {
  final String id;
  final String name;
  final String? email;
  final String role;
  final bool active;

  const AppUser({
    required this.id,
    required this.name,
    this.email,
    required this.role,
    required this.active,
  });

  factory AppUser.fromMap(Map<String, dynamic> m) => AppUser(
        id: m['id'] as String,
        name: (m['full_name'] as String?) ?? '-',
        email: m['email'] as String?,
        role: m['role'] as String,
        active: (m['is_active'] as bool?) ?? true,
      );
}

class UsersRepository {
  final _db = Supabase.instance.client;

  Future<List<AppUser>> list() async {
    final rows = await _db
        .from('profiles')
        .select('id, full_name, email, role, is_active')
        .order('created_at');
    return rows.map(AppUser.fromMap).toList();
  }

  Future<void> _update(String id, Map<String, dynamic> values) async {
    final res = await _db.from('profiles').update(values).eq('id', id).select();
    if (res.isEmpty) throw Exception('not allowed');
  }

  Future<void> setRole(String id, String role) => _update(id, {'role': role});
  Future<void> setActive(String id, bool active) => _update(id, {'is_active': active});
  Future<void> setName(String id, String name) => _update(id, {'full_name': name.trim()});

  /// ينشئ حسابًا جديدًا بعميل مستقل (حتى لا تتأثر جلسة المدير)، ثم يفعّل الملف
  /// الشخصي ويحدد الاسم والصلاحية. الحسابات الجديدة تُنشأ "غير مفعّلة" افتراضيًا
  /// في قاعدة البيانات، فلا يصل أي حساب غريب إلى البيانات قبل تفعيل المدير له.
  Future<void> createUser({
    required String name,
    required String email,
    required String password,
    required String role,
  }) async {
    final temp = SupabaseClient(
      Env.supabaseUrl,
      Env.supabaseAnonKey,
      authOptions: const AuthClientOptions(autoRefreshToken: false),
    );
    try {
      final res = await temp.auth.signUp(
        email: email.trim(),
        password: password,
        data: {'full_name': name.trim()},
      );
      final uid = res.user?.id;
      if (uid == null) throw Exception('signup failed');
      await _update(uid, {'full_name': name.trim(), 'role': role, 'is_active': true});
    } finally {
      await temp.dispose();
    }
  }
}

final usersRepoProvider = Provider((_) => UsersRepository());

final usersProvider =
    FutureProvider.autoDispose<List<AppUser>>((ref) => ref.read(usersRepoProvider).list());

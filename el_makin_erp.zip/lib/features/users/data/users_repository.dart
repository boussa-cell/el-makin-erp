import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AppUser {
  final String id;
  final String name;
  final String role;
  final bool active;

  const AppUser({required this.id, required this.name, required this.role, required this.active});

  factory AppUser.fromMap(Map<String, dynamic> m) => AppUser(
        id: m['id'] as String,
        name: (m['full_name'] as String?) ?? '-',
        role: m['role'] as String,
        active: (m['is_active'] as bool?) ?? true,
      );
}

class UsersRepository {
  final _db = Supabase.instance.client;

  Future<List<AppUser>> list() async {
    final rows = await _db
        .from('profiles')
        .select('id, full_name, role, is_active')
        .order('created_at');
    return rows.map(AppUser.fromMap).toList();
  }

  Future<void> _update(String id, Map<String, dynamic> values) async {
    final res = await _db.from('profiles').update(values).eq('id', id).select();
    if (res.isEmpty) throw Exception('not allowed');
  }

  Future<void> setRole(String id, String role) => _update(id, {'role': role});
  Future<void> setActive(String id, bool active) => _update(id, {'is_active': active});
}

final usersRepoProvider = Provider((_) => UsersRepository());

final usersProvider =
    FutureProvider.autoDispose<List<AppUser>>((ref) => ref.read(usersRepoProvider).list());

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/l10n/strings.dart';
import '../data/users_repository.dart';

class UsersScreen extends ConsumerWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final users = ref.watch(usersProvider);
    final myId = Supabase.instance.client.auth.currentUser?.id;

    Future<void> run(Future<void> Function() action) async {
      try {
        await action();
        ref.invalidate(usersProvider);
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
        }
      }
    }

    Future<void> editName(AppUser u) async {
      final c = TextEditingController(text: u.name);
      final ok = await showDialog<bool>(
        context: context,
        builder: (_) => Directionality(
          textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
          child: AlertDialog(
            title: Text(ref.tr('edit_name')),
            content: TextField(controller: c, decoration: InputDecoration(labelText: ref.tr('name'))),
            actions: [
              TextButton(
                  onPressed: () => Navigator.of(context).pop(false), child: Text(ref.tr('cancel'))),
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
                onPressed: () => Navigator.of(context).pop(true),
                child: Text(ref.tr('save')),
              ),
            ],
          ),
        ),
      );
      final name = c.text.trim();
      c.dispose();
      if (ok == true && name.isNotEmpty) {
        await run(() => ref.read(usersRepoProvider).setName(u.id, name));
      }
    }

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('users'))),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            final ok = await showModalBottomSheet<bool>(
              context: context,
              isScrollControlled: true,
              builder: (_) => const _NewUserForm(),
            );
            if (ok == true) ref.invalidate(usersProvider);
          },
          icon: const Icon(Icons.person_add_alt_1),
          label: Text(ref.tr('add_user')),
        ),
        body: users.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) => ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            children: [
              Card(
                color: const Color(0xFFE8F0FE),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(ref.tr('login_name_hint')),
                ),
              ),
              for (final u in list)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(u.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                                  if ((u.email ?? '').isNotEmpty)
                                    Text(u.email!,
                                        style: const TextStyle(fontSize: 12, color: Colors.black54)),
                                ],
                              ),
                            ),
                            IconButton(
                              tooltip: ref.tr('edit_name'),
                              icon: const Icon(Icons.edit_outlined),
                              onPressed: () => editName(u),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<String>(
                          value: u.role,
                          decoration: InputDecoration(labelText: ref.tr('role')),
                          items: [
                            for (final r in const ['admin', 'manager', 'vendeur'])
                              DropdownMenuItem(value: r, child: Text(ref.tr('role_$r'))),
                          ],
                          onChanged: u.id == myId
                              ? null
                              : (v) {
                                  if (v != null && v != u.role) {
                                    run(() => ref.read(usersRepoProvider).setRole(u.id, v));
                                  }
                                },
                        ),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(ref.tr('active')),
                          value: u.active,
                          onChanged: u.id == myId
                              ? null
                              : (v) => run(() => ref.read(usersRepoProvider).setActive(u.id, v)),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NewUserForm extends ConsumerStatefulWidget {
  const _NewUserForm();

  @override
  ConsumerState<_NewUserForm> createState() => _NewUserFormState();
}

class _NewUserFormState extends ConsumerState<_NewUserForm> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  String _role = 'vendeur';
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  void _msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || _email.text.trim().isEmpty) return _msg(ref.tr('required'));
    if (_pass.text.length < 6) return _msg(ref.tr('weak_password'));
    setState(() => _saving = true);
    try {
      await ref.read(usersRepoProvider).createUser(
            name: _name.text,
            email: _email.text,
            password: _pass.text,
            role: _role,
          );
      if (mounted) {
        _msg(ref.tr('user_created'));
        Navigator.of(context).pop(true);
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => _saving = false);
      _msg(e.message);
    } catch (e) {
      if (mounted) setState(() => _saving = false);
      _msg('$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(ref.tr('add_user'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              TextField(controller: _name, decoration: InputDecoration(labelText: ref.tr('name'))),
              const SizedBox(height: 12),
              TextField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(labelText: ref.tr('email')),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _pass,
                obscureText: true,
                decoration: InputDecoration(labelText: ref.tr('password')),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _role,
                decoration: InputDecoration(labelText: ref.tr('role')),
                items: [
                  for (final r in const ['manager', 'vendeur'])
                    DropdownMenuItem(value: r, child: Text(ref.tr('role_$r'))),
                ],
                onChanged: (v) => setState(() => _role = v ?? 'vendeur'),
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: Text(_saving ? ref.tr('working') : ref.tr('save')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

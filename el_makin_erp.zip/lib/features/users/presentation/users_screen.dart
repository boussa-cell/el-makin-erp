import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/l10n/strings.dart';
import '../data/users_repository.dart';

class UsersScreen extends ConsumerWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final users = ref.watch(usersProvider);
    final myId = Supabase.instance.client.auth.currentUser?.id;

    Future<void> run(Future<void> Function() action) async {
      try {
        await action();
        ref.invalidate(usersProvider);
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
        }
      }
    }

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('users'))),
        body: users.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
          data: (list) => ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Card(
                color: const Color(0xFFE8F0FE),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(ref.tr('users_hint')),
                ),
              ),
              for (final u in list)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(u.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<String>(
                          value: u.role,
                          decoration: InputDecoration(labelText: ref.tr('role')),
                          items: [
                            for (final r in const ['admin', 'manager', 'vendeur'])
                              DropdownMenuItem(value: r, child: Text(ref.tr('role_$r'))),
                          ],
                          onChanged: u.id == myId
                              ? null
                              : (v) {
                                  if (v != null && v != u.role) {
                                    run(() => ref.read(usersRepoProvider).setRole(u.id, v));
                                  }
                                },
                        ),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(ref.tr('active')),
                          value: u.active,
                          onChanged: u.id == myId
                              ? null
                              : (v) => run(() => ref.read(usersRepoProvider).setActive(u.id, v)),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

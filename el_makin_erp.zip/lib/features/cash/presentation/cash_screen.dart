import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../data/cash_repository.dart';

class CashScreen extends ConsumerWidget {
  const CashScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(langProvider);
    final balance = ref.watch(cashBalanceProvider);
    final txs = ref.watch(cashTxProvider);
    final df = DateFormat('yyyy-MM-dd HH:mm');

    void refresh() {
      ref.invalidate(cashBalanceProvider);
      ref.invalidate(cashTxProvider);
    }

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(ref.tr('cash_box'))),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () async {
            final ok = await showModalBottomSheet<bool>(
              context: context,
              isScrollControlled: true,
              builder: (_) => const _CashForm(),
            );
            if (ok == true) refresh();
          },
          icon: const Icon(Icons.add),
          label: Text(ref.tr('add_cash_tx')),
        ),
        body: RefreshIndicator(
          onRefresh: () async => refresh(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text(ref.tr('cash_balance')),
                      const SizedBox(height: 6),
                      balance.when(
                        loading: () => const CircularProgressIndicator(),
                        error: (e, _) => Text('$e'),
                        data: (b) => Text(dzd(b),
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w800,
                              color: b < 0 ? Colors.red : Colors.green.shade700,
                            )),
                      ),
                    ],
                  ),
                ),
              ),
              txs.when(
                loading: () => const Padding(
                    padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
                error: (e, _) => Text('$e'),
                data: (list) {
                  if (list.isEmpty) {
                    return Padding(
                      padding: const EdgeInsets.all(24),
                      child: Center(child: Text(ref.tr('no_transactions'))),
                    );
                  }
                  return Column(
                    children: [
                      for (final t in list)
                        Card(
                          child: ListTile(
                            leading: Icon(
                              t.isIn ? Icons.south_west : Icons.north_east,
                              color: t.isIn ? Colors.green.shade700 : Colors.red,
                            ),
                            title: Text(ref.tr('tx_${t.type}'),
                                style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text(
                                '${df.format(t.createdAt)}${(t.note ?? '').isEmpty ? '' : '\n${t.note}'}'),
                            isThreeLine: (t.note ?? '').isNotEmpty,
                            trailing: Text(
                              '${t.isIn ? '+' : '-'}${dzd(t.amount)}',
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                color: t.isIn ? Colors.green.shade700 : Colors.red,
                              ),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CashForm extends ConsumerStatefulWidget {
  const _CashForm();

  @override
  ConsumerState<_CashForm> createState() => _CashFormState();
}

class _CashFormState extends ConsumerState<_CashForm> {
  final String _id = const Uuid().v4();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  String _type = 'deposit';
  bool _saving = false;

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final v = double.tryParse(_amount.text.replaceAll(',', '.')) ?? 0;
    if (v <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ref.tr('required'))));
      return;
    }
    setState(() => _saving = true);
    try {
      await ref.read(cashRepoProvider).add(id: _id, type: _type, amount: v, note: _note.text);
      if (mounted) Navigator.of(context).pop(true);
    } on PostgrestException catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(ref.tr('add_cash_tx'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _type,
                decoration: InputDecoration(labelText: ref.tr('category')),
                items: [
                  for (final t in const ['opening', 'deposit', 'withdrawal'])
                    DropdownMenuItem(value: t, child: Text(ref.tr('tx_$t'))),
                ],
                onChanged: (v) => setState(() => _type = v ?? 'deposit'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _amount,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: ref.tr('amount')),
              ),
              const SizedBox(height: 12),
              TextField(controller: _note, decoration: InputDecoration(labelText: ref.tr('note'))),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: Text(ref.tr('save')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CashTx {
  final String type;
  final bool isIn;
  final double amount;
  final String? note;
  final DateTime createdAt;

  const CashTx({
    required this.type,
    required this.isIn,
    required this.amount,
    this.note,
    required this.createdAt,
  });

  factory CashTx.fromMap(Map<String, dynamic> m) => CashTx(
        type: m['tx_type'] as String,
        isIn: m['direction'] == 'in',
        amount: (m['amount'] as num).toDouble(),
        note: m['note'] as String?,
        createdAt: DateTime.parse(m['created_at'] as String).toLocal(),
      );
}

class CashRepository {
  final _db = Supabase.instance.client;

  Future<double> balance() async {
    final res = await _db.rpc('cash_balance');
    return ((res ?? 0) as num).toDouble();
  }

  Future<List<CashTx>> list() async {
    final rows = await _db
        .from('cash_transactions')
        .select('tx_type, direction, amount, note, created_at')
        .order('created_at', ascending: false)
        .limit(200);
    return rows.map(CashTx.fromMap).toList();
  }

  /// type: opening | deposit | withdrawal
  Future<void> add({
    required String id,
    required String type,
    required double amount,
    String? note,
  }) async {
    await _db.rpc('add_cash_transaction', params: {
      'p_id': id,
      'p_type': type,
      'p_amount': amount,
      'p_note': (note == null || note.trim().isEmpty) ? null : note.trim(),
    });
  }
}

final cashRepoProvider = Provider((_) => CashRepository());

final cashBalanceProvider =
    FutureProvider.autoDispose<double>((ref) => ref.read(cashRepoProvider).balance());

final cashTxProvider =
    FutureProvider.autoDispose<List<CashTx>>((ref) => ref.read(cashRepoProvider).list());

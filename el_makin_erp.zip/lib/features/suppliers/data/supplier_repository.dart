import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../domain/supplier.dart';

class SupplierRepository {
  final _db = Supabase.instance.client;

  Future<List<Supplier>> list({String q = ''}) async {
    var query = _db.from('suppliers').select().isFilter('deleted_at', null);
    final s = q.trim().replaceAll(RegExp(r'[,()%]'), '');
    if (s.isNotEmpty) {
      query = query.or('name.ilike.%$s%,phone.ilike.%$s%');
    }
    final rows = await query.order('name').limit(200);
    return rows.map(Supplier.fromMap).toList();
  }

  Future<void> save(Supplier s) => _db.from('suppliers').upsert(s.toMap());
}

final supplierRepoProvider = Provider((_) => SupplierRepository());

final suppliersProvider = FutureProvider.autoDispose.family<List<Supplier>, String>(
  (ref, q) => ref.read(supplierRepoProvider).list(q: q),
);

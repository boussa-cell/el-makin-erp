class Supplier {
  final String? id;
  final String name;
  final String? phone;
  final String? address;
  final String? notes;
  final double balance;

  const Supplier({
    this.id,
    required this.name,
    this.phone,
    this.address,
    this.notes,
    this.balance = 0,
  });

  factory Supplier.fromMap(Map<String, dynamic> m) => Supplier(
        id: m['id'] as String?,
        name: m['name'] as String,
        phone: m['phone'] as String?,
        address: m['address'] as String?,
        notes: m['notes'] as String?,
        balance: ((m['balance'] ?? 0) as num).toDouble(),
      );

  static String? _n(String? v) => (v == null || v.trim().isEmpty) ? null : v.trim();

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name': name.trim(),
        'phone': _n(phone),
        'address': _n(address),
        'notes': _n(notes),
      };
}

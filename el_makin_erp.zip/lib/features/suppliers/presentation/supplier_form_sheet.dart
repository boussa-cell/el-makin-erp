import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../data/supplier_repository.dart';
import '../domain/supplier.dart';

class SupplierFormSheet extends ConsumerStatefulWidget {
  final Supplier? supplier;
  const SupplierFormSheet({super.key, this.supplier});

  @override
  ConsumerState<SupplierFormSheet> createState() => _SupplierFormSheetState();
}

class _SupplierFormSheetState extends ConsumerState<SupplierFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController name, phone, address, notes;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final s = widget.supplier;
    name = TextEditingController(text: s?.name ?? '');
    phone = TextEditingController(text: s?.phone ?? '');
    address = TextEditingController(text: s?.address ?? '');
    notes = TextEditingController(text: s?.notes ?? '');
  }

  @override
  void dispose() {
    for (final c in [name, phone, address, notes]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await ref.read(supplierRepoProvider).save(Supplier(
            id: widget.supplier?.id,
            name: name.text,
            phone: phone.text,
            address: address.text,
            notes: notes.text,
          ));
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  Widget _field(TextEditingController c, String label,
      {bool required = false, TextInputType? type}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: type,
        decoration: InputDecoration(labelText: label),
        validator: required
            ? (v) => (v == null || v.trim().isEmpty) ? ref.tr('required') : null
            : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(ref.tr(widget.supplier == null ? 'add_supplier' : 'edit_supplier'),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 16),
                _field(name, ref.tr('name'), required: true),
                _field(phone, ref.tr('phone'), type: TextInputType.phone),
                _field(address, ref.tr('address')),
                _field(notes, ref.tr('notes')),
                FilledButton(
                  onPressed: _saving ? null : _save,
                  child: Text(ref.tr('save')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../../payments/presentation/account_detail_screen.dart';
import '../data/supplier_repository.dart';
import '../domain/supplier.dart';
import 'supplier_form_sheet.dart';

class SuppliersScreen extends ConsumerStatefulWidget {
  /// true = الموردون الذين لهم رصيد مستحق (أرصدة الموردين)
  final bool debtorsOnly;
  const SuppliersScreen({super.key, this.debtorsOnly = false});

  @override
  ConsumerState<SuppliersScreen> createState() => _SuppliersScreenState();
}

class _SuppliersScreenState extends ConsumerState<SuppliersScreen> {
  String _q = '';

  Future<void> _openForm([Supplier? s]) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => SupplierFormSheet(supplier: s),
    );
    if (saved == true) ref.invalidate(suppliersProvider);
  }

  Future<void> _openDetail(Supplier s) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => AccountDetailScreen(
        kind: 'supplier',
        partyId: s.id!,
        name: s.name,
        onEdit: () => _openForm(s),
      ),
    ));
    ref.invalidate(suppliersProvider);
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final suppliers = ref.watch(suppliersProvider(_q));

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
            title: Text(ref.tr(widget.debtorsOnly ? 'supplier_balances' : 'suppliers'))),
        floatingActionButton: widget.debtorsOnly
            ? null
            : FloatingActionButton.extended(
                onPressed: () => _openForm(),
                icon: const Icon(Icons.add_business),
                label: Text(ref.tr('add_supplier')),
              ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: '${ref.tr('name')} / ${ref.tr('phone')}',
                  prefixIcon: const Icon(Icons.search),
                ),
              ),
            ),
            Expanded(
              child: suppliers.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
                data: (all) {
                  final list =
                      widget.debtorsOnly ? all.where((s) => s.balance > 0).toList() : all;
                  if (list.isEmpty) return Center(child: Text(ref.tr('no_suppliers')));
                  return ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final s = list[i];
                      return Card(
                        child: ListTile(
                          onTap: () => _openDetail(s),
                          leading: const CircleAvatar(child: Icon(Icons.local_shipping)),
                          title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(s.phone ?? ''),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(ref.tr('balance'), style: const TextStyle(fontSize: 11)),
                              Text(dzd(s.balance),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: s.balance > 0 ? Colors.red : Colors.green.shade700,
                                  )),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

double _d(dynamic v) => v == null ? 0 : (v as num).toDouble();

class ReportData {
  final double salesTotal;
  final int salesCount;
  final double purchasesTotal;
  final double expensesTotal;
  final double grossProfit;
  final double netProfit;
  final double receivables;
  final double payables;
  final double cashBalance;
  final List<({String day, double total})> daily;
  final List<({String name, double qty, double revenue})> top;

  const ReportData({
    required this.salesTotal,
    required this.salesCount,
    required this.purchasesTotal,
    required this.expensesTotal,
    required this.grossProfit,
    required this.netProfit,
    required this.receivables,
    required this.payables,
    required this.cashBalance,
    required this.daily,
    required this.top,
  });
}

class ReportsRepository {
  final _db = Supabase.instance.client;

  /// from/to بصيغة yyyy-MM-dd
  Future<ReportData> load(String from, String to) async {
    final params = {'p_from': from, 'p_to': to};
    final s = Map<String, dynamic>.from(await _db.rpc('report_summary', params: params) as Map);
    final daily = (await _db.rpc('report_daily', params: params) as List).cast<Map>();
    final top = (await _db.rpc('report_top_products',
            params: {...params, 'p_limit': 10}) as List)
        .cast<Map>();

    return ReportData(
      salesTotal: _d(s['sales_total']),
      salesCount: (s['sales_count'] ?? 0) as int,
      purchasesTotal: _d(s['purchases_total']),
      expensesTotal: _d(s['expenses_total']),
      grossProfit: _d(s['gross_profit']),
      netProfit: _d(s['net_profit']),
      receivables: _d(s['receivables']),
      payables: _d(s['payables']),
      cashBalance: _d(s['cash_balance']),
      daily: [for (final r in daily) (day: r['day'] as String, total: _d(r['total']))],
      top: [
        for (final r in top)
          (name: r['pname'] as String, qty: _d(r['qty']), revenue: _d(r['revenue']))
      ],
    );
  }
}

final reportsRepoProvider = Provider((_) => ReportsRepository());

/// المفتاح: "yyyy-MM-dd|yyyy-MM-dd"
final reportProvider = FutureProvider.autoDispose.family<ReportData, String>((ref, key) {
  final parts = key.split('|');
  return ref.read(reportsRepoProvider).load(parts[0], parts[1]);
});

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart' show DateFormat, NumberFormat;

import '../../../core/l10n/strings.dart';
import '../../../core/pdf/pdf_export.dart';
import '../../../core/utils/money.dart';
import '../../products/data/product_repository.dart';
import '../data/reports_repository.dart';

class ReportsScreen extends ConsumerStatefulWidget {
  const ReportsScreen({super.key});

  @override
  ConsumerState<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends ConsumerState<ReportsScreen> {
  static final _fmt = DateFormat('yyyy-MM-dd');
  late DateTime _from;
  late DateTime _to;
  final _captureKey = GlobalKey();
  bool _exporting = false;

  @override
  void initState() {
    super.initState();
    _thisMonthInit();
  }

  void _thisMonthInit() {
    final now = DateTime.now();
    _to = DateTime(now.year, now.month, now.day);
    _from = DateTime(now.year, now.month, 1);
  }

  String get _key => '${_fmt.format(_from)}|${_fmt.format(_to)}';

  void _preset(int days) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    setState(() {
      _to = today;
      _from = today.subtract(Duration(days: days));
    });
  }

  void _thisMonth() => setState(_thisMonthInit);

  Future<void> _pick(bool isFrom) async {
    final d = await showDatePicker(
      context: context,
      initialDate: isFrom ? _from : _to,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d == null) return;
    setState(() {
      if (isFrom) {
        _from = d;
        if (_to.isBefore(_from)) _to = _from;
      } else {
        _to = d;
        if (_from.isAfter(_to)) _from = _to;
      }
    });
  }

  void _snack(Object e) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
  }

  Future<void> _exportPdf() async {
    setState(() => _exporting = true);
    try {
      final bytes = await boundaryToPdf(_captureKey, thermal: false);
      await sharePdf(bytes, 'report_${_fmt.format(_from)}_${_fmt.format(_to)}.pdf');
    } catch (e) {
      _snack(e);
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _exportCsv() async {
    final r = ref.read(reportProvider(_key)).value;
    if (r == null) return;
    String q(String v) => '"${v.replaceAll('"', '""')}"';
    final b = StringBuffer()
      ..writeln('EL MAKIN,${_fmt.format(_from)},${_fmt.format(_to)}')
      ..writeln('${q(ref.tr('sales_total'))},${r.salesTotal}')
      ..writeln('${q(ref.tr('sales_count'))},${r.salesCount}')
      ..writeln('${q(ref.tr('purchases_total'))},${r.purchasesTotal}')
      ..writeln('${q(ref.tr('expenses_total'))},${r.expensesTotal}')
      ..writeln('${q(ref.tr('gross_profit'))},${r.grossProfit}')
      ..writeln('${q(ref.tr('net_profit'))},${r.netProfit}')
      ..writeln('${q(ref.tr('receivables'))},${r.receivables}')
      ..writeln('${q(ref.tr('payables'))},${r.payables}')
      ..writeln('${q(ref.tr('cash_balance'))},${r.cashBalance}')
      ..writeln()
      ..writeln(q(ref.tr('daily_sales')));
    for (final d in r.daily) {
      b.writeln('${d.day},${d.total}');
    }
    b
      ..writeln()
      ..writeln(q(ref.tr('top_products')));
    for (final t in r.top) {
      b.writeln('${q(t.name)},${t.qty},${t.revenue}');
    }
    try {
      await shareCsv('report_${_fmt.format(_from)}_${_fmt.format(_to)}.csv', b.toString());
    } catch (e) {
      _snack(e);
    }
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 8),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      );

  Widget _empty() => Padding(
        padding: const EdgeInsets.all(16),
        child: Center(child: Text(ref.tr('no_data'))),
      );

  Widget _reportBody(ReportData r, String lang, AsyncValue products) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          childAspectRatio: 1.9,
          children: [
            _Kpi(ref.tr('sales_total'), dzd(r.salesTotal), Icons.trending_up, Colors.blue),
            _Kpi(ref.tr('sales_count'), '${r.salesCount}', Icons.receipt_long, Colors.indigo),
            _Kpi(ref.tr('purchases_total'), dzd(r.purchasesTotal), Icons.move_to_inbox,
                Colors.orange),
            _Kpi(ref.tr('expenses_total'), dzd(r.expensesTotal), Icons.payments, Colors.red),
            _Kpi(ref.tr('gross_profit'), dzd(r.grossProfit), Icons.savings, Colors.teal),
            _Kpi(ref.tr('net_profit'), dzd(r.netProfit), Icons.account_balance,
                r.netProfit >= 0 ? Colors.green : Colors.red),
            _Kpi(ref.tr('receivables'), dzd(r.receivables), Icons.groups, Colors.deepOrange),
            _Kpi(ref.tr('payables'), dzd(r.payables), Icons.local_shipping, Colors.brown),
            _Kpi(ref.tr('cash_balance'), dzd(r.cashBalance), Icons.account_balance_wallet,
                Colors.green),
          ],
        ),
        _sectionTitle(ref.tr('daily_sales')),
        if (r.daily.isEmpty)
          _empty()
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: _BarChart(
                labels: [for (final d in r.daily) DateFormat('dd/MM').format(DateTime.parse(d.day))],
                values: [for (final d in r.daily) d.total],
              ),
            ),
          ),
        _sectionTitle(ref.tr('top_products')),
        if (r.top.isEmpty)
          _empty()
        else
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  for (final t in r.top)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(child: Text(t.name, overflow: TextOverflow.ellipsis)),
                              Text('${t.qty}  •  ${dzd(t.revenue)}',
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          LinearProgressIndicator(
                            value: r.top.first.qty == 0 ? 0 : t.qty / r.top.first.qty,
                            minHeight: 8,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final report = ref.watch(reportProvider(_key));
    final products = ref.watch(productsProvider(''));

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(ref.tr('reports')),
          actions: [
            IconButton(
              tooltip: ref.tr('export_pdf'),
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: _exporting ? null : _exportPdf,
            ),
            IconButton(
              tooltip: ref.tr('export_csv'),
              icon: const Icon(Icons.table_chart),
              onPressed: _exportCsv,
            ),
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _pick(true),
                      child: Text('${ref.tr('from_date')}: ${_fmt.format(_from)}'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _pick(false),
                      child: Text('${ref.tr('to_date')}: ${_fmt.format(_to)}'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  ActionChip(label: Text(ref.tr('today')), onPressed: () => _preset(0)),
                  ActionChip(label: Text(ref.tr('week')), onPressed: () => _preset(6)),
                  ActionChip(label: Text(ref.tr('month')), onPressed: _thisMonth),
                ],
              ),
              const SizedBox(height: 12),
              RepaintBoundary(
                key: _captureKey,
                child: Container(
                  color: const Color(0xFFF4F7FC),
                  padding: const EdgeInsets.all(4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'EL MAKIN  |  ${_fmt.format(_from)}  →  ${_fmt.format(_to)}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                      ),
                      const SizedBox(height: 8),
                      report.when(
                        loading: () => const Padding(
                          padding: EdgeInsets.all(40),
                          child: Center(child: CircularProgressIndicator()),
                        ),
                        error: (e, _) => Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text('${ref.tr('error')}\n$e'),
                        ),
                        data: (r) => _reportBody(r, lang, products),
                      ),
                      _sectionTitle(ref.tr('low_stock_products')),
                      products.when(
                        loading: () => const LinearProgressIndicator(),
                        error: (e, _) => Text('$e'),
                        data: (list) {
                          final low = list.where((p) => p.isLow).take(15).toList();
                          if (low.isEmpty) return _empty();
                          return Card(
                            child: Column(
                              children: [
                                for (final p in low)
                                  ListTile(
                                    dense: true,
                                    leading: const Icon(Icons.warning_amber_rounded,
                                        color: Colors.red),
                                    title: Text(p.displayName(lang)),
                                    trailing: Text('${p.stockQty} / ${p.minStock}',
                                        style: const TextStyle(fontWeight: FontWeight.w700)),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

class _Kpi extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const _Kpi(this.label, this.value, this.icon, this.color);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: color.withOpacity(0.15),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 11), overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: AlignmentDirectional.centerStart,
                    child: Text(value,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BarChart extends StatelessWidget {
  final List<String> labels;
  final List<double> values;
  const _BarChart({required this.labels, required this.values});

  @override
  Widget build(BuildContext context) {
    final maxV = values.fold<double>(0, math.max);
    final width = math.max(MediaQuery.of(context).size.width - 64, values.length * 48.0);
    final compact = NumberFormat.compact();
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        height: 190,
        width: width,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            for (var i = 0; i < values.length; i++)
              SizedBox(
                width: 48,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(compact.format(values[i]), style: const TextStyle(fontSize: 10)),
                    const SizedBox(height: 4),
                    Container(
                      width: 24,
                      height: maxV == 0 ? 0 : 120 * values[i] / maxV,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1565D8),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(labels[i], style: const TextStyle(fontSize: 10)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

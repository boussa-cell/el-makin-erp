import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../products/domain/product.dart';

class CartLine {
  final Product product;
  final double qty;
  const CartLine(this.product, this.qty);
  CartLine withQty(double q) => CartLine(product, q);
}

class CartNotifier extends StateNotifier<List<CartLine>> {
  CartNotifier() : super(const []);

  void add(Product p) {
    final i = state.indexWhere((l) => l.product.id == p.id);
    if (i == -1) {
      state = [...state, CartLine(p, 1)];
    } else {
      final list = [...state];
      list[i] = list[i].withQty(list[i].qty + 1);
      state = list;
    }
  }

  void setQty(int i, double q) {
    if (q <= 0) return remove(i);
    final list = [...state];
    list[i] = list[i].withQty(q);
    state = list;
  }

  void remove(int i) {
    final list = [...state]..removeAt(i);
    state = list;
  }

  void clear() => state = const [];
}

final cartProvider = StateNotifierProvider<CartNotifier, List<CartLine>>((_) => CartNotifier());
final priceTierProvider = StateProvider<PriceTier>((_) => PriceTier.retail);

final cartTotalProvider = Provider<double>((ref) {
  final tier = ref.watch(priceTierProvider);
  return ref
      .watch(cartProvider)
      .fold(0.0, (sum, l) => sum + l.product.priceFor(tier) * l.qty);
});

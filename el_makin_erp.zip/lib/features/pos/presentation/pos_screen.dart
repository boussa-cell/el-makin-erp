import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../../../core/widgets/barcode_scanner_page.dart';
import '../../products/data/product_repository.dart';
import '../../products/domain/product.dart';
import 'cart_provider.dart';

class PosScreen extends ConsumerStatefulWidget {
  const PosScreen({super.key});

  @override
  ConsumerState<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends ConsumerState<PosScreen> {
  final _search = TextEditingController();
  String _q = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _scan() async {
    final code = await Navigator.of(context)
        .push<String>(MaterialPageRoute(builder: (_) => const BarcodeScannerPage()));
    if (code == null) return;
    final p = await ref.read(productRepoProvider).findByBarcode(code);
    if (!mounted) return;
    if (p == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ref.tr('not_found'))));
    } else {
      ref.read(cartProvider.notifier).add(p);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final tier = ref.watch(priceTierProvider);
    final cart = ref.watch(cartProvider);
    final total = ref.watch(cartTotalProvider);
    final products = ref.watch(productsProvider(_q));

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(ref.tr('pos')),
          actions: [
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () => ref.read(cartProvider.notifier).clear(),
            ),
          ],
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
              child: TextField(
                controller: _search,
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: ref.tr('search'),
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: _scan),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: SegmentedButton<PriceTier>(
                showSelectedIcon: false,
                segments: [
                  ButtonSegment(value: PriceTier.wholesale, label: Text(ref.tr('wholesale'))),
                  ButtonSegment(value: PriceTier.semiWholesale, label: Text(ref.tr('semi_wholesale'))),
                  ButtonSegment(value: PriceTier.retail, label: Text(ref.tr('retail'))),
                ],
                selected: {tier},
                onSelectionChanged: (s) => ref.read(priceTierProvider.notifier).state = s.first,
              ),
            ),
            Expanded(
              flex: 2,
              child: products.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('$e')),
                data: (list) => ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final p = list[i];
                    return ListTile(
                      dense: true,
                      title: Text(p.displayName(lang)),
                      subtitle: Text('${ref.tr('stock')}: ${p.stockQty}'),
                      trailing: Text(dzd(p.priceFor(tier)),
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      onTap: () => ref.read(cartProvider.notifier).add(p),
                    );
                  },
                ),
              ),
            ),
            const Divider(height: 1),
            Expanded(
              flex: 3,
              child: cart.isEmpty
                  ? Center(child: Text(ref.tr('empty_cart')))
                  : ListView.builder(
                      itemCount: cart.length,
                      itemBuilder: (_, i) {
                        final l = cart[i];
                        final unit = l.product.priceFor(tier);
                        return Card(
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          child: ListTile(
                            title: Text(l.product.displayName(lang)),
                            subtitle: Text('${dzd(unit)}  ×  ${l.qty.toStringAsFixed(l.qty % 1 == 0 ? 0 : 2)}'
                                '  =  ${dzd(unit * l.qty)}'),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.remove_circle_outline),
                                  onPressed: () =>
                                      ref.read(cartProvider.notifier).setQty(i, l.qty - 1),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.add_circle_outline),
                                  onPressed: () =>
                                      ref.read(cartProvider.notifier).setQty(i, l.qty + 1),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              color: Colors.white,
              child: SafeArea(
                top: false,
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(ref.tr('total')),
                          Text(dzd(total),
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                    Expanded(
                      child: FilledButton(
                        onPressed: cart.isEmpty
                            ? null
                            : () => ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(ref.tr('checkout_next')))),
                        child: Text(ref.tr('checkout')),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

enum PriceTier { wholesale, semiWholesale, retail }

class Product {
  final String? id;
  final String nameAr;
  final String? nameFr;
  final String? sku;
  final String? barcode;
  final String? description;
  final String? imageUrl;
  final String? categoryId;
  final String? brandId;
  final double purchasePrice;
  final double wholesalePrice;
  final double semiWholesalePrice;
  final double retailPrice;
  final double stockQty;
  final double minStock;
  final String unit;
  final int? boxQty;
  final int? cartonQty;
  final String? location;
  final double? weight;
  final double taxRate;
  final bool isActive;

  const Product({
    this.id,
    required this.nameAr,
    this.nameFr,
    this.sku,
    this.barcode,
    this.description,
    this.imageUrl,
    this.categoryId,
    this.brandId,
    this.purchasePrice = 0,
    this.wholesalePrice = 0,
    this.semiWholesalePrice = 0,
    this.retailPrice = 0,
    this.stockQty = 0,
    this.minStock = 0,
    this.unit = 'pcs',
    this.boxQty,
    this.cartonQty,
    this.location,
    this.weight,
    this.taxRate = 0,
    this.isActive = true,
  });

  bool get isLow => stockQty <= minStock;

  String displayName(String lang) =>
      (lang == 'fr' && (nameFr?.isNotEmpty ?? false)) ? nameFr! : nameAr;

  double priceFor(PriceTier t) {
    switch (t) {
      case PriceTier.wholesale:
        return wholesalePrice;
      case PriceTier.semiWholesale:
        return semiWholesalePrice;
      case PriceTier.retail:
        return retailPrice;
    }
  }

  static double _d(dynamic v) => v == null ? 0 : (v as num).toDouble();
  static double? _dn(dynamic v) => v == null ? null : (v as num).toDouble();
  static String? _s(String? v) => (v == null || v.trim().isEmpty) ? null : v.trim();

  factory Product.fromMap(Map<String, dynamic> m) => Product(
        id: m['id'] as String?,
        nameAr: m['name_ar'] as String,
        nameFr: m['name_fr'] as String?,
        sku: m['sku'] as String?,
        barcode: m['barcode'] as String?,
        description: m['description'] as String?,
        imageUrl: m['image_url'] as String?,
        categoryId: m['category_id'] as String?,
        brandId: m['brand_id'] as String?,
        purchasePrice: _d(m['purchase_price']),
        wholesalePrice: _d(m['wholesale_price']),
        semiWholesalePrice: _d(m['semi_wholesale_price']),
        retailPrice: _d(m['retail_price']),
        stockQty: _d(m['stock_qty']),
        minStock: _d(m['min_stock']),
        unit: (m['unit'] as String?) ?? 'pcs',
        boxQty: (m['box_qty'] as num?)?.toInt(),
        cartonQty: (m['carton_qty'] as num?)?.toInt(),
        location: m['location'] as String?,
        weight: _dn(m['weight']),
        taxRate: _d(m['tax_rate']),
        isActive: (m['is_active'] as bool?) ?? true,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name_ar': nameAr,
        'name_fr': _s(nameFr),
        'sku': _s(sku),
        'barcode': _s(barcode),
        'description': _s(description),
        'image_url': imageUrl,
        'category_id': categoryId,
        'brand_id': brandId,
        'purchase_price': purchasePrice,
        'wholesale_price': wholesalePrice,
        'semi_wholesale_price': semiWholesalePrice,
        'retail_price': retailPrice,
        'stock_qty': stockQty,
        'min_stock': minStock,
        'unit': _s(unit) ?? 'pcs',
        'box_qty': boxQty,
        'carton_qty': cartonQty,
        'location': _s(location),
        'weight': weight,
        'tax_rate': taxRate,
        'is_active': isActive,
      };
}

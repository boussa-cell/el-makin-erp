enum PriceTier { wholesale, semiWholesale, retail }

class Product {
  final String? id;
  final String nameAr;
  final String? nameFr;
  final String? sku;
  final String? barcode;
  final double purchasePrice;
  final double wholesalePrice;
  final double semiWholesalePrice;
  final double retailPrice;
  final double stockQty;
  final double minStock;
  final String unit;
  final bool isActive;

  const Product({
    this.id,
    required this.nameAr,
    this.nameFr,
    this.sku,
    this.barcode,
    this.purchasePrice = 0,
    this.wholesalePrice = 0,
    this.semiWholesalePrice = 0,
    this.retailPrice = 0,
    this.stockQty = 0,
    this.minStock = 0,
    this.unit = 'pcs',
    this.isActive = true,
  });

  bool get isLow => stockQty <= minStock;

  String displayName(String lang) =>
      (lang == 'fr' && (nameFr?.isNotEmpty ?? false)) ? nameFr! : nameAr;

  double priceFor(PriceTier t) {
    switch (t) {
      case PriceTier.wholesale:
        return wholesalePrice;
      case PriceTier.semiWholesale:
        return semiWholesalePrice;
      case PriceTier.retail:
        return retailPrice;
    }
  }

  static double _d(dynamic v) => v == null ? 0 : (v as num).toDouble();

  factory Product.fromMap(Map<String, dynamic> m) => Product(
        id: m['id'] as String?,
        nameAr: m['name_ar'] as String,
        nameFr: m['name_fr'] as String?,
        sku: m['sku'] as String?,
        barcode: m['barcode'] as String?,
        purchasePrice: _d(m['purchase_price']),
        wholesalePrice: _d(m['wholesale_price']),
        semiWholesalePrice: _d(m['semi_wholesale_price']),
        retailPrice: _d(m['retail_price']),
        stockQty: _d(m['stock_qty']),
        minStock: _d(m['min_stock']),
        unit: (m['unit'] as String?) ?? 'pcs',
        isActive: (m['is_active'] as bool?) ?? true,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name_ar': nameAr,
        'name_fr': nameFr,
        'sku': (sku?.isEmpty ?? true) ? null : sku,
        'barcode': (barcode?.isEmpty ?? true) ? null : barcode,
        'purchase_price': purchasePrice,
        'wholesale_price': wholesalePrice,
        'semi_wholesale_price': semiWholesalePrice,
        'retail_price': retailPrice,
        'stock_qty': stockQty,
        'min_stock': minStock,
        'unit': unit,
        'is_active': isActive,
      };
}

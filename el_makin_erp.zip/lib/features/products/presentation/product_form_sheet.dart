import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/sync/net.dart';
import '../../../core/utils/barcode_utils.dart';
import '../../../core/widgets/barcode_scanner_page.dart';
import '../../catalog/data/catalog_repository.dart';
import '../data/product_repository.dart';
import '../domain/product.dart';
import 'product_thumb.dart';

class ProductFormSheet extends ConsumerStatefulWidget {
  final Product? product;
  const ProductFormSheet({super.key, this.product});

  @override
  ConsumerState<ProductFormSheet> createState() => _ProductFormSheetState();
}

class _ProductFormSheetState extends ConsumerState<ProductFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final String _productId = widget.product?.id ?? const Uuid().v4();

  late final TextEditingController nameAr, nameFr, sku, barcode, description;
  late final TextEditingController buy, whole, semi, retail, stock, minStock;
  late final TextEditingController unit, boxQty, cartonQty, location, weight, tax;

  String? _categoryId;
  String? _brandId;
  String? _imageUrl;
  bool _active = true;
  bool _saving = false;
  bool _uploading = false;

  String _n(num? v) => (v == null || v == 0) ? '' : v.toString();

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    nameAr = TextEditingController(text: p?.nameAr ?? '');
    nameFr = TextEditingController(text: p?.nameFr ?? '');
    sku = TextEditingController(text: p?.sku ?? '');
    barcode = TextEditingController(text: p?.barcode ?? '');
    description = TextEditingController(text: p?.description ?? '');
    buy = TextEditingController(text: _n(p?.purchasePrice));
    whole = TextEditingController(text: _n(p?.wholesalePrice));
    semi = TextEditingController(text: _n(p?.semiWholesalePrice));
    retail = TextEditingController(text: _n(p?.retailPrice));
    stock = TextEditingController(text: _n(p?.stockQty));
    minStock = TextEditingController(text: _n(p?.minStock));
    unit = TextEditingController(text: p?.unit ?? 'pcs');
    boxQty = TextEditingController(text: _n(p?.boxQty));
    cartonQty = TextEditingController(text: _n(p?.cartonQty));
    location = TextEditingController(text: p?.location ?? '');
    weight = TextEditingController(text: _n(p?.weight));
    tax = TextEditingController(text: _n(p?.taxRate));
    _categoryId = p?.categoryId;
    _brandId = p?.brandId;
    _imageUrl = p?.imageUrl;
    _active = p?.isActive ?? true;
  }

  @override
  void dispose() {
    for (final c in [
      nameAr, nameFr, sku, barcode, description, buy, whole, semi, retail, stock, minStock,
      unit, boxQty, cartonQty, location, weight, tax,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  double _d(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '.')) ?? 0;
  double? _dn(TextEditingController c) =>
      c.text.trim().isEmpty ? null : double.tryParse(c.text.replaceAll(',', '.'));
  int? _in(TextEditingController c) => c.text.trim().isEmpty ? null : int.tryParse(c.text.trim());

  void _snack(String t) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  void _generate() => setState(() => barcode.text = generateEan13());

  Future<void> _scan() async {
    final code = await Navigator.of(context)
        .push<String>(MaterialPageRoute(builder: (_) => const BarcodeScannerPage()));
    if (code != null) barcode.text = code;
  }

  Future<void> _pickImage(ImageSource src) async {
    if (!Net.online) return _snack(ref.tr('image_online_only'));
    try {
      final x = await ImagePicker().pickImage(source: src, maxWidth: 1024, imageQuality: 80);
      if (x == null) return;
      setState(() => _uploading = true);
      final bytes = await x.readAsBytes();
      final path = '$_productId/${DateTime.now().millisecondsSinceEpoch}.jpg';
      final storage = Supabase.instance.client.storage.from('product-images');
      await storage.uploadBinary(
        path,
        bytes,
        fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: true),
      );
      if (mounted) setState(() => _imageUrl = storage.getPublicUrl(path));
    } catch (e) {
      _snack('$e');
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final p = Product(
        id: _productId,
        nameAr: nameAr.text.trim(),
        nameFr: nameFr.text,
        sku: sku.text,
        barcode: barcode.text,
        description: description.text,
        imageUrl: _imageUrl,
        categoryId: _categoryId,
        brandId: _brandId,
        purchasePrice: _d(buy),
        wholesalePrice: _d(whole),
        semiWholesalePrice: _d(semi),
        retailPrice: _d(retail),
        stockQty: _d(stock),
        minStock: _d(minStock),
        unit: unit.text,
        boxQty: _in(boxQty),
        cartonQty: _in(cartonQty),
        location: location.text,
        weight: _dn(weight),
        taxRate: _d(tax),
        isActive: _active,
      );
      await ref.read(productRepoProvider).save(p);
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _saving = false);
      _snack('$e');
    }
  }

  Widget _field(TextEditingController c, String label,
      {bool number = false, bool required = false, Widget? suffix, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        maxLines: maxLines,
        keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : null,
        decoration: InputDecoration(labelText: label, suffixIcon: suffix),
        validator: required
            ? (v) => (v == null || v.trim().isEmpty) ? ref.tr('required') : null
            : null,
      ),
    );
  }

  Widget _two(Widget a, Widget b) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [Expanded(child: a), const SizedBox(width: 8), Expanded(child: b)],
      );

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(categoriesProvider).value ?? const <Category>[];
    final brands = ref.watch(brandsProvider).value ?? const <Brand>[];
    final catValue = categories.any((c) => c.id == _categoryId) ? _categoryId : null;
    final brandValue = brands.any((b) => b.id == _brandId) ? _brandId : null;

    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(ref.tr(widget.product == null ? 'add_product' : 'edit_product'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 16),

                // الصورة
                Row(
                  children: [
                    ProductThumb(url: _imageUrl, size: 72),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _uploading
                          ? Row(children: [
                              const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(strokeWidth: 2)),
                              const SizedBox(width: 8),
                              Text(ref.tr('uploading')),
                            ])
                          : Wrap(
                              spacing: 8,
                              children: [
                                OutlinedButton.icon(
                                  onPressed: () => _pickImage(ImageSource.camera),
                                  icon: const Icon(Icons.photo_camera),
                                  label: Text(ref.tr('camera')),
                                ),
                                OutlinedButton.icon(
                                  onPressed: () => _pickImage(ImageSource.gallery),
                                  icon: const Icon(Icons.photo_library),
                                  label: Text(ref.tr('gallery')),
                                ),
                              ],
                            ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                _field(nameAr, ref.tr('name_ar'), required: true),
                _field(nameFr, ref.tr('name_fr')),
                _field(sku, ref.tr('sku')),
                _field(barcode, ref.tr('barcode_field'),
                    suffix: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          tooltip: ref.tr('generate'),
                          icon: const Icon(Icons.auto_awesome),
                          onPressed: _generate,
                        ),
                        IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: _scan),
                      ],
                    )),
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: DropdownButtonFormField<String?>(
                    value: catValue,
                    decoration: InputDecoration(labelText: ref.tr('product_category')),
                    items: [
                      DropdownMenuItem<String?>(value: null, child: Text(ref.tr('none'))),
                      for (final c in categories)
                        DropdownMenuItem<String?>(value: c.id, child: Text(c.nameAr)),
                    ],
                    onChanged: (v) => setState(() => _categoryId = v),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: DropdownButtonFormField<String?>(
                    value: brandValue,
                    decoration: InputDecoration(labelText: ref.tr('brand')),
                    items: [
                      DropdownMenuItem<String?>(value: null, child: Text(ref.tr('none'))),
                      for (final b in brands)
                        DropdownMenuItem<String?>(value: b.id, child: Text(b.name)),
                    ],
                    onChanged: (v) => setState(() => _brandId = v),
                  ),
                ),
                _field(description, ref.tr('description'), maxLines: 2),

                _two(_field(buy, ref.tr('purchase_price'), number: true),
                    _field(whole, ref.tr('wholesale'), number: true)),
                _two(_field(semi, ref.tr('semi_wholesale'), number: true),
                    _field(retail, ref.tr('retail'), number: true)),
                _two(_field(stock, ref.tr('stock'), number: true),
                    _field(minStock, ref.tr('min_stock'), number: true)),
                _two(_field(unit, ref.tr('unit')), _field(location, ref.tr('location'))),
                _two(_field(boxQty, ref.tr('box_qty'), number: true),
                    _field(cartonQty, ref.tr('carton_qty'), number: true)),
                _two(_field(weight, ref.tr('weight'), number: true),
                    _field(tax, ref.tr('tax'), number: true)),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(ref.tr('active')),
                  value: _active,
                  onChanged: (v) => setState(() => _active = v),
                ),
                const SizedBox(height: 8),
                FilledButton(
                  onPressed: (_saving || _uploading) ? null : _save,
                  child: Text(ref.tr('save')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

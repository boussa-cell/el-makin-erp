import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/widgets/barcode_scanner_page.dart';
import '../data/product_repository.dart';
import '../domain/product.dart';

class ProductFormSheet extends ConsumerStatefulWidget {
  final Product? product;
  const ProductFormSheet({super.key, this.product});

  @override
  ConsumerState<ProductFormSheet> createState() => _ProductFormSheetState();
}

class _ProductFormSheetState extends ConsumerState<ProductFormSheet> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController nameAr, nameFr, sku, barcode, buy, whole, semi, retail, stock, minStock;
  bool _saving = false;

  String _n(double v) => v == 0 ? '' : v.toString();

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    nameAr = TextEditingController(text: p?.nameAr ?? '');
    nameFr = TextEditingController(text: p?.nameFr ?? '');
    sku = TextEditingController(text: p?.sku ?? '');
    barcode = TextEditingController(text: p?.barcode ?? '');
    buy = TextEditingController(text: _n(p?.purchasePrice ?? 0));
    whole = TextEditingController(text: _n(p?.wholesalePrice ?? 0));
    semi = TextEditingController(text: _n(p?.semiWholesalePrice ?? 0));
    retail = TextEditingController(text: _n(p?.retailPrice ?? 0));
    stock = TextEditingController(text: _n(p?.stockQty ?? 0));
    minStock = TextEditingController(text: _n(p?.minStock ?? 0));
  }

  @override
  void dispose() {
    for (final c in [nameAr, nameFr, sku, barcode, buy, whole, semi, retail, stock, minStock]) {
      c.dispose();
    }
    super.dispose();
  }

  double _d(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '.')) ?? 0;

  Future<void> _scan() async {
    final code = await Navigator.of(context)
        .push<String>(MaterialPageRoute(builder: (_) => const BarcodeScannerPage()));
    if (code != null) barcode.text = code;
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final p = Product(
        id: widget.product?.id,
        nameAr: nameAr.text.trim(),
        nameFr: nameFr.text.trim().isEmpty ? null : nameFr.text.trim(),
        sku: sku.text.trim(),
        barcode: barcode.text.trim(),
        purchasePrice: _d(buy),
        wholesalePrice: _d(whole),
        semiWholesalePrice: _d(semi),
        retailPrice: _d(retail),
        stockQty: _d(stock),
        minStock: _d(minStock),
      );
      await ref.read(productRepoProvider).save(p);
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  Widget _field(TextEditingController c, String label,
      {bool number = false, bool required = false, Widget? suffix}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : null,
        decoration: InputDecoration(labelText: label, suffixIcon: suffix),
        validator: required ? (v) => (v == null || v.trim().isEmpty) ? ref.tr('required') : null : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ref.watch(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(ref.tr(widget.product == null ? 'add_product' : 'edit_product'),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 16),
                _field(nameAr, ref.tr('name_ar'), required: true),
                _field(nameFr, ref.tr('name_fr')),
                _field(sku, ref.tr('sku')),
                _field(barcode, ref.tr('barcode_field'),
                    suffix: IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: _scan)),
                _field(buy, ref.tr('purchase_price'), number: true),
                _field(whole, ref.tr('wholesale'), number: true),
                _field(semi, ref.tr('semi_wholesale'), number: true),
                _field(retail, ref.tr('retail'), number: true),
                _field(stock, ref.tr('stock'), number: true),
                _field(minStock, ref.tr('min_stock'), number: true),
                FilledButton(
                  onPressed: _saving ? null : _save,
                  child: Text(ref.tr('save')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

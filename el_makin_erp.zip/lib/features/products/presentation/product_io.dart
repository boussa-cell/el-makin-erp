import 'dart:convert';

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/excel/xlsx_io.dart';
import '../../../core/l10n/strings.dart';
import '../../../core/pdf/pdf_export.dart';
import '../../catalog/data/catalog_repository.dart';
import '../data/product_excel.dart';
import '../data/product_repository.dart';

const _xlsxMime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

/// عمليات استيراد وتصدير المنتجات (Excel) من شاشة المنتجات.
class ProductIo {
  static void _msg(BuildContext context, String t) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  static Future<void> export(BuildContext context, WidgetRef ref) async {
    _msg(context, ref.tr('working'));
    try {
      final bytes = await ProductExcelService().exportAll();
      await shareBytesFile('products.xlsx', bytes, _xlsxMime);
    } catch (e) {
      _msg(context, '$e');
    }
  }

  static Future<void> template(BuildContext context, WidgetRef ref) async {
    try {
      await shareBytesFile('products_template.xlsx', ProductExcelService().template(), _xlsxMime);
    } catch (e) {
      _msg(context, '$e');
    }
  }

  static Future<void> import(BuildContext context, WidgetRef ref) async {
    final file = await openFile();
    if (file == null) return;
    final bytes = await file.readAsBytes();

    final service = ProductExcelService();
    ImportPlan plan;
    try {
      final name = file.name.toLowerCase();
      final rows = name.endsWith('.xlsx')
          ? readXlsx(bytes)
          : readCsv(utf8.decode(bytes, allowMalformed: true));
      plan = await service.plan(rows);
    } catch (e) {
      return _msg(context, '${ref.tr('file_read_error')}: $e');
    }
    if (!context.mounted) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ref.read(langProvider) == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: AlertDialog(
          title: Text(ref.tr('import_confirm')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${ref.tr('import_new')}: ${plan.created}'),
                Text('${ref.tr('import_updated')}: ${plan.updated}'),
                Text('${ref.tr('categories')}: +${plan.newCategories.length}   '
                    '${ref.tr('brands')}: +${plan.newBrands.length}'),
                Text('${ref.tr('import_errors')}: ${plan.errors.length}',
                    style: TextStyle(color: plan.errors.isEmpty ? null : Colors.red)),
                if (plan.errors.isNotEmpty)
                  Text(plan.errors.take(6).join('\n'),
                      style: const TextStyle(fontSize: 12, color: Colors.red)),
                const SizedBox(height: 8),
                Text(ref.tr('import_note'), style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(context).pop(false), child: Text(ref.tr('cancel'))),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size(100, 44)),
              onPressed: plan.products.isEmpty ? null : () => Navigator.of(context).pop(true),
              child: Text(ref.tr('confirm')),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !context.mounted) return;

    _msg(context, ref.tr('working'));
    try {
      await service.apply(plan);
      ref.invalidate(productsProvider);
      ref.invalidate(categoriesProvider);
      ref.invalidate(brandsProvider);
      _msg(context, '${ref.tr('imported')}: ${plan.products.length}');
    } catch (e) {
      _msg(context, '$e');
    }
  }
}

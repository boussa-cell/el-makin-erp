import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/strings.dart';
import '../../../core/utils/money.dart';
import '../../../core/widgets/barcode_scanner_page.dart';
import '../data/product_repository.dart';
import '../domain/product.dart';
import '../../../core/auth/role_provider.dart';
import '../../stock/presentation/stock_adjust_dialog.dart';
import 'product_form_sheet.dart';
import 'product_io.dart';
import 'product_thumb.dart';

class ProductsScreen extends ConsumerStatefulWidget {
  const ProductsScreen({super.key});

  @override
  ConsumerState<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends ConsumerState<ProductsScreen> {
  final _search = TextEditingController();
  String _q = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _openForm([Product? p]) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => ProductFormSheet(product: p),
    );
    if (saved == true) ref.invalidate(productsProvider);
  }

  Future<void> _scan() async {
    final code = await Navigator.of(context)
        .push<String>(MaterialPageRoute(builder: (_) => const BarcodeScannerPage()));
    if (code != null) {
      _search.text = code;
      setState(() => _q = code);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(langProvider);
    final products = ref.watch(productsProvider(_q));
    final role = ref.watch(roleProvider).value;
    final canAdjust = role == 'admin' || role == 'manager';

    return Directionality(
      textDirection: lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(ref.tr('products')),
          actions: [
            if (canAdjust)
              PopupMenuButton<String>(
                icon: const Icon(Icons.table_view),
                onSelected: (v) {
                  if (v == 'export') ProductIo.export(context, ref);
                  if (v == 'import') ProductIo.import(context, ref);
                  if (v == 'template') ProductIo.template(context, ref);
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'export', child: Text(ref.tr('export_products'))),
                  PopupMenuItem(value: 'import', child: Text(ref.tr('import_products'))),
                  PopupMenuItem(value: 'template', child: Text(ref.tr('download_template'))),
                ],
              ),
          ],
        ),
        floatingActionButton: !canAdjust
            ? null
            : FloatingActionButton.extended(
          onPressed: () => _openForm(),
          icon: const Icon(Icons.add),
          label: Text(ref.tr('add_product')),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                controller: _search,
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: ref.tr('search'),
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: _scan),
                ),
              ),
            ),
            Expanded(
              child: products.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(child: Text('${ref.tr('error')}\n$e')),
                data: (list) {
                  if (list.isEmpty) return Center(child: Text(ref.tr('no_products')));
                  return ListView.separated(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final p = list[i];
                      return Card(
                        child: ListTile(
                          onTap: canAdjust ? () => _openForm(p) : null,
                          leading: ProductThumb(url: p.imageUrl),
                          title: Text(p.displayName(lang),
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                              '${ref.tr('retail')}: ${dzd(p.retailPrice)}\n${ref.tr('stock')}: ${p.stockQty}'),
                          isThreeLine: true,
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (canAdjust)
                                IconButton(
                                  tooltip: ref.tr('adjust_stock'),
                                  icon: const Icon(Icons.tune),
                                  onPressed: () async {
                                    final ok = await showDialog<bool>(
                                      context: context,
                                      builder: (_) => StockAdjustDialog(product: p),
                                    );
                                    if (ok == true) ref.invalidate(productsProvider);
                                  },
                                ),
                              if (p.isLow)
                                Tooltip(
                                  message: ref.tr('low_stock'),
                                  child: const Icon(Icons.warning_amber_rounded, color: Colors.red),
                                ),
                              if (canAdjust)
                                IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () async {
                                  await ref.read(productRepoProvider).softDelete(p.id!);
                                  ref.invalidate(productsProvider);
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

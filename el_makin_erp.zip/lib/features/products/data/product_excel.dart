import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../../../core/excel/xlsx_io.dart';

const productColumns = [
  'name_ar',
  'name_fr',
  'sku',
  'barcode',
  'category',
  'brand',
  'purchase_price',
  'wholesale_price',
  'semi_wholesale_price',
  'retail_price',
  'stock_qty',
  'min_stock',
  'unit',
  'description',
];

class ImportPlan {
  final List<Map<String, dynamic>> products; // جاهزة للإدخال/التحديث
  final Set<String> newCategories;
  final Set<String> newBrands;
  final int created;
  final int updated;
  final List<String> errors;

  const ImportPlan({
    required this.products,
    required this.newCategories,
    required this.newBrands,
    required this.created,
    required this.updated,
    required this.errors,
  });
}

class ProductExcelService {
  final _db = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> _all(String select) async {
    final out = <Map<String, dynamic>>[];
    var from = 0;
    while (true) {
      final rows = await _db.from('products').select(select).order('id').range(from, from + 999);
      out.addAll(rows);
      if (rows.length < 1000) break;
      from += 1000;
    }
    return out;
  }

  /// ملف xlsx بكل المنتجات غير المحذوفة.
  Future<Uint8List> exportAll() async {
    final rows = await _all('*, categories(name_ar), brands(name)');
    final data = <List<Object?>>[productColumns];
    for (final m in rows) {
      if (m['deleted_at'] != null) continue;
      final c = m['categories'];
      final b = m['brands'];
      data.add([
        m['name_ar'],
        m['name_fr'],
        m['sku'],
        m['barcode'],
        c is Map ? c['name_ar'] : null,
        b is Map ? b['name'] : null,
        m['purchase_price'],
        m['wholesale_price'],
        m['semi_wholesale_price'],
        m['retail_price'],
        m['stock_qty'],
        m['min_stock'],
        m['unit'],
        m['description'],
      ]);
    }
    return buildXlsx(data, sheetName: 'Products');
  }

  /// قالب فارغ بصف مثال.
  Uint8List template() => buildXlsx([
        productColumns,
        [
          'دفتر 100 ورقة', 'Cahier 100 pages', 'SKU-001', '6130000000011', 'دفاتر', 'Clairefontaine',
          80, 100, 110, 130, 50, 10, 'pcs', 'دفتر مسطر',
        ],
      ], sheetName: 'Products');

  double _num(String s) => double.tryParse(s.trim().replaceAll(',', '.')) ?? 0;
  String? _txt(String s) => s.trim().isEmpty ? null : s.trim();

  /// يحلل الصفوف ويجهّز خطة الاستيراد (دون كتابة أي شيء).
  Future<ImportPlan> plan(List<List<String>> rows) async {
    if (rows.isEmpty) throw Exception('empty file');
    final header = rows.first.map((e) => e.trim().toLowerCase()).toList();
    final idx = {for (var i = 0; i < header.length; i++) header[i]: i};
    if (!idx.containsKey('name_ar')) throw Exception('missing column name_ar');

    String cell(List<String> r, String col) {
      final i = idx[col];
      return (i == null || i >= r.length) ? '' : r[i];
    }

    final existing = await _all('id, sku, barcode');
    final byBarcode = {
      for (final e in existing)
        if ((e['barcode'] as String?)?.isNotEmpty ?? false) e['barcode'] as String: e['id'] as String
    };
    final bySku = {
      for (final e in existing)
        if ((e['sku'] as String?)?.isNotEmpty ?? false) e['sku'] as String: e['id'] as String
    };

    final cats = await _db.from('categories').select('id, name_ar').isFilter('deleted_at', null);
    final brands = await _db.from('brands').select('id, name').isFilter('deleted_at', null);
    final catIds = {for (final c in cats) (c['name_ar'] as String).trim(): c['id'] as String};
    final brandIds = {for (final b in brands) (b['name'] as String).trim(): b['id'] as String};

    final newCats = <String>{};
    final newBrands = <String>{};
    final seenBarcodes = <String>{};
    final seenSkus = <String>{};
    final products = <Map<String, dynamic>>[];
    final errors = <String>[];
    var created = 0;
    var updated = 0;

    for (var i = 1; i < rows.length; i++) {
      final r = rows[i];
      if (r.every((c) => c.trim().isEmpty)) continue;
      final line = i + 1;
      final name = cell(r, 'name_ar').trim();
      if (name.isEmpty) {
        errors.add('$line: name_ar');
        continue;
      }
      final barcode = _txt(cell(r, 'barcode'));
      final sku = _txt(cell(r, 'sku'));
      if (barcode != null && !seenBarcodes.add(barcode)) {
        errors.add('$line: barcode duplicated in file');
        continue;
      }
      if (sku != null && !seenSkus.add(sku)) {
        errors.add('$line: sku duplicated in file');
        continue;
      }

      final id = (barcode != null ? byBarcode[barcode] : null) ?? (sku != null ? bySku[sku] : null);
      if (id == null) {
        created++;
      } else {
        updated++;
      }

      final cat = cell(r, 'category').trim();
      final brand = cell(r, 'brand').trim();
      if (cat.isNotEmpty && !catIds.containsKey(cat)) newCats.add(cat);
      if (brand.isNotEmpty && !brandIds.containsKey(brand)) newBrands.add(brand);

      products.add({
        'id': id ?? const Uuid().v4(),
        'name_ar': name,
        'name_fr': _txt(cell(r, 'name_fr')),
        'sku': sku,
        'barcode': barcode,
        '_category': cat,
        '_brand': brand,
        'purchase_price': _num(cell(r, 'purchase_price')),
        'wholesale_price': _num(cell(r, 'wholesale_price')),
        'semi_wholesale_price': _num(cell(r, 'semi_wholesale_price')),
        'retail_price': _num(cell(r, 'retail_price')),
        'stock_qty': _num(cell(r, 'stock_qty')),
        'min_stock': _num(cell(r, 'min_stock')),
        'unit': _txt(cell(r, 'unit')) ?? 'pcs',
        'description': _txt(cell(r, 'description')),
        'is_active': true,
        'deleted_at': null,
      });
    }

    return ImportPlan(
      products: products,
      newCategories: newCats,
      newBrands: newBrands,
      created: created,
      updated: updated,
      errors: errors,
    );
  }

  /// يكتب الخطة في قاعدة البيانات (التصنيفات والماركات الجديدة أولًا).
  Future<void> apply(ImportPlan plan) async {
    final cats = await _db.from('categories').select('id, name_ar').isFilter('deleted_at', null);
    final brands = await _db.from('brands').select('id, name').isFilter('deleted_at', null);
    final catIds = {for (final c in cats) (c['name_ar'] as String).trim(): c['id'] as String};
    final brandIds = {for (final b in brands) (b['name'] as String).trim(): b['id'] as String};

    for (final n in plan.newCategories) {
      final id = const Uuid().v4();
      await _db.from('categories').insert({'id': id, 'name_ar': n});
      catIds[n] = id;
    }
    for (final n in plan.newBrands) {
      final id = const Uuid().v4();
      await _db.from('brands').insert({'id': id, 'name': n});
      brandIds[n] = id;
    }

    final payload = <Map<String, dynamic>>[];
    for (final p in plan.products) {
      final m = Map<String, dynamic>.from(p);
      final cat = (m.remove('_category') as String?) ?? '';
      final brand = (m.remove('_brand') as String?) ?? '';
      if (cat.isNotEmpty) m['category_id'] = catIds[cat];
      if (brand.isNotEmpty) m['brand_id'] = brandIds[brand];
      payload.add(m);
    }

    for (var i = 0; i < payload.length; i += 200) {
      final end = i + 200 > payload.length ? payload.length : i + 200;
      await _db.from('products').upsert(payload.sublist(i, end));
    }
  }
}

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../domain/product.dart';

class ProductRepository {
  final _db = Supabase.instance.client;

  Future<List<Product>> list({String q = ''}) async {
    var query = _db.from('products').select().isFilter('deleted_at', null);
    final s = q.trim().replaceAll(RegExp(r'[,()%]'), '');
    if (s.isNotEmpty) {
      query = query.or(
          'name_ar.ilike.%$s%,name_fr.ilike.%$s%,sku.ilike.%$s%,barcode.ilike.%$s%');
    }
    final rows = await query.order('name_ar').limit(200);
    return rows.map(Product.fromMap).toList();
  }

  Future<Product?> findByBarcode(String code) async {
    final rows = await _db
        .from('products')
        .select()
        .isFilter('deleted_at', null)
        .eq('barcode', code)
        .limit(1);
    return rows.isEmpty ? null : Product.fromMap(rows.first);
  }

  Future<void> save(Product p) => _db.from('products').upsert(p.toMap());

  Future<void> softDelete(String id) => _db
      .from('products')
      .update({'deleted_at': DateTime.now().toUtc().toIso8601String()}).eq('id', id);
}

final productRepoProvider = Provider((_) => ProductRepository());

final productsProvider = FutureProvider.autoDispose.family<List<Product>, String>(
  (ref, q) => ref.read(productRepoProvider).list(q: q),
);

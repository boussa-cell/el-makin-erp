import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/local/local_db.dart';
import '../../../core/sync/net.dart';
import '../domain/product.dart';

class ProductRepository {
  final _db = Supabase.instance.client;

  /// أونلاين أولًا؛ عند انقطاع الإنترنت يبحث في النسخة المحلية.
  Future<List<Product>> list({String q = ''}) async {
    try {
      var query = _db.from('products').select().isFilter('deleted_at', null);
      final s = q.trim().replaceAll(RegExp(r'[,()%]'), '');
      if (s.isNotEmpty) {
        query = query.or(
            'name_ar.ilike.%$s%,name_fr.ilike.%$s%,sku.ilike.%$s%,barcode.ilike.%$s%');
      }
      final rows = await query.order('name_ar').limit(200).timeout(netTimeout);
      return rows.map(Product.fromMap).toList();
    } catch (e) {
      if (!isNetworkError(e)) rethrow;
      final rows = await ProductCache.search(q);
      return rows.map(Product.fromMap).toList();
    }
  }

  Future<Product?> findByBarcode(String code) async {
    try {
      final rows = await _db
          .from('products')
          .select()
          .isFilter('deleted_at', null)
          .eq('barcode', code)
          .limit(1)
          .timeout(netTimeout);
      return rows.isEmpty ? null : Product.fromMap(rows.first);
    } catch (e) {
      if (!isNetworkError(e)) rethrow;
      final m = await ProductCache.byBarcode(code);
      return m == null ? null : Product.fromMap(m);
    }
  }

  Future<void> save(Product p) => _db.from('products').upsert(p.toMap());

  Future<void> softDelete(String id) => _db
      .from('products')
      .update({'deleted_at': DateTime.now().toUtc().toIso8601String()}).eq('id', id);
}

final productRepoProvider = Provider((_) => ProductRepository());

final productsProvider = FutureProvider.autoDispose.family<List<Product>, String>(
  (ref, q) => ref.read(productRepoProvider).list(q: q),
);

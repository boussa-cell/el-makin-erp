-- EL MAKIN ERP | Phase 1
create extension if not exists pgcrypto;

create type user_role as enum ('admin','manager','vendeur');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role user_role not null default 'vendeur',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    case when exists (select 1 from public.profiles) then 'vendeur'::user_role else 'admin'::user_role end
  );
  return new;
end $$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.current_role_name()
returns text language sql stable security definer set search_path = public as $$
  select role::text from public.profiles where id = auth.uid() and is_active
$$;

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null,
  name_fr text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table public.brands (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name_ar text not null,
  name_fr text,
  sku text unique,
  barcode text unique,
  category_id uuid references public.categories(id),
  brand_id uuid references public.brands(id),
  description text,
  image_url text,
  purchase_price numeric(14,2) not null default 0,
  wholesale_price numeric(14,2) not null default 0,
  semi_wholesale_price numeric(14,2) not null default 0,
  retail_price numeric(14,2) not null default 0,
  stock_qty numeric(14,3) not null default 0,
  min_stock numeric(14,3) not null default 0,
  unit text not null default 'pcs',
  box_qty int,
  carton_qty int,
  location text,
  weight numeric(10,3),
  tax_rate numeric(5,2) not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index products_name_idx on public.products (name_ar);
create index products_barcode_idx on public.products (barcode);

create trigger products_updated before update on public.products
for each row execute function public.set_updated_at();
create trigger categories_updated before update on public.categories
for each row execute function public.set_updated_at();
create trigger brands_updated before update on public.brands
for each row execute function public.set_updated_at();

alter table public.profiles   enable row level security;
alter table public.categories enable row level security;
alter table public.brands     enable row level security;
alter table public.products   enable row level security;

create policy "profiles_read_own_or_admin" on public.profiles for select to authenticated
  using (id = auth.uid() or public.current_role_name() = 'admin');
create policy "profiles_admin_write" on public.profiles for all to authenticated
  using (public.current_role_name() = 'admin') with check (public.current_role_name() = 'admin');

create policy "categories_read" on public.categories for select to authenticated
  using (public.current_role_name() is not null);
create policy "categories_write" on public.categories for all to authenticated
  using (public.current_role_name() in ('admin','manager'))
  with check (public.current_role_name() in ('admin','manager'));

create policy "brands_read" on public.brands for select to authenticated
  using (public.current_role_name() is not null);
create policy "brands_write" on public.brands for all to authenticated
  using (public.current_role_name() in ('admin','manager'))
  with check (public.current_role_name() in ('admin','manager'));

create policy "products_read" on public.products for select to authenticated
  using (public.current_role_name() is not null);
create policy "products_write" on public.products for all to authenticated
  using (public.current_role_name() in ('admin','manager'))
  with check (public.current_role_name() in ('admin','manager'));

insert into storage.buckets (id, name, public) values ('product-images','product-images', true)
on conflict (id) do nothing;

create policy "product_images_read" on storage.objects for select
  using (bucket_id = 'product-images');
create policy "product_images_write" on storage.objects for all to authenticated
  using (bucket_id = 'product-images' and public.current_role_name() in ('admin','manager'))
  with check (bucket_id = 'product-images' and public.current_role_name() in ('admin','manager'));
